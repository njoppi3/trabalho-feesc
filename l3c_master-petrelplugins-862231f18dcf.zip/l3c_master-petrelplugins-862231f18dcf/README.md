﻿# Inversão Classificação e Simulação

1) Inversão Bayesiana Linearizada (BLI)
2) Inversão Bayesiana de Fácies
3) Simulação Geoestatística por FFT-MA
4) Classificação de Fácies por Kohonen

# CPPlugin


Cross Plot Plugin

Function.cs  --- Classe que administra funções externas, como: escrever em arquivos ou chamar processos.

SimpleCommandHandler1.cs --- Classe que cuida dos comandos que são triggerados pela tabzinha no petrel.

CPDataWorkstep.cs --- Classe que gerencia o Workstep e gera a UI, com ela é possível adicionar o plugin na parte dos "Process" do Petrel.

CPDataWorkstepUI.cs --- Classe que gerencia a interface inicial e eventos que acontecem nela.

Plugin.cs --- Classe que contém informações do plugin. (Criado por padrão)

Module.cs --- Classe que gerencia a inicialização e integração de itens do plugin.



# DLL (cuidados na compilação)
Compilar em 64bits.


# PS
Marcar checkbox "Allow unsafe code" em: Proprieties>Build


# CLI wrapper
Para utilizar o wrapper cli precisamos compilar o projeto gauss como lib estática. Para 
isso tem o projeto standalone priors no branch lib.
Tem um exemplo csharppriors que carrega os dados do arquivo txt via wrapper para um 
array gerenciado do csharp e passa para o crossplot pelo wrapper. Do jeito que o 
wrapper está, deve funcionar para uma aplicação standalone. Para o petrel, acredito que 
teremos que remover a criação do QApplication no crossplot.cpp.

Update: A princípio funcionou no Petrel a chamada da janela de priors, feita no último commit 02f18c5 .
O Petrel não tem as libs debug do Qt, por isso precisa copiar QtCored.dll, QtWidgetsd.dll, QtGuid.dll para a pasta bin do projeto csharp.
Precisa testar o Release e implementar o destrutor da classe corssplot no projeto wrapper.

# Qt
O Petrel tem um bug que não deixa utilizar as libs do Qt dele pelo DLL do wrapper. Para contornar, copiar a pasta Qt dentro de Petrel\Public para a pasta Petrel\Extensions.
Adicionar Extensions\Qt ao arquivo Petrel\PluginPackager.exe.config como em: <probing privatePath="Public;Extensions;Extensions\Qt;...
Para utilizar a versão do Petrel do Qt, temos que compilar com uma versão <= que a do Petrel, ou seja, o Petrel 2015 utiliza a versão 5.3.2.
Utilizando esta versão irá funcionar em todas as versões do Petrel que utilizam o Qt5. Portanto, baixar e instalar o Qt5.3.2 e utilizar para compilar.
Não precisa mais copiar as dlls do Qt para a pasta de output do plugin na versão release. Somente para Debug, pois o Petrel não possui as dlls debug.
