#include "kohonen_cli.h"

Eigen::MatrixXd KohonenCLI::cli_to_eigen(cli::array<double>^ input) {
	std::vector<double> vec(input->Length);
	pin_ptr<double> pin(&input[0]);

	double *first(pin);
	double *last(pin + input->Length);
	std::copy(first, last, vec.begin());
	free(pin);

	//Eigen::MatrixXd mat = Eigen::Map<Eigen::MatrixXd>(&vec[0]);
	Eigen::MatrixXd mat;
	return mat;
}

// problem
KohonenCLI::KohonenCLI(ParametersCLI^ par) {
	int len = par->cubes->Length;
	//std::vector<Cube::Ptr> vecCubes(len);
	std::vector<Cube::Ptr> vecCubes;

	for (int a = 0; a < len; a++) {
		CubeCLI^ cube = par->cubes[a];
		vecCubes.push_back(cube->getCube());
	}
	
	auto *p = new _GAUSS::KohonenProblem::Parameters();
	p->x_map = par->x_map;
	p->y_map = par->y_map;
	p->learning_rate = par->learning_rate;
	p->cubes = vecCubes;
	p->num_inlines = par->num_inlines;
	p->num_crosslines = par->num_crosslines;
	p->num_zlines = par->num_zlines;
	p->discretization_level = par->discretization_level;
	p->watershed = par->wathershed;
	p->retrain_net = par->retrain_net;

	problem = new _GAUSS::KohonenProblem(*p);
}

KohonenCLI::~KohonenCLI() {}

// result
void KohonenCLI::setFaciesCube(CubeCLI^ facies) {
	Cube::Ptr cube = facies->getCube();
	getResult().setFaciesCube(cube);
}

void KohonenCLI::setUStarMatrix(cli::array<double>^ ustar) {
	Eigen::MatrixXd mat_ustar = cli_to_eigen(ustar);
	getResult().setUStarMatrix(mat_ustar);
}

void KohonenCLI::setImmMatrix(cli::array<double>^ imm) {
	Eigen::MatrixXd mat_imm = cli_to_eigen(imm);
	getResult().setImmMatrix(mat_imm);
}

CubeCLI^ KohonenCLI::getFaciesCube() {
	Cube::Ptr facies = getResult().getFaciesCube();
	return gcnew CubeCLI(facies);
}

cli::array<double>^ KohonenCLI::getImmOrWatershedM(bool watershed) {
	Eigen::MatrixXd m;
	m = getResult().getImmMatrix();
	if (watershed)
		m = getResult().getUStarMatrix();
	cli::array<double>^ d = gcnew cli::array<double>(m.cols() * m.rows());
	int count = 0;
	for (int i = 0; i < m.rows(); i++)
		for (int j = 0; j < m.cols(); j++) {
			d[count] = m(i, j);
			count++;
		}
	return d;
}

// solver
_GAUSS::KohonenResult KohonenCLI::getResult() {
	return ((_GAUSS::KohonenResult)*solver->getResult());
}

void KohonenCLI::setSolver(unsigned int trailen) {
	solver = new _SOLVERS::KohonenSolver((_GAUSS::KohonenProblem::PTR)problem, trailen);
}
void KohonenCLI::updateProblem() {
	solver->updateProblem((_GAUSS::KohonenProblem::PTR)problem);
}

bool KohonenCLI::solve() {
	return solver->solve();
}