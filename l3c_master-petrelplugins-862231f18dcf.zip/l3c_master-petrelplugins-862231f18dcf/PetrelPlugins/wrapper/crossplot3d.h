
#include <gauss/Prior3D.h>
#include <QtWinExtras/QtWin>

public ref class crossplot3d
{
private:
	Prior3D* cp3d;

	QCoreApplication* a;
	static bool QtInitiated = false;
public:
	crossplot3d();
	crossplot3d(bool testmode);
	void setData(cli::array<double>^ %data, int nz, int ncols, int npriors, bool doCalcFromWells);
	void show();
	void getPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x, cli::array<double>^ %mu_y, cli::array<double>^ %mu_z);
	void setPriors(cli::array<cli::array<double>^>^ data, cli::array<double>^ mu_x, cli::array<double>^ mu_y, cli::array<double>^ mu_z, bool signalUpdate);
	void calcFromWells();
	void setNames(System::String^ label1, System::String^ label2, System::String^ label3);
	System::String^ getPriorName(int i);
	void setPriorName(int i, System::String^ name);
	System::String^ getPriorColor(int i);
	void setPriorColor(int i, System::String^ color);
};

