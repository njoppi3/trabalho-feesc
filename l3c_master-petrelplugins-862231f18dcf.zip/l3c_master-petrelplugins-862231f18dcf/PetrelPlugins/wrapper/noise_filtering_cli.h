#pragma once

#include <gauss/noise_filtering.h>
#include "cube_cli.h"

public ref class NoiseFilteringCLI {
private:
	_SOLVERS::NoiseFilteringSolver* solver;
	_SOLVERS::NoiseFilteringProblem* problem;

private:
	cli::array<double>^ from_pointer(double* resp);

public:
	// problem
	NoiseFilteringCLI(
		CubeCLI^ mean,
		CubeCLI^ conditioning_points,
		double variance,
		int correlation_x_range, int correlation_y_range, int correlation_z_range,
		double x_rotation, double y_rotation, double z_rotation,
		int realizations, int realizations_to_save, double property_maximum_threshold);

	NoiseFilteringCLI(
		double variance,
		int correlation_x_range, int correlation_y_range, int correlation_z_range,
		double x_rotation, double y_rotation, double z_rotation,
		int realizations, int realizations_to_save, double property_maximum_threshold,
		int x_size, int y_size, int z_size
	);

	// solver
	void set_solver();
	void set_solver(CubeCLI^ kriging_mean, CubeCLI^ kriging_variance);
	void set_solver(unsigned int initial_seed);
	void set_solver(unsigned int initial_seed, CubeCLI kriging_mean, CubeCLI kriging_variance);

	void rearm();

	bool solve();

	CubeCLI^ get_result(unsigned index);
	cli::array<double>^ get_under_threshold_probability();

	CubeCLI^ get_kriging_mean();
	CubeCLI^ get_kriging_variance();
	CubeCLI^ get_conditioning_points();
};

