#include "noise_filtering_cli.h"

// problem
NoiseFilteringCLI::NoiseFilteringCLI(
	CubeCLI^ mean,
	CubeCLI^ conditioning_points,
	double variance,
	int correlation_x_range, int correlation_y_range, int correlation_z_range,
	double x_rotation, double y_rotation, double z_rotation,
	int realizations, int realizations_to_save, double property_maximum_threshold)
{

	Cube::Ptr cp(nullptr);
	cp = conditioning_points != nullptr ? conditioning_points->getCube() : nullptr;

	problem = new _SOLVERS::NoiseFilteringProblem(
		mean->getCube(),
		cp,
		variance,
		correlation_x_range, correlation_y_range, correlation_z_range,
		x_rotation, y_rotation, z_rotation,
		realizations, realizations_to_save, property_maximum_threshold
	);
}

NoiseFilteringCLI::NoiseFilteringCLI(
	double variance,
	int correlation_x_range, int correlation_y_range, int correlation_z_range,
	double x_rotation, double y_rotation, double z_rotation,
	int realizations, int realizations_to_save, double property_maximum_threshold,
	int x_size, int y_size, int z_size)
{
	problem = new _SOLVERS::NoiseFilteringProblem(variance,
		correlation_x_range, correlation_y_range, correlation_z_range,
		x_rotation, y_rotation, z_rotation,
		realizations, realizations_to_save, property_maximum_threshold,
		x_size, y_size, z_size);
}

//solver
void NoiseFilteringCLI::set_solver() {
	solver = new _SOLVERS::NoiseFilteringSolver((_SOLVERS::NoiseFilteringProblem::ptr)problem);
}

void NoiseFilteringCLI::set_solver(CubeCLI^ kriging_mean, CubeCLI^ kriging_variance) {
	solver = new _SOLVERS::NoiseFilteringSolver(
		(_SOLVERS::NoiseFilteringProblem::ptr)problem,
		kriging_mean->getCube(),
		kriging_variance->getCube()
	);
}

void NoiseFilteringCLI::set_solver(unsigned int initial_seed) {
	solver = new _SOLVERS::NoiseFilteringSolver(
		(_SOLVERS::NoiseFilteringProblem::ptr)problem,
		initial_seed
	);
}

void NoiseFilteringCLI::set_solver(unsigned int initial_seed, CubeCLI kriging_mean, CubeCLI kriging_variance) {
	solver = new _SOLVERS::NoiseFilteringSolver(
		(_SOLVERS::NoiseFilteringProblem::ptr)problem,
		initial_seed,
		kriging_mean.getCube(),
		kriging_variance.getCube()
	);
}

void NoiseFilteringCLI::rearm() {
	solver->rearm();
}

bool NoiseFilteringCLI::solve() {
	return solver->solve();
}

cli::array<double>^ NoiseFilteringCLI::from_pointer(double* input) {
	pin_ptr<double> pt = &input[0];

	int it = 0;
	while (pt != nullptr) {
		pt++;
		it++;
	}

	cli::array<double>^ result = gcnew cli::array<double>(it);
	for (int i = 0; i < it; i++) {
		result[i] = pt[i];
	}

	return result;
}

CubeCLI^ NoiseFilteringCLI::get_result(unsigned index) {
	double* res = solver->get_result(index);
	Cube* cp = new Cube(res, problem->noise_x_size, problem->noise_y_size, problem->noise_z_size);
	std::shared_ptr<Cube> sp(cp);
	CubeCLI^ cube = gcnew CubeCLI(sp);
	return cube;
}

cli::array<double>^ NoiseFilteringCLI::get_under_threshold_probability() {
	double* res = solver->get_under_threshold_probability();
	return from_pointer(res);
}

CubeCLI^ NoiseFilteringCLI::get_kriging_mean() {
	Cube::Ptr kc = solver->get_kriging_mean();
	return gcnew CubeCLI(kc);
}

CubeCLI^ NoiseFilteringCLI::get_kriging_variance() {
	Cube::Ptr kv = solver->get_kriging_variance();
	return gcnew CubeCLI(kv);
}

CubeCLI^ NoiseFilteringCLI::get_conditioning_points() {
	Cube::Ptr cp = solver->get_conditioning_points();
	return gcnew CubeCLI(cp);
}