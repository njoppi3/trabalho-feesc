#include "BayesianInferenceW.h"



BayesianInferenceW::BayesianInferenceW(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x, cli::array<double>^ %mu_y, cli::array<double>^ %priorProbs)
{
	Eigen::Vector2d** means = new Eigen::Vector2d*[data->Length];
	Eigen::Matrix2d** covars = new Eigen::Matrix2d*[data->Length];
	Eigen::Vector2d* probs = new Eigen::Vector2d[data->Length];

	for (int i = 0; i < data->Length; i++)
	{
		means[i] = new Eigen::Vector2d;
		(*means[i])(0) = mu_x[i];
		(*means[i])(1) = mu_y[i];
		(*probs)(i) = priorProbs[i];

		covars[i] = new Eigen::Matrix2d;
		(*covars[i])(0, 0) = data[i][0];
		(*covars[i])(1, 0) = data[i][1];
		(*covars[i])(0, 1) = data[i][2];
		(*covars[i])(1, 1) = data[i][3];

	}

	bi_ = new GAUSS::BayesianInference(means, covars, data->Length, probs);
}



void BayesianInferenceW::inferMaxProb(CubeCLI^ %x1, CubeCLI^ %x2, CubeCLI^ %out, int %progress) {
	pin_ptr<int> pt = &progress;
	bi_->maxProb(x1->getCubeRaw(), x2->getCubeRaw(), out->getCubeRaw(), pt);
}

void BayesianInferenceW::inferProbCubes(CubeCLI^ %x1, CubeCLI^ %x2, cli::array <CubeCLI^>^ %out, int %progress) {
	pin_ptr<int> pt = &progress;
	std::vector<Cube*> *cubesOut = new std::vector<Cube*>();
	for (int i = 0; i < out->Length; i++) {
		cubesOut->push_back(out[i]->getCubeRaw());
	}
	bi_->infer(x1->getCubeRaw(), x2->getCubeRaw(), cubesOut, pt);
}