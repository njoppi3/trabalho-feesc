#include "elastic_inversion_cli.h"

// problem
ElasticInversionCLI::ElasticInversionCLI(int n_seismic, ParametersCLI^ parameters, cli::array<System::Tuple<cli::array<double>^, double>^>^ wavelet, cli::array<double>^ angles) {
	// From cli::array to std::vector
	Eigen::VectorXd input_angles = cliarray_to_vector_eigen(angles);


	// From C# wavelets to WaveletPTR (gauss' wavelets)
	std::vector<WaveletPTR> gaussWavelets;
	for (int a = 0; a < wavelet->Length; a++) {
		auto tupleElement = wavelet[a];
		int len = tupleElement->Item1->Length;
		pin_ptr<double> pt = &tupleElement->Item1[0];
		std::shared_ptr<Wavelet> wav(new Wavelet(pt, len, len/2, tupleElement->Item2));
		//free(pt);
		gaussWavelets.push_back(wav);
	}

	Eigen::VectorXd esgm_d2 = cliarray_to_vector_eigen(parameters->sgm_d2); 

	Eigen::Vector3d matsgm = cliarray_to_vector_eigen(parameters->sgm_m);

	// Convert std::vector to Eigen::MatrixXd
	
	Eigen::Matrix3d matprop = Matrix3d::Ones();
	matprop(0, 1) = parameters->prop_corr[0];
	matprop(0, 2) = parameters->prop_corr[1];
	matprop(1, 0) = parameters->prop_corr[0];
	matprop(1, 2) = parameters->prop_corr[2];
	matprop(2, 0) = parameters->prop_corr[1];
	matprop(2, 1) = parameters->prop_corr[2];

	_GAUSS::ElasticProblem::Parameters *probpars = new _GAUSS::ElasticProblem::Parameters();
	probpars->sgm_d2 = esgm_d2;
	probpars->sgm_m = matsgm;
	probpars->prop_corr = matprop;
	probpars->corr_samples = parameters->corr_samples;
	probpars->trend_frequency = parameters->trend_frequency;
	probpars->interval_frequency_sec = parameters->interval_frequency_sec;
	probpars->filter_model = parameters->filter_model;
	probpars->merge_inversion = parameters->merge_inversion;
	probpars->calc_ip_vpvs = parameters->calc_ip_vpvs;

	problem = new _GAUSS::ElasticProblem(n_seismic, *probpars, gaussWavelets, input_angles);
}

std::vector<double> ElasticInversionCLI::cliarray_to_vector(cli::array<double>^ arr) {
	// From cli::array to std::vector
	std::vector<double> vec(arr->Length);
	pin_ptr<double> pin(&arr[0]);

	double *first(pin);
	double *last(pin + arr->Length);
	std::copy(first, last, vec.begin());
	free(pin);
	return vec;
}

double ElasticInversionCLI::convertUIVpstdtoLogstd(double uistd)
{
	return _GAUSS::ElasticProblem::convertUIVpstdtoLogstd(uistd);
}

double ElasticInversionCLI::convertUIVsstdtoLogstd(double uistd)
{
	return _GAUSS::ElasticProblem::convertUIVsstdtoLogstd(uistd);
}
double ElasticInversionCLI::convertUIRhostdtoLogstd(double uistd)
{
	return _GAUSS::ElasticProblem::convertUIRhostdtoLogstd(uistd);
}

Eigen::VectorXd ElasticInversionCLI::cliarray_to_vector_eigen(cli::array<double>^ arr) {
	// From cli::array to std::vector
	Eigen::VectorXd vec(arr->Length);

	for (int i = 0; i < arr->Length; i++)
		vec(i) = arr[i];
	
	return vec;
}

int ElasticInversionCLI::getNSeismic() {
	return problem->getNSeismic();
}

int ElasticInversionCLI::getNProperty() {
	return problem->getNProperty();
}

int ElasticInversionCLI::getNAngles() {
	return problem->getNAngles();
}

//Eigen::VectorXd ElasticInversionCLI::getAngles() {
//	return problem->getAngles();
//}

cli::array<CubeCLI^>^ ElasticInversionCLI::getSeismicCubes() {
	auto cubevec = problem->getSeismicCubes(); // std::vector<Cube::Ptr>
	cli::array<CubeCLI^>^ output = gcnew cli::array<CubeCLI^>(cubevec.size());
	int i = 0;
	for (auto a : cubevec) {
		output[i] = gcnew CubeCLI(a);
		i++;
	}
	return output;
}

void ElasticInversionCLI::setSeismicCubes(cli::array<CubeCLI^>^ seismicCubes) {
	std::vector<Cube::Ptr> gaussCubes;
	for (int a = 0; a < seismicCubes->Length; a++) {
		gaussCubes.push_back(seismicCubes[a]->getCube());
	}
	problem->setSeismicCubes(gaussCubes);
}

CubeCLI^ ElasticInversionCLI::getTrendVpCube() {
	Cube::Ptr vpc = problem->getTrendVpCube();
	return gcnew CubeCLI(vpc);
}

CubeCLI^ ElasticInversionCLI::getTrendVsCube() {
	Cube::Ptr vsc = problem->getTrendVsCube();
	return gcnew CubeCLI(vsc);
}

CubeCLI^ ElasticInversionCLI::getTrendPCube() {
	Cube::Ptr pc = problem->getTrendPCube();
	return gcnew CubeCLI(pc);
}

void ElasticInversionCLI::setTrendVpCube(CubeCLI^ trendVpCube) {
	problem->setTrendVpCube(trendVpCube->getCube());
}

void ElasticInversionCLI::setTrendVsCube(CubeCLI^ trendVsCube) {
	problem->setTrendVsCube(trendVsCube->getCube());
}

void ElasticInversionCLI::setTrendPCube(CubeCLI^ trendPCube) {
	problem->setTrendPCube(trendPCube->getCube());
}

double ElasticInversionCLI::createCorrSamples(double corrSamplesUI, cli::array<double>^ %w, double waverate) {
	int len = w->Length;
	pin_ptr<double> pt = &w[0];
	std::shared_ptr<Wavelet> wav(new Wavelet(pt, len, len/2, waverate));
	return problem->createCorrSamples(corrSamplesUI, wav);
}

double ElasticInversionCLI::createSgmD2ForSingleCube(CubeCLI^ seismic, double signalToNoiseRatio) {
	Cube::Ptr cses = seismic->getCube();
	return problem->createSgmD2ForSingleCube(cses, signalToNoiseRatio);
}

double ElasticInversionCLI::convertDegreesToRadians(double angle) {
	return problem->convertDegreesToRadians(angle);
}

//result
CubeCLI^ ElasticInversionCLI::getVpCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->getVpCube();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ElasticInversionCLI::getVsCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->getVsCube();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ElasticInversionCLI::getPCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->getPCube();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ElasticInversionCLI::getIPCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->getIPCube();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ElasticInversionCLI::getVPVSCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->getVPVSCube();
	return gcnew CubeCLI(cpp_cube);
}

cli::array<CubeCLI^>^ ElasticInversionCLI::getSyntheticsCube() {

	std::vector<Cube::Ptr> cubevec;
	if (solver)
		cubevec = solver->getResult()->getSyntheticsCube(); // std::vector<Cube::Ptr>
	cli::array<CubeCLI^>^ output = gcnew cli::array<CubeCLI^>(cubevec.size());
	int i = 0;
	for (auto a : cubevec) {
		output[i] = gcnew CubeCLI(a);
		i++;
	}
	return output;
}

void ElasticInversionCLI::setVpCube(CubeCLI^ vp) {
	Cube::Ptr cpp_vp = vp->getCube();
	if (solver)
		solver->getResult()->setVpCube(cpp_vp);
}

void ElasticInversionCLI::setVsCube(CubeCLI^ vs) {
	Cube::Ptr cpp_vs = vs->getCube();
	if (solver)
		solver->getResult()->setVsCube(cpp_vs);
}

void ElasticInversionCLI::setPCube(CubeCLI^ p) {
	Cube::Ptr cpp_p = p->getCube();
	if (solver)
		solver->getResult()->setPCube(cpp_p);
}

void ElasticInversionCLI::setIPCube(CubeCLI^ ip) {
	Cube::Ptr cpp_p = ip->getCube();
	if (solver)
		solver->getResult()->setIPCube(cpp_p);
}

void ElasticInversionCLI::setVPVSCube(CubeCLI^ vpvs) {
	Cube::Ptr cpp_p = vpvs->getCube();
	if (solver)
		solver->getResult()->setVPVSCube(cpp_p);
}

void ElasticInversionCLI::setSyntheticsCubes(cli::array<CubeCLI^>^ syntheticsCubes) {
	std::vector<Cube::Ptr> vecScube(syntheticsCubes->Length);
	for (int a = 0; a < syntheticsCubes->Length; a++) {
		vecScube.push_back(syntheticsCubes[a]->getCube());
	}
	if (solver)
		solver->getResult()->setSyntheticsCubes(vecScube);
}

// solver
bool ElasticInversionCLI::solve() {
	solver = new _SOLVERS::ElasticSolver((_GAUSS::ElasticProblem::PTR)problem);
	bool res = solver->solve();
	return res;
}

_GAUSS::ElasticResult::PTR ElasticInversionCLI::getResult() {
	if (solver)
		return solver->getResult();
	return 0;
}
