#pragma once
#include <gauss/elastic_facies_inversion/elasticfaciesproblem.h>
#include <gauss/elastic_facies_inversion/elasticfaciessolver.h>
#include <gauss/elastic_facies_inversion/elasticfaciesresult.h>
#include "cube_cli.h"

public ref class FaciesElasticInversionCLI
{
public:

	ref struct ParametersCLI {
		cli::array<cli::array<double>^>^ C_prior;
		cli::array<cli::array<double>^>^ mu_prior;
		cli::array<double>^ transitionMatrix;
		cli::array<double>^ proportions;
		cli::array<CubeCLI^>^ cubeProportions;

		int n_seismic;
		int n_iterations_perTrace;

		cli::array<double>^ sgm_d2;
		cli::array<cli::array<double>^>^ wavelets;
		cli::array<double>^ angles;
		
		double interval_frequency_sec = 0.004;

		double corr_samples;

	};

	FaciesElasticInversionCLI(ParametersCLI^ parameters);

	void setSeismicCubes(cli::array<CubeCLI^>^ seismicCubes);

	static Eigen::MatrixXd CLIarrayToEigenSquareMatrix(cli::array<double> ^ data);

	// result
	CubeCLI^ getVpCube();

	CubeCLI^ getVsCube();

	CubeCLI^ getPCube();

	CubeCLI^ getMapFacCube();

	cli::array<CubeCLI^>^ getFacProbCubes();

	cli::array<CubeCLI^>^ getSyntheticsCubes();

	int getProgress() { return solver->current_progress(); };

	// solver
	bool solve();

	_GAUSS::ElasticFaciesResult::PTR getResult() {
		if (solver)
			return solver->getResult();
		return 0;
	};


private:
	_GAUSS::ElasticFaciesProblem* problem;
	_SOLVERS::ElasticFaciesSolver* solver;
};

