#include "cube_cli.h"

CubeCLI::CubeCLI(std::size_t numInlines, std::size_t numCrosslines, std::size_t numZs) {
	c = new std::shared_ptr<Cube>(new Cube(numInlines, numCrosslines, numZs));
}

CubeCLI::CubeCLI(const Cube::Ptr cube) {
	c = new std::shared_ptr<Cube>(cube);
}

CubeCLI::~CubeCLI() {
	delete c;
}

Cube::Ptr CubeCLI::getCube() {
	return *c;
}

void CubeCLI::set(CubeCLI^ newc) {
	if (c)
		delete c;
	c = new std::shared_ptr<Cube>(newc->getCube());
}

void CubeCLI::getTraceAt(std::size_t inlineIndex, std::size_t crosslineIndex, cli::array<double>^ trace) {
	pin_ptr<double> pt = &trace[0];
	Eigen::Map<Eigen::VectorXd> dataTrace(pt, trace->Length, 1);
	(*c)->getTraceAt(inlineIndex, crosslineIndex, dataTrace);
}

void CubeCLI::setTraceAt(std::size_t inlineIndex, std::size_t crosslineIndex, const cli::array<double>^ trace) {
	pin_ptr<double> pt = &trace[0];
	Eigen::Map<Eigen::VectorXd> dataTrace(pt, trace->Length, 1);
	(*c)->setTraceAt(inlineIndex, crosslineIndex, dataTrace);
}

void CubeCLI::setValueAt(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineIndex, double value) {
	(*c)->setValueAt(inlineIndex, crosslineIndex, zlineIndex, value);
}

void CubeCLI::getNValuesAt(std::size_t inlineIndex, std::size_t crosslineIndex, cli::array<double>^ values) {
	pin_ptr<double> pt = &values[0];
	Eigen::Map<Eigen::VectorXd> dataValues(pt, values->Length, 1);
	(*c)->getNValuesAt(inlineIndex, crosslineIndex, dataValues);
}

double CubeCLI::getAt(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineIndex) {
	return (*c)->getAt(inlineIndex, crosslineIndex, zlineIndex);
}

void CubeCLI::getSubTrace(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineStart,
	std::size_t zlineOffset, cli::array<double>^ subTrace) {
	pin_ptr<double> pt = &subTrace[0];
	Eigen::Map<Eigen::VectorXd> dataSubTrace(pt, subTrace->Length, 1);
	(*c)->getSubTrace(inlineIndex, crosslineIndex, zlineStart, zlineOffset, dataSubTrace);
}

void CubeCLI::setSubTrace(std::size_t inlineIndex, std::size_t crosslineIndex,
	std::size_t zlineStart, cli::array<double>^ subTrace) {
	pin_ptr<double> pt = &subTrace[0];
	Eigen::Map<Eigen::Matrix<double, -1, 1>> dataSubTrace(pt, subTrace->Length, 1);
	(*c)->setSubTrace(inlineIndex, crosslineIndex, zlineStart, dataSubTrace);
}

std::size_t CubeCLI::getNumInlines() { 
	return (*c)->getNumInlines();
}

std::size_t CubeCLI::getNumCrosslines() { 
	return (*c)->getNumCrosslines();
}
std::size_t CubeCLI::getNumZlines() {
	return (*c)->getNumZlines();
}
std::size_t CubeCLI::getSize() { 
	return (*c)->getSize();
}

void CubeCLI::setValue(double v) {
	(*c)->setValue(v);
}

double CubeCLI::getMean() {
	return (*c)->getMean();
}

void CubeCLI::setMean(double mean) {
	(*c)->setMean(mean);
}

double CubeCLI::getSum() {
	return (*c)->getSum();
}

void CubeCLI::setSum(double sum) {
	(*c)->setSum(sum);
}

double CubeCLI::getStdDeviation() {
	return (*c)->getStdDeviation();
}

void CubeCLI::setStdDeviation(double stdDeviation) {
	(*c)->setStdDeviation(stdDeviation);
}

long CubeCLI::getCountNonZeros() {
	return (*c)->getCountNonZeros();
}

void CubeCLI::setCountNonZeros(unsigned long numNonZeros) {
	(*c)->setCountNonZeros(numNonZeros);
}

void CubeCLI::setCropOffset(size_t offset) {
	(*c)->setCropOffset(offset);
}

std::size_t CubeCLI::getCropOffset() {
	return (*c)->getCropOffset();
}

void CubeCLI::filterNaN(float value) {
	(*c)->filterNaN(value);
}

void CubeCLI::filterNaN() {
	(*c)->filterNaN();
}

double CubeCLI::getFromDataAt(std::size_t pos) {
	return (*c)->getFromDataAt(pos);
}

void CubeCLI::setDataAt(std::size_t pos, double value) {
	(*c)->setDataAt(pos, value);
}

void CubeCLI::setMax(double value) {
	(*c)->setMax(value);
}

double CubeCLI::getMax() {
	return (*c)->getMax();
}

void CubeCLI::setMin(double value) { 
	(*c)->setMin(value);
}

double CubeCLI::getMin() {
	return (*c)->getMin();
}

void CubeCLI::calculateStatistics() {
	(*c)->calculateStatistics();
}

void CubeCLI::clearStatistics() {
	(*c)->clearStatistics();
}