#include "facies_elasticInversion_cli.h"
#include "elastic_inversion_cli.h"

#define cliarray_to_vector_eigen ElasticInversionCLI::cliarray_to_vector_eigen

FaciesElasticInversionCLI::FaciesElasticInversionCLI(ParametersCLI^ parameters)
{
	GAUSS::ElasticFaciesProblem::Parameters pars_cpp;

	pars_cpp.angles = cliarray_to_vector_eigen(parameters->angles);
	pars_cpp.corr_samples = parameters->corr_samples;
	pars_cpp.n_iterations = parameters->n_iterations_perTrace;
	pars_cpp.n_seismic = parameters->n_seismic;
	pars_cpp.sgm_d2 = cliarray_to_vector_eigen(parameters->sgm_d2);
	pars_cpp.transitionMatrix = CLIarrayToEigenSquareMatrix(parameters->transitionMatrix);
	pars_cpp.samp_interval_sec = parameters->interval_frequency_sec;
	if (parameters->proportions)
		pars_cpp._priorProportions_vec = cliarray_to_vector_eigen(parameters->proportions);

	for (int i = 0; i < parameters->wavelets->Length; i++) {
		int len = parameters->wavelets[i]->Length;
		pin_ptr<double> pt = &parameters->wavelets[i][0];
		std::shared_ptr<Wavelet> wav(new Wavelet(pt, len, len / 2, parameters->interval_frequency_sec));
		pars_cpp.wavelets.push_back(wav);
	}

	for (int i = 0; i < parameters->mu_prior->Length; i++) {
		pars_cpp.C_prior.push_back(CLIarrayToEigenSquareMatrix(parameters->C_prior[i]));
		pars_cpp.mu_prior.push_back(cliarray_to_vector_eigen(parameters->mu_prior[i]));
		if (parameters->cubeProportions)
			pars_cpp._priorProportions.push_back(parameters->cubeProportions[i]->getCube());

	}

	problem = new GAUSS::ElasticFaciesProblem(pars_cpp);

}

Eigen::MatrixXd FaciesElasticInversionCLI::CLIarrayToEigenSquareMatrix(cli::array<double> ^ data) {
	int ll = sqrt(data->Length);
	MatrixXd ret(ll, ll);
	for (int i = 0; i < data->Length; i++)
		ret(i) = data[i];
	return ret;
}

void FaciesElasticInversionCLI::setSeismicCubes(cli::array<CubeCLI^>^ seismicCubes) {
	std::vector<Cube::Ptr> gaussCubes;
	for (int a = 0; a < seismicCubes->Length; a++) {
		gaussCubes.push_back(seismicCubes[a]->getCube());
	}
	problem->setSeismicCubes(gaussCubes);
}

CubeCLI^ FaciesElasticInversionCLI::getVpCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->_vpCube;
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ FaciesElasticInversionCLI::getVsCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->_vsCube;
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ FaciesElasticInversionCLI::getPCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->_pCube;
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ FaciesElasticInversionCLI::getMapFacCube() {
	Cube::Ptr cpp_cube;
	if (solver)
		cpp_cube = solver->getResult()->_mapFacCube;
	return gcnew CubeCLI(cpp_cube);
}

cli::array<CubeCLI^>^ FaciesElasticInversionCLI::getFacProbCubes() {

	std::vector<Cube::Ptr> cubevec;
	if (solver)
		cubevec = solver->getResult()->_facProbCubes; // std::vector<Cube::Ptr>
	cli::array<CubeCLI^>^ output = gcnew cli::array<CubeCLI^>(cubevec.size());
	int i = 0;
	for (auto a : cubevec) {
		output[i] = gcnew CubeCLI(a);
		i++;
	}
	return output;
}

cli::array<CubeCLI^>^ FaciesElasticInversionCLI::getSyntheticsCubes() {

	std::vector<Cube::Ptr> cubevec;
	if (solver)
		cubevec = solver->getResult()->_syntheticsCubes; // std::vector<Cube::Ptr>
	cli::array<CubeCLI^>^ output = gcnew cli::array<CubeCLI^>(cubevec.size());
	int i = 0;
	for (auto a : cubevec) {
		output[i] = gcnew CubeCLI(a);
		i++;
	}
	return output;
}

bool FaciesElasticInversionCLI::solve() {
	_GAUSS::ElasticFaciesProblem::PTR prob(problem);
	solver = new _SOLVERS::ElasticFaciesSolver(prob);
	bool res = solver->solve();
	return res;
}