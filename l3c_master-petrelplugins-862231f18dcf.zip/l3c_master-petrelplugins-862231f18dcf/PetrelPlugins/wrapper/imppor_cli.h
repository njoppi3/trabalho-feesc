#pragma once

#include <gauss/impedanceporosity_inversion/imppor_problem.h>
#include <gauss/impedanceporosity_inversion/imppor_result.h>
#include <gauss/impedanceporosity_inversion/imppor_solver.h>
#include <gauss/wavelet.h>
#include "cube_cli.h"
#include <Eigen/Dense>

public ref class ImpporCLI {
private:
	_GAUSS::ImpporProblem *problem;
	_SOLVERS::ImpporSolver *solver;

public:
	// problem
	ref struct ParametersCLI {
		double sgm_d2;
		double sgm_m_z;
		double sgm_m_phi;
		double corr_samples;
		double horizontal_corr_samples;
		double trend_frequency = 8;
		bool filter_model = false;
		bool merge_inversion = false;
		double mu_z;
		double mu_phi;
		cli::array<double>^ C_prior;
	};

	ImpporCLI(int n_seismic, ParametersCLI^ par, cli::array<double>^ wavelet, double interval);

	bool isWaveletFromCube();
	int windowSize();

	CubeCLI^ getTrendCubez();
	CubeCLI^ getTrendCubephi();
	CubeCLI^ getSeismicCube();

	void setTrendCubez(CubeCLI^ trendCubez);
	void setTrendCubephi(CubeCLI^ trendCubephi);
	void setSeismicCube(CubeCLI^ seismicCube);
	void configCorrelationMatrix(int inlineIndex, int crosslineIndex);

	double createSgmM(double impedance_uncertainty, CubeCLI^ impedance);
	double createSgmD2(CubeCLI^ seismic, double noise_level);
	double createCorrSamples(double corr_samples_ui, double wavelet_interval);
	double getPosteriorStdAI(double impedance_mean);
	double getPosteriorStdPhi();

	// result
	CubeCLI^ synteticsCube();
	CubeCLI^ invertedCubeAI();
	CubeCLI^ invertedCubePHI();

	void createSynteticsCube(int numInlines, int numCrosslines, int numZs);
	void createInvertedCubes(int numInlines, int numCrosslines, int numZs);

	// solver
	bool solve();
	_GAUSS::ImpporResult::PTR getResult();

};

