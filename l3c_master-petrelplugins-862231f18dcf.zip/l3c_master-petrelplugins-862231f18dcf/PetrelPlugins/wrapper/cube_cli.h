#pragma once

#include <gauss/Cube.h>

public ref class CubeCLI {
private:
	std::shared_ptr<Cube>* c;
	cli::array<double>^ data_;

public:
	CubeCLI(std::size_t numInlines, std::size_t numCrosslines, std::size_t numZs);
	CubeCLI(const Cube::Ptr cube);

	~CubeCLI();

	Cube::Ptr getCube();
	Cube* getCubeRaw() { return c->get(); };

	void set(CubeCLI^ newc);

	void getTraceAt(std::size_t inlineIndex, std::size_t crosslineIndex, cli::array<double>^ trace);
	void setTraceAt(std::size_t inlineIndex, std::size_t crosslineIndex, const cli::array<double>^ trace);
	void setValueAt(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineIndex, double value);
	void getNValuesAt(std::size_t inlineIndex, std::size_t crosslineIndex, cli::array<double>^ values);
	double getAt(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineIndex);

	void getSubTrace(std::size_t inlineIndex, std::size_t crosslineIndex, std::size_t zlineStart,
		std::size_t zlineOffset, cli::array<double>^ subTrace);

	void setSubTrace(std::size_t inlineIndex, std::size_t crosslineIndex,
		std::size_t zlineStart, cli::array<double>^ subTrace);

	/*const double * getTracePointer(std::size_t inlineIndex, std::size_t crosslineIndex) const;*/

	std::size_t getNumInlines();
	std::size_t getNumCrosslines();
	std::size_t getNumZlines();
	std::size_t getSize();
	void setValue(double v);
	void setNAN() { (*c)->setValue(std::nan("")); };

	/*double * getData() { return _data; }
	auto getSubCube(std::size_t inlineBegin, std::size_t numInlines, std::size_t crosslineBegin, std::size_t numCrosslines, std::size_t zlineBegin, std::size_t numZlines);
	void setSubCube(Cube & subCube);*/

	double getMean();
	void setMean(double mean);
	double getSum();
	void setSum(double sum);
	double getStdDeviation();
	void setStdDeviation(double stdDeviation);
	long getCountNonZeros();
	void setCountNonZeros(unsigned long numNonZeros);
	void setCropOffset(size_t offset);
	std::size_t getCropOffset();
	void filterNaN(float value);
	void filterNaN();

	double getFromDataAt(std::size_t pos);
	void setDataAt(std::size_t pos, double value);

	void setMax(double value);
	double getMax();
	void setMin(double value);
	double getMin();
	void calculateStatistics();
	void clearStatistics();
};