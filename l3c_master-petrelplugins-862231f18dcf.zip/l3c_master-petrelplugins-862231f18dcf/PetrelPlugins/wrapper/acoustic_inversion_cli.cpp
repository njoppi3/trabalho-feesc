#include "acoustic_inversion_cli.h"

// Problem
AcousticInversionCLI::AcousticInversionCLI(int n_seismic, Parameters^ parameters, cli::array<double>^ wavelet, double srate) {
	pin_ptr<double> pt = &wavelet[0];
	WaveletPTR wav(new Wavelet(pt, wavelet->Length, wavelet->Length/2, srate));
	_GAUSS::AcousticProblem::Parameters * p = new _GAUSS::AcousticProblem::Parameters();
	p->sgm_d2 = parameters->sgm_d2;
	p->sgm_m = parameters->sgm_m;
	p->corr_samples = parameters->corr_samples;
	p->filter_model = parameters->filter_model;
	p->horizontal_corr_samples = parameters->horizontal_corr_samples;
	p->merge_inversion = parameters->merge_inversion;
	p->trend_frequency = parameters->trend_frequency;

	if (parameters->window_size > 0)
		problem = new _GAUSS::AcousticProblem(n_seismic, *p, wav,parameters->window_size);
	else
		problem = new _GAUSS::AcousticProblem(n_seismic, *p, wav);
}
//AcousticInversionCLI::AcousticInversionCLI(int n_seismic, _GAUSS::AcousticProblem::Parameters *parameters, cli::array<float>^ wavelet) {
	//problem = new _GAUSS::AcousticProblem(n_seismic, parameters, wavelet);
//}

AcousticInversionCLI::AcousticInversionCLI(int n_seismic, _GAUSS::AcousticProblem::Parameters *parameters, CubeCLI wavelet_cube) {
	Cube::Ptr wc = wavelet_cube.getCube();
	problem = new _GAUSS::AcousticProblem(n_seismic, *parameters, wc);
}

AcousticInversionCLI::~AcousticInversionCLI() {}

bool AcousticInversionCLI::isWaveletFromCube() {
	return problem->isWaveletFromCube();
}

int AcousticInversionCLI::windowSize() {
	return problem->windowSize();
}

CubeCLI^ AcousticInversionCLI::getTrendCube() {
	Cube::Ptr c = problem->getTrendCube();
	return gcnew CubeCLI(c);
}

CubeCLI^ AcousticInversionCLI::getSeismicCube() {
	Cube::Ptr c = problem->getSeismicCube();
	return gcnew CubeCLI(c);
}

void AcousticInversionCLI::setTrendCube(CubeCLI^ trendCube) {
	problem->setTrendCube(trendCube->getCube());
}

void AcousticInversionCLI::setSeismicCube(CubeCLI^ seismicCube) {
	problem->setSeismicCube(seismicCube->getCube());
}

void AcousticInversionCLI::configCorrelationMatrix(int inlineIndex, int crosslineIndex) {
	problem->configCorrelationMatrix(inlineIndex, crosslineIndex);
}

double AcousticInversionCLI::createSgmM(double impedance_uncertainty, CubeCLI impedance) {
	return problem->createSgmM(impedance_uncertainty, impedance.getCube());
}

double AcousticInversionCLI::createSgmD2(CubeCLI seismic, double noise_level) {
	return problem->createSgmD2(seismic.getCube(), noise_level);
}

double AcousticInversionCLI::createCorrSamples(double corr_samples_ui, double wavelet_interval) {
	return problem->createCorrSamples(corr_samples_ui, wavelet_interval);
}

double AcousticInversionCLI::getPosteriorStd(double impedance_mean) {
	return problem->getPosteriorStd(impedance_mean);
}

double AcousticInversionCLI::convertUIstdtoLogstd(double uistd)
{
	return _GAUSS::AcousticProblem::convertUIstdtoLogstd(uistd);
}

// Solver
bool AcousticInversionCLI::solve() {
	solver = new _SOLVERS::AcousticSolver((_GAUSS::AcousticProblem::PTR)problem);
	bool success = false;
	try
	{
		success = solver->solve();
	}
	catch (const std::exception&)
	{
		return false;
	}
	return success;
}

bool AcousticInversionCLI::solveCorrelated() {
	solver = new _SOLVERS::AcousticSolver((_GAUSS::AcousticProblem::PTR)problem);
	return solver->solveCorrelated();
}

_GAUSS::AcousticResult AcousticInversionCLI::getResult() {
	return ((_GAUSS::AcousticResult)*solver->getResult());
}

// Result
CubeCLI^ AcousticInversionCLI::synteticsCube() {
	Cube::Ptr c = getResult().synteticsCube();
	return gcnew CubeCLI(c);
}

CubeCLI^ AcousticInversionCLI::invertedCube() {
	Cube::Ptr c = getResult().invertedCube();
	return gcnew CubeCLI(c);
}

void AcousticInversionCLI::createSynteticsCube(int numInlines, int numCrosslines, int numZs) {
	getResult().createSynteticsCube(numInlines, numCrosslines, numZs);
}

void AcousticInversionCLI::createInvertedCube(int numInlines, int numCrosslines, int numZs) {
	getResult().createSynteticsCube(numInlines, numCrosslines, numZs);
}