#include "crossplot.h"
#include <QtWidgets\QApplication>
#include <QtCore/QDir>
#include "read_file.h"
#include <gauss/ui/crossplotwindow.h>
#include <QtCore/QLibrary>
#include <QtCore/QTextStream>
#include <msclr\marshal_cppstd.h>
#include <istream>
#include <gauss/plots/ellipse.h>

crossplot::crossplot() {
	this->crossplot::crossplot(false);
}

// use testmode in debug only
crossplot::crossplot(bool testmode)
{
	int argc = 0;
	char **argv = nullptr;
	a = QApplication::instance();

	if (testmode==false)
		initQt();

	if (!a)
		a = new QApplication(argc, argv);
	cpw = new CrossPlotWindow();
	cpw->setWindowTitle("Priors definition");
}

crossplot::~crossplot() {
	delete cpw;
	if (a)
		delete a;
}

void crossplot::setData(cli::array<double>^ %data, int nz, int ncols) {
	pin_ptr<double> pt = &data[0];
	Eigen::Map<Eigen::MatrixXd> dataMatrix(pt, nz, ncols);
	cpw->setCPData(dataMatrix);
}

void crossplot::show()
{
	cpw->showNormal();
	a->exec();
}

void crossplot::hideSaveLoad() {
	cpw->disableSaveLoad();
}

void crossplot::getPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x,
	cli::array<double>^ %mu_y)
{
	int n = cpw->priorsLength();

	data = gcnew cli::array<cli::array<double>^>(n);
	for (int i = 0; i < n; i++) {
		data[i] = gcnew cli::array<double>(4);
	}


	mu_x = gcnew cli::array<double>(n);
	mu_y = gcnew cli::array<double>(n);


	for (size_t i = 0; i < n; i++)
	{
		pin_ptr<double> dataa = &data[i][0];
		pin_ptr<double> mu_xx = &mu_x[i];
		pin_ptr<double> mu_yy = &mu_y[i];
		cpw->getPriors(dataa, mu_xx, mu_yy, i);
	}
}

void crossplot::setPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x,
	cli::array<double>^ %mu_y)
{
	int n = data->GetLength(0);
	if (n < 1)
		return;

	double** C = new double*[n];
	
	for (size_t i = 0; i < n; i++)
	{
		pin_ptr<double> dataa = &data[i][0];

		C[i] = new double[4];
		memcpy(C[i],dataa,4*sizeof(double));
	}

	pin_ptr<double> mu_xx = &mu_x[0];
	pin_ptr<double> mu_yy = &mu_y[0];
	cpw->setPriors(C, mu_xx, mu_yy, n);
	
	for (size_t i = 0; i < n; i++)
		delete[] C[i];
	delete[] C;
}

int crossplot::priorsLength()
{
	return cpw->priorsLength();
}

bool crossplot::isAccepted() {
	return cpw->result() == cpw->Accepted;
}

void crossplot::savePriors(System::String^ fname) {
	msclr::interop::marshal_context context;
	std::string fn = context.marshal_as<std::string>(fname);
	//QString * file = new QString(filna);
	cpw->savePriors(fn);
}

void crossplot::loadPriors(System::String^ fname) {
	msclr::interop::marshal_context context;
	cpw->loadPriors(context.marshal_as<std::string>(fname));
}

cli::array<double>^ crossplot::readFile(System::String^ fname, int %nrows, int %ncols) {
	cli::array<System::String^>^ header;
	return readFile(fname, nrows, ncols, header, false);
}



cli::array<double>^ crossplot::readFile(System::String^ fname, int %nrows, int %ncols, cli::array<System::String^>^ %header, bool hasHeader) {
	std::string headerLine = "";
	MatrixXd dadosprior1 = readMatrix((char *)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(fname).ToPointer(), headerLine, hasHeader);
	nrows = dadosprior1.rows();
	ncols = dadosprior1.cols();
	if (hasHeader) {
		header = gcnew cli::array<System::String^>(ncols);
		std::stringstream ss(headerLine);
		std::string token;
		char delim = '\t';
		int i = 0;

		while (std::getline(ss, token, delim)) {
			header[i++] = gcnew System::String(token.c_str());
			if (i > ncols)
				break;
		}
	}

	cli::array<double>^ data = gcnew cli::array<double>(nrows * ncols);

	for (int i = 0; i < nrows * ncols; i++) {
		data[i] = dadosprior1.array()(i);
	}

	return data;

}

void crossplot::initQt()
{
	if (QtInitiated)
		return;

	char ownPth[MAX_PATH * 2];

	// Use GetModuleFileName() with module handle to get the path
	GetModuleFileNameA(NULL, ownPth, (sizeof(ownPth)));
	

	QString pathBase = QString(ownPth).remove("petrel.exe", Qt::CaseInsensitive);
	QString finalPath = QDir(pathBase).filePath("Public/Qt/plugins");
	QString qwind = QDir(finalPath).filePath("platforms/qwindows.dll");

	if (!QFileInfo(qwind).exists())
		throw gcnew System::Exception("Error with Qt library.\nCould not open the Quality Control interface.\nPlease reinstall Petrel.\nMissing File:" + "\n"
			+ gcnew System::String(qwind.toStdString().c_str())
		);


	QApplication::addLibraryPath(finalPath);
	QtInitiated = true;
}

void crossplot::setXText(System::String^ xtext) {
	msclr::interop::marshal_context context;
	std::string * standardString = new string(context.marshal_as<std::string>(xtext));
	cpw->setXText(*standardString);
}
void crossplot::setYText(System::String^ ytext) {
	msclr::interop::marshal_context context;
	std::string * standardString = new string(context.marshal_as<std::string>(ytext));
	cpw->setYText(*standardString);
}

System::String^ crossplot::getPriorName(int i) 
{
	return msclr::interop::marshal_as<System::String^>(cpw->getPriorNameByIdx(i));
}

System::String^ crossplot::getPriorColor(int i) 
{
	QColor color = cpw->getPriorColorByIdx(i);
	return msclr::interop::marshal_as<System::String^>(color.name().toUtf8().constData());
}

void crossplot::setPriorColor(int i, System::String^ color) {
	msclr::interop::marshal_context context;

	std::string c = context.marshal_as<std::string>(color);
	QColor q_color;
	q_color.setNamedColor(QString(c.c_str()));
	cpw->setPriorColorByIdx(i, q_color);
}