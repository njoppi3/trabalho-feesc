#pragma once
#include <gauss\BayesianInference.h>
#include "cube_cli.h"

public ref class BayesianInferenceW
{
public:
	BayesianInferenceW(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x, cli::array<double>^ %mu_y, cli::array<double>^ %priorProbs);
	void inferMaxProb(CubeCLI^ %x1, CubeCLI^ %x2, CubeCLI^ %out, int %progress);
	void inferProbCubes(CubeCLI^ %x1, CubeCLI^ %x2, cli::array <CubeCLI^>^ %out, int %progress);

private:
	GAUSS::BayesianInference * bi_;
	
};

