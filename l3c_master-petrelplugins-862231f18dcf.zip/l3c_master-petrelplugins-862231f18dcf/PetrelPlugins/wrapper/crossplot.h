#pragma once

#include <gauss/ui/crossplotwindow.h>
#include <QtWinExtras/QtWin>

public ref class crossplot
{

private:
	CrossPlotWindow* cpw;

	QCoreApplication* a;
	static bool QtInitiated = false;
public:
	crossplot(bool testmode);
	crossplot();
	~crossplot();

	void setData(cli::array<double>^ %data, int nz, int ncols);
	void show();
	void getPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x,
		cli::array<double>^ %mu_y);
	void setPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x,
		cli::array<double>^ %mu_y);
	int priorsLength();
	static cli::array<double>^ readFile(System::String^ fname, int %nrows, int %ncols);
	static cli::array<double>^ readFile(System::String^ fname, int %nrows, int %ncols, cli::array<System::String^>^ %header, bool hasHeader);
	bool isAccepted();
	void savePriors(System::String^ fname);
	void loadPriors(System::String^ fname);
	void hideSaveLoad();
	static void initQt();
	void setXText(System::String^ xtext);
	void setYText(System::String^ ytext);
	System::String^ getPriorName(int i);
	System::String^ getPriorColor(int i);
	void setPriorColor(int i, System::String^ color);
};

