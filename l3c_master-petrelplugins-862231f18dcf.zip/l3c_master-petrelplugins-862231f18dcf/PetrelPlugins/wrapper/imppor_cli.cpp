#include "imppor_cli.h"

// problem
ImpporCLI::ImpporCLI(int n_seismic, ParametersCLI^ par, cli::array<double>^ wavelet, double interval) {
	int len = wavelet->Length;
	pin_ptr<double> pt = &wavelet[0];
	std::shared_ptr<Wavelet> wav(new Wavelet(pt, len, len / 2, interval));

	_GAUSS::ImpporProblem::Parameters *probpars = new _GAUSS::ImpporProblem::Parameters();
	probpars->sgm_d2 = par->sgm_d2;
	probpars->sgm_m_z = par->sgm_m_z;
	probpars->sgm_m_phi = par->sgm_m_phi;
	probpars->corr_samples = par->corr_samples;
	probpars->horizontal_corr_samples = par->horizontal_corr_samples;
	probpars->trend_frequency = par->trend_frequency;
	probpars->filter_model = par->filter_model;
	probpars->merge_inversion = par->merge_inversion;
	probpars->mu_z = par->mu_z;
	probpars->mu_phi = par->mu_phi;
	probpars->C_prior(0) = par->C_prior[0];
	probpars->C_prior(1) = par->C_prior[1];
	probpars->C_prior(2) = par->C_prior[2];
	probpars->C_prior(3) = par->C_prior[3];

	problem = new _GAUSS::ImpporProblem(n_seismic, *probpars, wav);
}

bool ImpporCLI::isWaveletFromCube() {
	return problem->isWaveletFromCube();
}

int ImpporCLI::windowSize() {
	return problem->windowSize();
}

CubeCLI^ ImpporCLI::getTrendCubez() {
	Cube::Ptr cz = problem->getTrendCubez();
	return gcnew CubeCLI(cz);
}

CubeCLI^ ImpporCLI::getTrendCubephi() {
	Cube::Ptr cphi = problem->getTrendCubephi();
	return gcnew CubeCLI(cphi);
}

CubeCLI^ ImpporCLI::getSeismicCube() {
	Cube::Ptr sc = problem->getSeismicCube();
	return gcnew CubeCLI(sc);
}

void ImpporCLI::setTrendCubez(CubeCLI^ trendCubez) {
	problem->setTrendCubez(trendCubez->getCube());
}

void ImpporCLI::setTrendCubephi(CubeCLI^ trendCubephi) {
	problem->setTrendCubephi(trendCubephi->getCube());
}

void ImpporCLI::setSeismicCube(CubeCLI^ seismicCube) {
	problem->setSeismicCube(seismicCube->getCube());
}

void ImpporCLI::configCorrelationMatrix(int inlineIndex, int crosslineIndex) {
	problem->configCorrelationMatrix(inlineIndex, crosslineIndex);
}

double ImpporCLI::createSgmM(double impedance_uncertainty, CubeCLI^ impedance) {
	return problem->createSgmM(impedance_uncertainty, impedance->getCube());
}

double ImpporCLI::createSgmD2(CubeCLI^ seismic, double noise_level) {
	return problem->createSgmD2(seismic->getCube(), noise_level);
}

double ImpporCLI::createCorrSamples(double corr_samples_ui, double wavelet_interval) {
	return problem->createCorrSamples(corr_samples_ui, wavelet_interval);
}

double ImpporCLI::getPosteriorStdAI(double impedance_mean) {
	return problem->getPosteriorStdAI(impedance_mean);
}

double ImpporCLI::getPosteriorStdPhi() {
	return problem->getPosteriorStdPhi();
}

// result
CubeCLI^ ImpporCLI::synteticsCube() {
	_GAUSS::ImpporResult::PTR result = solver->getResult();
	Cube::Ptr cpp_cube = result->synteticsCube();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ImpporCLI::invertedCubeAI() {
	_GAUSS::ImpporResult::PTR result = solver->getResult();
	Cube::Ptr cpp_cube = result->invertedCubeAI();
	return gcnew CubeCLI(cpp_cube);
}

CubeCLI^ ImpporCLI::invertedCubePHI() {
	_GAUSS::ImpporResult::PTR result = solver->getResult();
	Cube::Ptr cpp_cube = result->invertedCubePHI();
	return gcnew CubeCLI(cpp_cube);
}


void ImpporCLI::createInvertedCubes(int numInlines, int numCrosslines, int numZs) {
	_GAUSS::ImpporResult::PTR result = solver->getResult();
	result->createInvertedCubes(numInlines, numCrosslines, numZs);
}

void ImpporCLI::createSynteticsCube(int numInlines, int numCrosslines, int numZs) {
	_GAUSS::ImpporResult::PTR result = solver->getResult();
	result->createSynteticsCube(numInlines, numCrosslines, numZs);
}

// solver
bool ImpporCLI::solve() {
	solver = new _SOLVERS::ImpporSolver((_GAUSS::ImpporProblem::PTR)problem);
	return solver->solve();
}

_GAUSS::ImpporResult::PTR ImpporCLI::getResult() {
	return solver->getResult();
}