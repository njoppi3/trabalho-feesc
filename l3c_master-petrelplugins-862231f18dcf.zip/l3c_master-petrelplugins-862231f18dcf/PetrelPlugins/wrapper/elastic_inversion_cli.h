#pragma once
#include <gauss/elastic_inversion/elastic_problem.h>
#include <gauss/elastic_inversion/elastic_solver.h>
#include <gauss/elastic_inversion/elastic_result.h>
#include "cube_cli.h"

public ref class ElasticInversionCLI {
private:
	_GAUSS::ElasticProblem* problem;
	_SOLVERS::ElasticSolver* solver;

public:
	static std::vector<double> cliarray_to_vector(cli::array<double>^ arr);
	static Eigen::VectorXd cliarray_to_vector_eigen(cli::array<double>^ arr);
public:
	//problem
	ref struct ParametersCLI {
		cli::array<double>^ sgm_d2;
		cli::array<double>^ sgm_m;
		cli::array<double>^ prop_corr;
		double corr_samples = 1.0;
		double trend_frequency = 6.0;
		double interval_frequency_sec = 0.004;
		bool filter_model = true;
		bool merge_inversion = false;
		bool calc_ip_vpvs = false;
	};

	ElasticInversionCLI(int n_seismic, ParametersCLI^ parameters, cli::array<System::Tuple<cli::array<double>^, double>^>^ wavelet, cli::array<double>^ angles);

	int getNSeismic();
	int getNProperty();
	int getNAngles();
	//Eigen::VectorXd getAngles();

	cli::array<CubeCLI^>^ getSeismicCubes();
	void setSeismicCubes(cli::array<CubeCLI^>^ seismicCubes);

	CubeCLI^ getTrendVpCube();
	CubeCLI^ getTrendVsCube();
	CubeCLI^ getTrendPCube();
	void setTrendVpCube(CubeCLI^ trendVpCube);
	void setTrendVsCube(CubeCLI^ trendVsCube);
	void setTrendPCube(CubeCLI^ trendPCube);

	double createCorrSamples(double corrSamplesUI, cli::array<double>^ %w, double waverate);
	//static Eigen::Matrix3d createPropCorr(double vpRho, double vsRho, double vpVs);
	//static Eigen::Vector3d createSgmM(double vpUncertainty, const Cube::Ptr vpTrend, double vsUncertainty, const Cube::Ptr vsTrend, double pUncertainty, const Cube::Ptr pTrend);
	double createSgmD2ForSingleCube(CubeCLI^ seismic, double signalToNoiseRatio);
	double convertDegreesToRadians(double angle);
	static double convertUIVpstdtoLogstd(double uistd);
	static double convertUIVsstdtoLogstd(double uistd);
	static double convertUIRhostdtoLogstd(double uistd);

	// result
	CubeCLI^ getVpCube();

	CubeCLI^ getVsCube();

	CubeCLI^ getPCube();

	CubeCLI^ getIPCube();

	CubeCLI^ getVPVSCube();

	cli::array<CubeCLI^>^ getSyntheticsCube();

	void setVpCube(CubeCLI^ vp);

	void setVsCube(CubeCLI^ vs);

	void setPCube(CubeCLI^ p);

	void setIPCube(CubeCLI^ ip);

	void setVPVSCube(CubeCLI^ vpvs);

	void setSyntheticsCubes(cli::array<CubeCLI^>^ syntheticsCubes);

	int getProgress() { return solver->current_progress(); };

	// solver
	bool solve();
	_GAUSS::ElasticResult::PTR getResult();
};