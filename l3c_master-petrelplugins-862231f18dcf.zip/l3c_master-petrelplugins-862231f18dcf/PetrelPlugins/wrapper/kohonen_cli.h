#include <gauss/facies/kohonen_problem.h>
#include <gauss/facies/kohonen_result.h>
#include <gauss/facies/kohonen_solver.h>
#include "cube_cli.h"

#pragma once
public ref class KohonenCLI {
private:
	GAUSS::KohonenProblem* problem;
	_SOLVERS::KohonenSolver* solver;

private:
	Eigen::MatrixXd cli_to_eigen(cli::array<double>^ input);

public:
	// problem
	ref struct ParametersCLI {
		int x_map;
		int y_map;
		float learning_rate;
		cli::array<CubeCLI^>^ cubes;
		int num_inlines;
		int num_crosslines;
		int num_zlines;
		int discretization_level;
		bool wathershed;
		bool retrain_net;
	};

	KohonenCLI(ParametersCLI^ par);
	~KohonenCLI();

	// result
	void setFaciesCube(CubeCLI^ facies);
	void setUStarMatrix(cli::array<double>^ ustar);
	void setImmMatrix(cli::array<double>^ imm);
	CubeCLI^ getFaciesCube();
	cli::array<double>^ getImmOrWatershedM(bool watershed);

	// solver
	_GAUSS::KohonenResult getResult();
	void setSolver(unsigned int trailen);
	void updateProblem();
	int getProgress() { return solver->current_progress(); }
	bool solve();
};