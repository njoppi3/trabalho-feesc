﻿#include "crossplot3d.h"
#include "crossplot.h"
#include <QtWidgets\QApplication>
#include <QtCore/QDir>
//#include "read_file.h"
#include <QtCore/QLibrary>
#include <QtCore/QTextStream>
#include <msclr\marshal_cppstd.h>

crossplot3d::crossplot3d() {
	this->crossplot3d::crossplot3d(false);
}

// use testmode in debug only
crossplot3d::crossplot3d(bool testmode)
{
	int argc = 0;
	char **argv = nullptr;
	a = QApplication::instance();

	if (testmode == false)
		crossplot::initQt();

	if (!a)
		a = new QApplication(argc, argv);
	cp3d = new Prior3D();

}

void crossplot3d::setData(cli::array<double>^ %data, int nz, int ncols, int npriors, bool doCalcFromWells) {
	pin_ptr<double> pt = &data[0];
	Eigen::Map<Eigen::MatrixXd> dataMatrix(pt, nz, ncols);
	cp3d->setData(dataMatrix, npriors, doCalcFromWells);
}

void crossplot3d::setPriors(cli::array<cli::array<double>^>^ data, cli::array<double>^ mu_x, cli::array<double>^ mu_y, cli::array<double>^ mu_z, bool signalUpdate) {
	int n = data->Length;
	
	double **Ct = new double*[n];
	for (int i = 0; i < n; i++) {
		 Ct[i] = new double[9];
		 for (int j = 0; j < 9; j++)
			 Ct[i][j] = data[i][j];
	}
	pin_ptr<double> mu_1 = &mu_x[0];
	pin_ptr<double> mu_2 = &mu_y[0];
	pin_ptr<double> mu_3 = &mu_z[0];

	cp3d->setPriors(Ct, mu_1, mu_2, mu_3, n, signalUpdate);
}



void crossplot3d::show()
{
	cp3d->show();
	a->exec();
}

void crossplot3d::setNames(System::String^ label1, System::String^ label2, System::String^ label3) {

	msclr::interop::marshal_context context;

	std::string s1 = context.marshal_as<std::string>(label1);
	std::string s2 = context.marshal_as<std::string>(label2);
	std::string s3 = context.marshal_as<std::string>(label3);
	cp3d->setNames(s1,s2,s3);
}

void crossplot3d::calcFromWells() {
	cp3d->calcFromWells();
}

void crossplot3d::getPriors(cli::array<cli::array<double>^>^ %data, cli::array<double>^ %mu_x,
	cli::array<double>^ %mu_y, cli::array<double>^ %mu_z)
{
	int n = cp3d->getNPriors();

	data = gcnew cli::array<cli::array<double>^>(n);
	for (int i = 0; i < n; i++) {
		data[i] = gcnew cli::array<double>(9);
	}


	mu_x = gcnew cli::array<double>(n);
	mu_y = gcnew cli::array<double>(n);
	mu_z = gcnew cli::array<double>(n);

	for (size_t i = 0; i < n; i++)
	{
		pin_ptr<double> dataa = &data[i][0];
		pin_ptr<double> mu_xx = &mu_x[i];
		pin_ptr<double> mu_yy = &mu_y[i];
		pin_ptr<double> mu_zz = &mu_z[i];
		cp3d->getPrior(dataa, mu_xx, mu_yy, mu_zz, i);
	}
}

System::String^ crossplot3d::getPriorName(int i)
{
	return msclr::interop::marshal_as<System::String^>(cp3d->getPriorName(i));
}

void crossplot3d::setPriorName(int i, System::String^ name) {
	msclr::interop::marshal_context context;
	std::string c = context.marshal_as<std::string>(name);
	QString new_name(c.c_str());
	cp3d->setPriorName(i, new_name);
}

System::String^ crossplot3d::getPriorColor(int i)
{
	QColor color = cp3d->getPriorColor(i);
	return msclr::interop::marshal_as<System::String^>(color.name().toUtf8().constData());
}

void crossplot3d::setPriorColor(int i, System::String^ color) {
	msclr::interop::marshal_context context;

	std::string c = context.marshal_as<std::string>(color);
	QColor q_color;
	q_color.setNamedColor(QString(c.c_str()));
	cp3d->setPriorColor(i, q_color);
}