﻿namespace csharp_priors
{
    using System;
    using System.Windows.Forms;
    using System.IO;

    class standalone
    {
        static void Main()
        {
            crossplot cp = new crossplot(true);
            int nrows = -1, ncols=-1;
            cp.hideSaveLoad();
            string[] header = null;

            double[] dados = crossplot.readFile("dadosPrior.txt", ref nrows, ref ncols, ref header, true);

            //cp.setData(ref dados, nrows, ncols, 0, true);
            cp.setData(ref dados, nrows, ncols);
            //cp.setNames("Vp", "Vs", "Rho");
            cp.setXText(header[0]);
            cp.setYText(header[1]);

            string curFile = @"priors.txt";
            if (File.Exists(curFile))
                cp.loadPriors(curFile);
            cp.show();

            double[][] C = null;
            double[] mux = null, muy = null;

            cp.getPriors(ref C, ref mux, ref muy);
            if (cp.isAccepted())
                cp.savePriors(curFile);
            /*
            // -------------
            int n = cp.priorsLength();
            double[][] data = null;
            double[] x = null;
            double[] y = null;

            cp.getPriors(ref data, ref x, ref y);

            for (int i = 0; i < n; i++) {
                MessageBox.Show("C[0]: " + data[i][0].ToString() + "\n C[1]: " + data[i][1].ToString() + "\n C[2]: " 
                                + data[i][2].ToString() + "\n C[3]: " + data[i][3].ToString() + "\n mu_x: " 
                                + x[i].ToString() + "\n mu_y: " + y[i].ToString());
            }*/

        }
    }

}

