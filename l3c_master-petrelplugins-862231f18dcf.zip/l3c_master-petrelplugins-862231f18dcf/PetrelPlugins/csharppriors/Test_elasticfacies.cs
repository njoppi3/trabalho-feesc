﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_priors
{
    class Test_elasticfacies
    {
        static void Main()
        {
            FaciesElasticInversionCLI.ParametersCLI pars = new FaciesElasticInversionCLI.ParametersCLI();

            pars.angles = new double[] { 0.1920, 0.3665, 0.5411 };
            pars.corr_samples = 2.5;
            int npriors = 4;

            int nrows = -1, ncols = -1;
            int nrowsprobmap = -1, ncolsprobmap = -1;

            pars.cubeProportions = new CubeCLI[npriors];
            pars.C_prior = new double[npriors][];
            pars.mu_prior = new double[npriors][];
            for (int i = 0; i < npriors; i++)
            {
                double[] prob_map_array = crossplot.readFile("D:/ToPetrel/dados/probmap" + (i + 1) + ".txt", ref nrowsprobmap, ref ncolsprobmap);
                CubeCLI cube = new CubeCLI(1, 1, Convert.ToUInt64(nrowsprobmap));
                cube.setTraceAt(0, 0, prob_map_array);
                pars.cubeProportions[i] = cube;
                pars.C_prior[i] = crossplot.readFile("D:/ToPetrel/dados/C_prior" + (i + 1) + ".txt", ref nrows, ref ncols);
                pars.mu_prior[i] = crossplot.readFile("D:/ToPetrel/dados/mu_prior" + (i + 1) + ".txt", ref nrows, ref ncols);
            }

            pars.interval_frequency_sec = 0.004;
            pars.n_iterations_perTrace = 1000;
            pars.n_seismic = nrowsprobmap - 1;
            pars.sgm_d2 = new double[3] { 1349611389.70614, 1457250872.10651, 720083800.011914 };
            pars.wavelets = new double[3][];

            CubeCLI[] seismic = new CubeCLI[3];

            for (int i = 0; i < 3; i++)
            {
                pars.wavelets[i] = crossplot.readFile("D:/ToPetrel/dados/wavelet" + (i + 1) + ".txt", ref nrows, ref ncols);
                double[] seisi = crossplot.readFile("D:/ToPetrel/dados/seismic" + (i + 1) + ".txt", ref nrows, ref ncols);
                seismic[i] = new CubeCLI(1, 1, Convert.ToUInt64(nrows));
                seismic[i].setTraceAt(0, 0, seisi);
            }

            pars.transitionMatrix = new double[] {0.6500, 0.5000, 0.1300, 0, 0.3500, 0.2500, 0.1300,
                                0, 0, 0.2500, 0.7400, 0.5000, 0, 0, 0, 0.5000};

            Stopwatch stopwatch = new Stopwatch();


            FaciesElasticInversionCLI fi = new FaciesElasticInversionCLI(pars);

            fi.setSeismicCubes(seismic);
            stopwatch.Start();

            fi.solve();

            stopwatch.Stop();

            System.Diagnostics.Debug.WriteLine("Elapsed Time is {0} ms", stopwatch.ElapsedMilliseconds);

            string createText = "Elapsed Time is" + stopwatch.ElapsedMilliseconds.ToString();
            File.WriteAllText("D:/debug_csgibbs.txt", createText);

            CubeCLI mapfac = fi.getMapFacCube();

            printMatrix(mapfac, @"D:/ToPetrel/dados/csharp_mapFac.txt");

            var mapprob = fi.getFacProbCubes();
            printMatrix(mapprob[0], @"D:/ToPetrel/dados/csharp_probmap1.txt");

            printMatrix(mapprob[1], @"D:/ToPetrel/dados/csharp_probmap2.txt");

            printMatrix(mapprob[2], @"D:/ToPetrel/dados/csharp_probmap3.txt");

            printMatrix(mapprob[3], @"D:/ToPetrel/dados/csharp_probmap4.txt");

            printMatrix(fi.getVpCube(), @"D:/ToPetrel/dados/csharp_vp.txt");

            printMatrix(fi.getVsCube(), @"D:/ToPetrel/dados/csharp_vs.txt");

            printMatrix(fi.getPCube(), @"D:/ToPetrel/dados/csharp_p.txt");

        }

        static void printMatrix(CubeCLI cube, string filename)
        {
            double[] trace = new double[cube.getNumZlines()];

            cube.getTraceAt(0, 0, trace);
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberDecimalSeparator = ".";

            using (StreamWriter writer = new StreamWriter(filename, false))
            {
                foreach (var value in trace)
                {
                    writer.WriteLine(value.ToString(nfi));
                }
            }
        }

    }
}
