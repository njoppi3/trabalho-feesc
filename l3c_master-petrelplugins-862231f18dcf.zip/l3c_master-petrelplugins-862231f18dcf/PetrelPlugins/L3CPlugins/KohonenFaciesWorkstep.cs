using System;
using System.Linq;
using System.Collections;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.KohonenFaciesWorkstepUI;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using Slb.Ocean.Basics;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the KohonenFaciesWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class KohonenFaciesWorkstep : Workstep<KohonenFaciesWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {

        

        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override KohonenFaciesWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "0c798687-5985-4823-a5fc-64194077062e";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;
            public KohonenTaskSetup ktask;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                this.args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�
                //inputs
                List<SeismicCube> volumeCubeList = new List<SeismicCube>();
                foreach (string cubeDroid in args.structure.volumeCubeListDroid) {
                    volumeCubeList.Add(Functions.getCubeByReferenceVar(new Droid(cubeDroid)));
                }
                //options
                decimal neuronsX = args.structure.neuronsX;
                decimal neuronsY = args.structure.neuronsY;
                decimal discretization = args.structure.discretization;
                bool retrainNetCB = args.structure.retrainNetCB;
                bool inlinePrevCB = args.structure.inlinePrevCB;
                decimal inlinePrev = args.structure.inlinePrev;
                bool watershed = args.structure.watershed;
                //vertGate
                RegularHeightFieldSurface top = null;
                if (args.structure.topDroid != "") {
                    top = Functions.getRegularHeightFieldSurface(new Droid(args.structure.topDroid));
                    PetrelLogger.InfoOutputWindow("top: " + top.Name);
                }
                RegularHeightFieldSurface bottom = null;
                if (args.structure.bottomDroid != "") {
                    bottom = Functions.getRegularHeightFieldSurface(new Droid(args.structure.bottomDroid));
                    PetrelLogger.InfoOutputWindow("bottom: " + bottom.Name);
                }
                double topOffset = args.structure.topOffset;
                PetrelLogger.InfoOutputWindow("topOffset: " + topOffset.ToString());
                double bottomOffset = args.structure.bottomOffset;
                PetrelLogger.InfoOutputWindow("bottomOffset: " + bottomOffset.ToString());

                // ----------------------- check for horizon and create mean hor ----

                bool useHorizons = false;
                double[,] meanHor = null;
                double horSamples = 0;
                double tstart = volumeCubeList[0].Origin.Z * 1000;
                double tstep = volumeCubeList[0].PositionAtIndex(new IndexDouble3(0, 0, 1)).Z * -1000 + tstart;
                if (top != null)
                {
                    if (bottom == null)
                        bottom = top;

                    var seismicCube = volumeCubeList[0];

                    double tend = seismicCube.PositionAtIndex(new IndexDouble3(0, 0, seismicCube.NumSamplesIJK.K - 1)).Z * 1000;
                    meanHor = Functions.StartMeanHorizonFromTwo(top.SpatialLattice.OriginalLattice, top.Samples, bottom.Samples, topOffset, bottomOffset,
                        seismicCube.SpatialLattice.OriginalLattice, tstart, tstep, tend, out horSamples);
                    useHorizons = true;
                }

                // ------------------------ checks -------------------------------------

                // ------------------------ run -------------------------------------

                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot root = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = root.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Kohonen (SOM) Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                //write output
                SeismicCube facies_result;
                CubeFromPetrel[] cube_wrap = new CubeFromPetrel[volumeCubeList.Count];
                CubeFromPetrel facies_wrap = null;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    try
                    {
                        tr.Lock(scol);
                        facies_result = scol.CreateSeismicCube(volumeCubeList.First(), typeof(Single), PetrelProject.WellKnownTemplates.MiscellaneousGroup.FromFacies, volumeCubeList[0].ClippingRange);
                        facies_result.Name = "Facies Classes";
                        if (!string.IsNullOrEmpty(args.structure.cubeOutName))
                            facies_result.Name = args.structure.cubeOutName;
                        args.OutCube = facies_result;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                    if (useHorizons)
                    {
                        if (inlinePrevCB)
                        {
                            facies_wrap = new CubeFromPetrel(facies_result, Convert.ToInt32(inlinePrev), meanHor, horSamples);
                        }
                        else
                        {
                            facies_wrap = new CubeFromPetrel(facies_result, meanHor, horSamples, 10);
                        }
                    }
                    else
                    {
                        if (inlinePrevCB)
                        {
                            facies_wrap = new CubeFromPetrel(facies_result, Convert.ToInt32(inlinePrev), false);
                        }
                        else
                        {
                            facies_wrap = new CubeFromPetrel(facies_result, 10);
                        }
                    }
                }

                facies_wrap.prepareWriteToPetrel();

                int j = 0;
                foreach (var i in volumeCubeList)
                {   
                    if (useHorizons)
                    {
                        if (inlinePrevCB)
                            cube_wrap[j] = new CubeFromPetrel(i, Convert.ToInt32(inlinePrev), meanHor, horSamples, false);
                        else
                            cube_wrap[j] = new CubeFromPetrel(i, meanHor, horSamples);
                    }
                    else
                    {
                        if (inlinePrevCB)
                            cube_wrap[j] = new CubeFromPetrel(i, Convert.ToInt32(inlinePrev), false);
                        else
                            cube_wrap[j] = new CubeFromPetrel(i);
                    }
                    
                    ++j;
                }

                KohonenCLI.ParametersCLI p = new KohonenCLI.ParametersCLI();
                p.x_map = Convert.ToInt32(neuronsX);
                p.y_map = Convert.ToInt32(neuronsY);
                p.discretization_level = Convert.ToInt32(discretization);
                //p.retrain_net = retrainNetCB;
                p.retrain_net = true;
                p.wathershed = watershed;
                p.learning_rate = 0.01f;

                p.num_inlines = 2;
                p.num_crosslines = 10;
                p.num_zlines = 20;

                if (p.retrain_net || ktask == null)
                    ktask = new KohonenTaskSetup(ref cube_wrap, ref p, ref facies_wrap);
                List<KohonenTaskSetup> tasks = new List<KohonenTaskSetup>();
                tasks.Add(ktask);

                using (IProgress pbar = PetrelLogger.NewProgress(0, volumeCubeList.First().NumSamplesIJK.I * volumeCubeList.First().NumSamplesIJK.J))
                {
                    try
                    {
                        pbar.SetProgressText("Performing Kohonen Automatic Facies Classification");
                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doKohonenClassification, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    }
                    catch (Exception excep)
                    {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");
                PetrelLogger.InfoOutputWindow("Process complete");
            }

            private void doKohonenClassification(object objJob)
            {
                var task = (KohonenTaskSetup)objJob;
                task._statusMsg = "Reading data from input volumes";

                foreach (var c in task._cubes)
                {
                    c.readFromPetrel();
                }
                task._p.cubes = task._cubes;
                KohonenCLI k = new KohonenCLI(task._p);
                k.setSolver(100);
                task._statusMsg = "Training Network";
                task.kf = k;
                k.solve();
                task._cube_class_out.setCube(k.getFaciesCube());

                task._statusMsg = "Writing classification results";
                task._cube_class_out.writeToPetrel(ref task.progressPct);
;            }
        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for KohonenFaciesWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {
            public KohonenFaciesStruct structure;
            private SeismicCube outCube;

            [Description("Output Seismic Cube", "Output Seismic Cube")]
            public SeismicCube OutCube {
                get { return outCube; }
                internal set { outCube = value; }
            }

            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the KohonenFaciesWorkstep
        /// </summary>
        public IDescription Description {
            get { return KohonenFaciesWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the KohonenFaciesWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class KohonenFaciesWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static KohonenFaciesWorkstepDescription instance = new KohonenFaciesWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static KohonenFaciesWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of KohonenFaciesWorkstep
            /// </summary>
            public string Name {
                get { return "Self Organizing Maps (SOM)"; }
            }
            /// <summary>
            /// Gets the short description of KohonenFaciesWorkstep
            /// </summary>
            public string ShortDescription {
                get { return "Automatic Seismic Facies Classification with Kohonen Self Organizing Maps."; }
            }
            /// <summary>
            /// Gets the detailed description of KohonenFaciesWorkstep
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new KohonenFaciesWorkstepUI((KohonenFaciesWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}