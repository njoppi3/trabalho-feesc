﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slb.Ocean.Petrel;

namespace UFSC_Plugins
{
    public partial class FaciesTransitionMatrixUI : UserControl
    {
        List<string> priors = new List<string>();
        List<Color> colors = new List<Color>();
        List<string> colorsHtml = new List<string>();

        public FaciesTransitionMatrixUI()
        {
            InitializeComponent();
            colors.Add(Color.Magenta);
            colors.Add(Color.Red);
            colors.Add(Color.Green);
            colors.Add(Color.Blue);
            colors.Add(Color.Yellow);

            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.TopLeftHeaderCell.Value = @"From\To";
        }

        public void addPriors(int count)
        {
            List<string> priors = new List<string>();
            for (int i = 0; i < count; ++i)
            {
                priors.Add("Prior " + (i+1));
            }
            setPriors(priors);
        }

        public bool transitionMatrixOk()
        {
            for (int r = 0; r < dataGridView1.Rows.Count; ++r)
            {
                double sum = 0.0;
                for (int c = 0; c < dataGridView1.Columns.Count; ++c)
                {
                    sum += Convert.ToDouble(dataGridView1.Rows[r].Cells[c].Value.ToString());
                }
                if (sum != 1.00)
                {
                    PetrelLogger.ErrorBox("The sum of each transition matrix row must be equal to 1.");
                    return false;
                }
            }
            return true;
        }

        public void setColors(List<Color> colors)
        {
            this.colors = colors;
            colorsHtml.Clear();
            foreach (var color in colors)
            {
                colorsHtml.Add(System.Drawing.ColorTranslator.ToHtml(color));
            }
        }


        public void setColorsHtml(List<string> colorsHtml)
        {
            this.colorsHtml = colorsHtml;
            colors.Clear();
            foreach (var color in colorsHtml)
            {
                colors.Add(System.Drawing.ColorTranslator.FromHtml(color));
            }
        }

        public void setPriors(List<String> priorsName)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            String colName = "col_prior_";
            for (int i= 0; i < priorsName.Count; ++i)
            {
                dataGridView1.Columns.Add(colName+i, priorsName[i]);
                dataGridView1.Columns[i].HeaderCell.Style.BackColor = colors[i % colors.Count];
                if (!Functions.isTooLightYIQ(System.Drawing.ColorTranslator.ToHtml(colors[i % colors.Count])))
                    dataGridView1.Columns[i].HeaderCell.Style.ForeColor = Color.White;
            }

            List<string> row_vals = new List<string>();
            for (int i = 0; i < priorsName.Count; ++i)
            {
                double init_val = 1 / Convert.ToDouble(priorsName.Count);
                row_vals.Add(Convert.ToString(init_val.ToString("F2")));
            }

            for (int i = 0; i < priorsName.Count; ++i)
            {
                dataGridView1.Rows.Add(row_vals.ToArray());
                dataGridView1.Rows[i].HeaderCell.Value = priorsName[i];
                dataGridView1.Rows[i].HeaderCell.Style.BackColor = colors[i % colors.Count];
                if (!Functions.isTooLightYIQ(System.Drawing.ColorTranslator.ToHtml(colors[i % colors.Count])))
                    dataGridView1.Rows[i].HeaderCell.Style.ForeColor = Color.White;
            }
            if (priorsName.Count != 0)
            {
                dataGridView1.RowHeadersWidth = dataGridView1.Columns[0].Width;
                dataGridView1.Columns.Cast<DataGridViewColumn>().ToList().ForEach(f => f.SortMode = DataGridViewColumnSortMode.NotSortable);
            }
            priors = priorsName;
        }

        public DataGridView getTransitionMatrix()
        {
            return dataGridView1;
        }

        public double[,] getTransitionMatrixData()
        {
            double[,] tdata = new double[dataGridView1.RowCount, dataGridView1.ColumnCount];
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                {
                    tdata[i, j] = Convert.ToDouble(dataGridView1.Rows[i].Cells[j].Value.ToString());
                }
            }
            return tdata;
        }

        public void setTransitionMatrixData(double[,] data)
        {
            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int j = 0; j < data.GetLength(1); j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = data[i, j].ToString("F2");
                }
            }
        }

        public List<string> getPriorsName()
        {
            return priors;
        }

        public List<Color> getColors()
        {
            return colors;
        }

        public List<string> getColorsHtml()
        {
            return colorsHtml;
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double val;
            if (!Double.TryParse(dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString(), out val))
            {
                PetrelLogger.ErrorBox("Only number");
                dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "0";
                return;
            }
        }
    }
}
