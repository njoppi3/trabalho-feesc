﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class ImpPorTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel _cubeseis;
        public CubeFromPetrel[] _cubetrend;
        public ImpporCLI.ParametersCLI _p;
        public CubeFromPetrel _cuberesidout;
        public CubeFromPetrel[] _cube_ippor_out;
        public int progressPct = 0;
        public String _statusMsg = "";
        public double[] _wavelet;
        public double srate = 0.004;
        public ImpporCLI imppori = null;

        public ImpPorTaskSetup(ref CubeFromPetrel seis, ref CubeFromPetrel[] trend,
            ref ImpporCLI.ParametersCLI pars, ref CubeFromPetrel[] ipporOut, ref CubeFromPetrel resid_out,
            ref double[] wavelet)
        {
            _cubeseis = seis;
            _cubetrend = trend;
            _p = pars;
            _cuberesidout = resid_out;
            _cube_ippor_out = ipporOut;
            _wavelet = wavelet;
        }

        public int progress()
        {
            if (imppori != null)
            {
                int prog = 0;//= imppori.getProgress();
                return prog;
            }
            return 0;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}
