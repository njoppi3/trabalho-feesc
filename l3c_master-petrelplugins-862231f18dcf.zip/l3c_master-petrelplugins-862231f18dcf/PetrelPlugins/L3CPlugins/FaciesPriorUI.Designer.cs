﻿namespace UFSC_Plugins
{
    partial class FaciesPriorUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewFacies = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFacies)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewFacies
            // 
            this.dataGridViewFacies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFacies.Location = new System.Drawing.Point(4, 4);
            this.dataGridViewFacies.Name = "dataGridViewFacies";
            this.dataGridViewFacies.Size = new System.Drawing.Size(419, 230);
            this.dataGridViewFacies.TabIndex = 0;
            // 
            // FaciesPriorUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridViewFacies);
            this.Name = "FaciesPriorUI";
            this.Size = new System.Drawing.Size(467, 300);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFacies)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewFacies;
    }
}
