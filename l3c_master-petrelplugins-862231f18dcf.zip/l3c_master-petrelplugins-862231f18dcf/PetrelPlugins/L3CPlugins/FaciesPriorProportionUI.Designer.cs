﻿namespace UFSC_Plugins
{
    partial class FaciesPriorProportionUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.gridPropPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.inputGridDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.zonePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.inputZoneDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.dataGridViewZoneFacies = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewZones = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radioButtonGrid = new System.Windows.Forms.RadioButton();
            this.comboBoxFacies = new System.Windows.Forms.ComboBox();
            this.cubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.labelFacie = new System.Windows.Forms.Label();
            this.inputCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.dataGridViewPrior = new System.Windows.Forms.DataGridView();
            this.ColumnProb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radioButtonCube = new System.Windows.Forms.RadioButton();
            this.radioButtonPrior = new System.Windows.Forms.RadioButton();
            this.dataGridViewCube = new System.Windows.Forms.DataGridView();
            this.ColumnCubeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnFacie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZoneFacies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCube)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.gridPropPresentationBox);
            this.panel1.Controls.Add(this.inputGridDrop);
            this.panel1.Controls.Add(this.zonePresentationBox);
            this.panel1.Controls.Add(this.inputZoneDrop);
            this.panel1.Controls.Add(this.dataGridViewZoneFacies);
            this.panel1.Controls.Add(this.dataGridViewZones);
            this.panel1.Controls.Add(this.radioButtonGrid);
            this.panel1.Controls.Add(this.comboBoxFacies);
            this.panel1.Controls.Add(this.cubePresentationBox);
            this.panel1.Controls.Add(this.buttonRemove);
            this.panel1.Controls.Add(this.buttonAdd);
            this.panel1.Controls.Add(this.labelFacie);
            this.panel1.Controls.Add(this.inputCubeDrop);
            this.panel1.Controls.Add(this.dataGridViewPrior);
            this.panel1.Controls.Add(this.radioButtonCube);
            this.panel1.Controls.Add(this.radioButtonPrior);
            this.panel1.Controls.Add(this.dataGridViewCube);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(408, 132);
            this.panel1.TabIndex = 0;
            // 
            // gridPropPresentationBox
            // 
            this.gridPropPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridPropPresentationBox.Location = new System.Drawing.Point(39, 49);
            this.gridPropPresentationBox.Name = "gridPropPresentationBox";
            this.gridPropPresentationBox.Size = new System.Drawing.Size(103, 22);
            this.gridPropPresentationBox.TabIndex = 43;
            this.gridPropPresentationBox.TabStop = false;
            this.gridPropPresentationBox.Visible = false;
            // 
            // inputGridDrop
            // 
            this.inputGridDrop.AllowDrop = true;
            this.inputGridDrop.Location = new System.Drawing.Point(3, 49);
            this.inputGridDrop.Name = "inputGridDrop";
            this.inputGridDrop.Size = new System.Drawing.Size(24, 22);
            this.inputGridDrop.TabIndex = 42;
            this.inputGridDrop.Visible = false;
            this.inputGridDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputCubeDrop_DragDrop);
            // 
            // zonePresentationBox
            // 
            this.zonePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zonePresentationBox.Location = new System.Drawing.Point(39, 77);
            this.zonePresentationBox.Name = "zonePresentationBox";
            this.zonePresentationBox.Size = new System.Drawing.Size(103, 22);
            this.zonePresentationBox.TabIndex = 41;
            this.zonePresentationBox.TabStop = false;
            this.zonePresentationBox.Visible = false;
            // 
            // inputZoneDrop
            // 
            this.inputZoneDrop.AllowDrop = true;
            this.inputZoneDrop.Location = new System.Drawing.Point(3, 77);
            this.inputZoneDrop.Name = "inputZoneDrop";
            this.inputZoneDrop.Size = new System.Drawing.Size(24, 22);
            this.inputZoneDrop.TabIndex = 40;
            this.inputZoneDrop.Visible = false;
            this.inputZoneDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputZoneDrop_DragDrop);
            // 
            // dataGridViewZoneFacies
            // 
            this.dataGridViewZoneFacies.AllowUserToAddRows = false;
            this.dataGridViewZoneFacies.AllowUserToDeleteRows = false;
            this.dataGridViewZoneFacies.AllowUserToResizeColumns = false;
            this.dataGridViewZoneFacies.AllowUserToResizeRows = false;
            this.dataGridViewZoneFacies.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewZoneFacies.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewZoneFacies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewZoneFacies.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2});
            this.dataGridViewZoneFacies.Location = new System.Drawing.Point(267, 3);
            this.dataGridViewZoneFacies.Name = "dataGridViewZoneFacies";
            this.dataGridViewZoneFacies.Size = new System.Drawing.Size(133, 120);
            this.dataGridViewZoneFacies.TabIndex = 39;
            this.dataGridViewZoneFacies.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Facies";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewZones
            // 
            this.dataGridViewZones.AllowUserToAddRows = false;
            this.dataGridViewZones.AllowUserToDeleteRows = false;
            this.dataGridViewZones.AllowUserToResizeColumns = false;
            this.dataGridViewZones.AllowUserToResizeRows = false;
            this.dataGridViewZones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewZones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewZones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dataGridViewZones.Location = new System.Drawing.Point(148, 3);
            this.dataGridViewZones.Name = "dataGridViewZones";
            this.dataGridViewZones.Size = new System.Drawing.Size(113, 120);
            this.dataGridViewZones.TabIndex = 38;
            this.dataGridViewZones.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Zones";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // radioButtonGrid
            // 
            this.radioButtonGrid.AutoSize = true;
            this.radioButtonGrid.Location = new System.Drawing.Point(56, 26);
            this.radioButtonGrid.Name = "radioButtonGrid";
            this.radioButtonGrid.Size = new System.Drawing.Size(86, 17);
            this.radioButtonGrid.TabIndex = 37;
            this.radioButtonGrid.Text = "Grid Property";
            this.radioButtonGrid.UseVisualStyleBackColor = true;
            this.radioButtonGrid.CheckedChanged += new System.EventHandler(this.radioButtonGrid_CheckedChanged);
            // 
            // comboBoxFacies
            // 
            this.comboBoxFacies.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFacies.FormattingEnabled = true;
            this.comboBoxFacies.Location = new System.Drawing.Point(50, 77);
            this.comboBoxFacies.Name = "comboBoxFacies";
            this.comboBoxFacies.Size = new System.Drawing.Size(92, 21);
            this.comboBoxFacies.TabIndex = 36;
            this.comboBoxFacies.Visible = false;
            // 
            // cubePresentationBox
            // 
            this.cubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cubePresentationBox.Location = new System.Drawing.Point(39, 49);
            this.cubePresentationBox.Name = "cubePresentationBox";
            this.cubePresentationBox.Size = new System.Drawing.Size(103, 22);
            this.cubePresentationBox.TabIndex = 35;
            this.cubePresentationBox.TabStop = false;
            this.cubePresentationBox.Visible = false;
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(82, 102);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(60, 23);
            this.buttonRemove.TabIndex = 34;
            this.buttonRemove.Text = "Remove";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Visible = false;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(6, 102);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(60, 23);
            this.buttonAdd.TabIndex = 33;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Visible = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // labelFacie
            // 
            this.labelFacie.AutoSize = true;
            this.labelFacie.Location = new System.Drawing.Point(3, 80);
            this.labelFacie.Name = "labelFacie";
            this.labelFacie.Size = new System.Drawing.Size(41, 13);
            this.labelFacie.TabIndex = 31;
            this.labelFacie.Text = "Facies:";
            this.labelFacie.Visible = false;
            // 
            // inputCubeDrop
            // 
            this.inputCubeDrop.AllowDrop = true;
            this.inputCubeDrop.Location = new System.Drawing.Point(3, 49);
            this.inputCubeDrop.Name = "inputCubeDrop";
            this.inputCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.inputCubeDrop.TabIndex = 28;
            this.inputCubeDrop.Visible = false;
            this.inputCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputCubeDrop_DragDrop);
            // 
            // dataGridViewPrior
            // 
            this.dataGridViewPrior.AllowUserToAddRows = false;
            this.dataGridViewPrior.AllowUserToDeleteRows = false;
            this.dataGridViewPrior.AllowUserToResizeColumns = false;
            this.dataGridViewPrior.AllowUserToResizeRows = false;
            this.dataGridViewPrior.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewPrior.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrior.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrior.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnProb});
            this.dataGridViewPrior.Location = new System.Drawing.Point(148, 3);
            this.dataGridViewPrior.Name = "dataGridViewPrior";
            this.dataGridViewPrior.Size = new System.Drawing.Size(252, 120);
            this.dataGridViewPrior.TabIndex = 27;
            this.dataGridViewPrior.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPrior_CellEndEdit);
            // 
            // ColumnProb
            // 
            this.ColumnProb.HeaderText = "Proportion";
            this.ColumnProb.Name = "ColumnProb";
            this.ColumnProb.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // radioButtonCube
            // 
            this.radioButtonCube.AutoSize = true;
            this.radioButtonCube.Location = new System.Drawing.Point(3, 26);
            this.radioButtonCube.Name = "radioButtonCube";
            this.radioButtonCube.Size = new System.Drawing.Size(50, 17);
            this.radioButtonCube.TabIndex = 26;
            this.radioButtonCube.Text = "Cube";
            this.radioButtonCube.UseVisualStyleBackColor = true;
            this.radioButtonCube.CheckedChanged += new System.EventHandler(this.radioButtonCube_CheckedChanged);
            // 
            // radioButtonPrior
            // 
            this.radioButtonPrior.AutoSize = true;
            this.radioButtonPrior.Checked = true;
            this.radioButtonPrior.Location = new System.Drawing.Point(3, 3);
            this.radioButtonPrior.Name = "radioButtonPrior";
            this.radioButtonPrior.Size = new System.Drawing.Size(96, 17);
            this.radioButtonPrior.TabIndex = 25;
            this.radioButtonPrior.TabStop = true;
            this.radioButtonPrior.Text = "Prior proportion";
            this.radioButtonPrior.UseVisualStyleBackColor = true;
            this.radioButtonPrior.CheckedChanged += new System.EventHandler(this.radioButtonPrior_CheckedChanged);
            // 
            // dataGridViewCube
            // 
            this.dataGridViewCube.AllowUserToAddRows = false;
            this.dataGridViewCube.AllowUserToDeleteRows = false;
            this.dataGridViewCube.AllowUserToResizeColumns = false;
            this.dataGridViewCube.AllowUserToResizeRows = false;
            this.dataGridViewCube.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewCube.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCube.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCube.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnCubeName,
            this.ColumnFacie});
            this.dataGridViewCube.Location = new System.Drawing.Point(148, 3);
            this.dataGridViewCube.Name = "dataGridViewCube";
            this.dataGridViewCube.ReadOnly = true;
            this.dataGridViewCube.Size = new System.Drawing.Size(252, 120);
            this.dataGridViewCube.TabIndex = 29;
            this.dataGridViewCube.Visible = false;
            // 
            // ColumnCubeName
            // 
            this.ColumnCubeName.HeaderText = "Name";
            this.ColumnCubeName.Name = "ColumnCubeName";
            this.ColumnCubeName.ReadOnly = true;
            // 
            // ColumnFacie
            // 
            this.ColumnFacie.HeaderText = "Facies";
            this.ColumnFacie.Name = "ColumnFacie";
            this.ColumnFacie.ReadOnly = true;
            // 
            // FaciesPriorProportionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "FaciesPriorProportionUI";
            this.Size = new System.Drawing.Size(408, 132);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZoneFacies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCube)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridViewPrior;
        private System.Windows.Forms.RadioButton radioButtonCube;
        private System.Windows.Forms.RadioButton radioButtonPrior;
        private Slb.Ocean.Petrel.UI.DropTarget inputCubeDrop;
        private System.Windows.Forms.DataGridView dataGridViewCube;
        private System.Windows.Forms.Button buttonRemove;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label labelFacie;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox cubePresentationBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCubeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnFacie;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnProb;
        private System.Windows.Forms.ComboBox comboBoxFacies;
        private System.Windows.Forms.RadioButton radioButtonGrid;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox zonePresentationBox;
        private Slb.Ocean.Petrel.UI.DropTarget inputZoneDrop;
        private System.Windows.Forms.DataGridView dataGridViewZoneFacies;
        private System.Windows.Forms.DataGridView dataGridViewZones;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn2;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox gridPropPresentationBox;
        private Slb.Ocean.Petrel.UI.DropTarget inputGridDrop;
    }
}
