﻿using UFSC_Plugins;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.Basics;
using Slb.Ocean.Petrel.Data;
using Slb.Ocean.Petrel.Data.Persistence;
using Slb.Ocean.Petrel.UI;
using System;

namespace UFSC_Plugins {
    [Archivable]
    public class GenericDomainObject : IIdentifiable, INameInfoSource, IDeletable {
        [Archived]
        private string name;
        [Archived]
        private string parameters;
        [Archived]
        private string type;

        [ArchivableContextInject]
        public StructuredArchiveDataSource dataSource { get; private set; }

        [Archived]
        public Droid Droid {get; private set;}

        public GenericDomainObject(StructuredArchiveDataSource ds, string name, string type, string parameters) {
            this.name = name;
            this.type = type;
            this.parameters = parameters;

            this.dataSource = ds;
            Droid = ds.GenerateDroid();
            ds.AddItem(Droid, this);
        }

        public GenericDomainObject(StructuredArchiveDataSource ds, string name, string type, string parameters, Droid droid) {
            this.name = name;
            this.type = type;
            this.parameters = parameters;
            this.dataSource = ds;
            Droid = droid;
            try {
                ds.AddItem(Droid, this);
            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * set the name of the object in de tree
         */
        public NameInfo NameInfo {
            get {
                return new DefaultNameInfo(name);
            }
        }

        /**
         * set object to deletable
         */
        public DeletableInfo DeletableInfo {
            get {
                return new DeletableInfo();
            }
        }

        public void Delete() {
            if (Deleted != null) {
                Deleted(this, new EventArgs());
            }
        }
        public event EventHandler Deleted;

        /**
         * set the parameter (JSON)
         */
        public string Parameters {
            get {
                return parameters;
            }
            set {
                parameters = value;
            }
        }

        /**
         * set the type
         */
        public string Type {
            get {
                return type;
            }
            set {
                type = value;
            }
        }

    }

    class GenericDataSourceFactory : DataSourceFactory {
        private static string DataSourceId = "GenericDS";
        public static StructuredArchiveDataSource Get(
        IDataSourceManager dsm) {
            return dsm.GetSource(DataSourceId) as
            StructuredArchiveDataSource;
        }
        public override IDataSource GetDataSource() {
            StructuredArchiveDataSource dataSource =
            new StructuredArchiveDataSource(DataSourceId,
            new[] { typeof(GenericDomainObject) });
            return dataSource;
        }
    }

}