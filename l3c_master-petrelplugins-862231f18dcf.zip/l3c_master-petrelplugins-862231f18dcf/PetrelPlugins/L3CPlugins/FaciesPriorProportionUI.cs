﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject.PillarGrid;
using Slb.Ocean.Petrel.PropertyModeling;
using Slb.Ocean.Petrel.Modeling;

namespace UFSC_Plugins
{
    public partial class FaciesPriorProportionUI : UserControl
    {
        public List<string> priors = new List<string>();
        public List<Droid> cubes = new List<Droid>();
        public List<Droid> zones = new List<Droid>();
        public List<string> gridFacies = new List<string>();
        Droid cubeDroidTemp = null;
        Droid gridPropertyDroidTemp = null;
        Droid zoneDroidTemp = null;
        List<Color> colors = new List<Color>();
        List<string> colorsHtml = new List<string>();

        public FaciesPriorProportionUI()
        {
            InitializeComponent();
            dataGridViewPrior.EnableHeadersVisualStyles = false;
            dataGridViewZoneFacies.EnableHeadersVisualStyles = false;
            colors.Add(Color.Magenta);
            colors.Add(Color.Red);
            colors.Add(Color.Green);
            colors.Add(Color.Blue);
            colors.Add(Color.Yellow);
            dataGridViewCube.Columns.Cast<DataGridViewColumn>().ToList().ForEach(f => f.SortMode = DataGridViewColumnSortMode.NotSortable);
        }

        public bool isInWorkflow()
        {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        public bool proportionOk()
        {
            if (faciesProportionSelected())
            {
                double sum = dataGridViewPrior.Rows.Cast<DataGridViewRow>().Sum(t => Convert.ToDouble(t.Cells[0].Value));
                if (sum != 1.00)
                {
                    PetrelLogger.ErrorBox("The sum of facies proportion must be equal to 1.");
                    return false;
                }
            } else if (cubeSelected())
            {
                if (cubes.Count != priors.Count)
                {
                    PetrelLogger.ErrorBox("Please, select a volume for each Facies/Priors.");
                    return false;
                }
            } else if (gridPropertySelected())
            {
                if (gridPropertyDroidTemp == null)
                {
                    PetrelLogger.ErrorBox("Please, select a Grid Property Facies.");
                    return false;
                }
                if (zones.Count == 0)
                {
                    PetrelLogger.ErrorBox("Please, select at least one Grid Zone.");
                    return false;
                }
                if (gridFacies.Count != priors.Count)
                {
                    PetrelLogger.ErrorBox("The Grid Property has less facies than defined facies priors.");
                    return false;
                }
            }
            return true;
        }

        public bool faciesProportionSelected()
        {
            return radioButtonPrior.Checked;
        }

        public bool cubeSelected()
        {
            return radioButtonCube.Checked;
        }

        public bool gridPropertySelected()
        {
            return radioButtonGrid.Checked;
        }

        public void setColors(List<Color> colors)
        {
            this.colors = colors;
            colorsHtml.Clear();
            foreach (var color in colors)
            {
                colorsHtml.Add(System.Drawing.ColorTranslator.ToHtml(color));
            }
        }

        public void setColorsHtml(List<string> colorsHtml)
        {
            this.colorsHtml = colorsHtml;
            colors.Clear();
            foreach (var color in colorsHtml)
            {
                colors.Add(System.Drawing.ColorTranslator.FromHtml(color));
            }
        }

        public void setPriors(List<string> priorsName)
        {
            dataGridViewPrior.Rows.Clear();
            dataGridViewCube.Rows.Clear();
            dataGridViewZoneFacies.Rows.Clear();
            cubes.Clear();
            comboBoxFacies.Items.Clear();
            for (int i = 0; i < priorsName.Count; ++i)
            {
                // Prior
                double init_val = 1 / Convert.ToDouble(priorsName.Count);
                dataGridViewPrior.Rows.Add(init_val.ToString("F2"));
                dataGridViewPrior.Rows[i].HeaderCell.Value = priorsName[i];
                dataGridViewPrior.Rows[i].HeaderCell.Style.BackColor = colors[i % colors.Count];
                if (!Functions.isTooLightYIQ(System.Drawing.ColorTranslator.ToHtml(colors[i % colors.Count])))
                    dataGridViewPrior.Rows[i].HeaderCell.Style.ForeColor = Color.White;
                
                // Cube
                comboBoxFacies.Items.Add(priorsName[i]);
                comboBoxFacies.SelectedIndex = 0;

                //Grid
                dataGridViewZones.RowHeadersVisible = false;
                dataGridViewZoneFacies.Rows.Add("");
                dataGridViewZoneFacies.Rows[i].HeaderCell.Value = priorsName[i];
                dataGridViewZoneFacies.Rows[i].HeaderCell.Style.BackColor = colors[i % colors.Count];
                if (!Functions.isTooLightYIQ(System.Drawing.ColorTranslator.ToHtml(colors[i % colors.Count])))
                    dataGridViewZoneFacies.Rows[i].HeaderCell.Style.ForeColor = Color.White;
                matchPriorGridDictFacies();
            }
            
            dataGridViewPrior.RowHeadersWidth = dataGridViewPrior.Width/2;
            dataGridViewPrior.Columns.Cast<DataGridViewColumn>().ToList().ForEach(f => f.SortMode = DataGridViewColumnSortMode.NotSortable);
            dataGridViewZoneFacies.RowHeadersWidth = dataGridViewZoneFacies.Width/2;
            priors = priorsName;
        }

        public void setProportions(List<double> values)
        {
            for (int i = 0; i < values.Count; i++)
            {
                dataGridViewPrior.Rows[i].Cells[0].Value = values[i].ToString("F2");
            }
        }

        public void setCubeProportions(Dictionary<string, string> cube_facies)
        {
            dataGridViewCube.Rows.Clear();
            cubes.Clear();
            foreach (var cf in cube_facies)
            {
                Droid d = new Droid(cf.Key);
                dataGridViewCube.Rows.Add(Functions.getCube(d).Name, cf.Value);
                cubes.Add(d);
            }
        }

        public void setGridDictProp(string droid)
        {
            DictionaryProperty prop = Functions.getDictProperty(new Droid(droid));
            if (prop != null) {
                gridPropertyDroidTemp = prop.Droid;
                gridPropPresentationBox.Text = prop.Name;
                fillFaciesZone(prop.Droid);
            }
            radioButtonGrid.Checked = true;
        }

        public void setZones(List<string> zonesDroid)
        {
            zones.Clear();
            dataGridViewZones.Rows.Clear();
            foreach (var zd in zonesDroid)
            {
                Zone zone = Functions.getZone(new Droid(zd));
                if (zone != null) {
                    zones.Add(zone.Droid);
                }
                dataGridViewZones.Rows.Add(zone.Name);
            }
            matchPriorGridDictFacies();
        }

        public void setPriorGridFacies(Dictionary<string, string> priorGridFacies)
        {
            //TODO
        }

        public List<double> getProportions()
        {
            List<double> props = new List<double>();
            foreach (DataGridViewRow row in dataGridViewPrior.Rows)
                props.Add(Convert.ToDouble(row.Cells[0].Value.ToString()));
            return props;
        }

        public Dictionary<string, double> getFaciesProportion()
        {
            var result = new Dictionary<string, double>();
            for (int i = 0; i < priors.Count && i < getProportions().Count; ++i)
                result.Add(priors[i], getProportions()[i]);
            return result;
        }

        public Dictionary<string, string> getCubeFaciesProportion()
        {
            var result = new Dictionary<string, string>();
            for (int p = 0; p < priors.Count; ++p)
            {
                for (int i = 0; i < dataGridViewCube.Rows.Count; ++i)
                {
                    if (priors[p].Equals(dataGridViewCube.Rows[i].Cells[1].Value.ToString()))
                    {
                        result.Add(cubes[i].ToString(), priors[p]);
                        break;
                    }
                }
            }
            return result;
        }

        public List<string> getZones()
        {
            return zones.ConvertAll(x => x.ToString());
        }

        public Dictionary<string, string> getPriorGridFacies()
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            for (int r = 0; r < dataGridViewZoneFacies.Rows.Count; ++r)
            {
                DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)dataGridViewZoneFacies.Rows[r].Cells[0];
                result.Add(dataGridViewZoneFacies.Rows[r].HeaderCell.Value.ToString(), cell.Value.ToString());
            }
            return result;
        }

        public List<Color> getColors()
        {
            return colors;
        }

        public List<string> getColorsHtml()
        {
            return colorsHtml;
        }

        public string getGridDictPropDroid()
        {
            if (gridPropertyDroidTemp != null)
                return gridPropertyDroidTemp.ToString();
            return null;
        }

        private void radioButtonPrior_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonPrior.Checked)
            {
                setPriorOptsVisible(true);
                setCubeOptsVisible(false);
                setGridOptsVisible(false);
            }
        }

        private void radioButtonCube_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonCube.Checked)
            {
                setPriorOptsVisible(false);
                setCubeOptsVisible(true);
                setGridOptsVisible(false);
            }
        }

        private void radioButtonGrid_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonGrid.Checked)
            {
                setPriorOptsVisible(false);
                setCubeOptsVisible(false);
                setGridOptsVisible(true);
            }
        }

        private void inputCubeDrop_DragDrop(object sender, DragEventArgs e)
        {
            object dropped = e.Data.GetData(typeof(object));
            if (radioButtonCube.Checked)
            {
                Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp == null)
                {
                    PetrelLogger.ErrorBox("Please, select a seismic cube.");
                    return;
                }
                cubePresentationBox.Text = cubeTemp.Name;
                cubeDroidTemp = cubeTemp.Droid;
            } else if (radioButtonGrid.Checked)
            {
                Droid droidObj = Functions.dragDropDictProperty(isInWorkflow(), dropped);

                DictionaryProperty property = Functions.getDictProperty(droidObj);
                if (property == null)
                {
                    PetrelLogger.ErrorBox("Please, select a grid property.");
                    return;
                }
                gridPropPresentationBox.Text = property.Name;
                gridPropertyDroidTemp = property.Droid;
                fillFaciesZone(gridPropertyDroidTemp);
            }
        }

        private void inputZoneDrop_DragDrop(object sender, DragEventArgs e)
        {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropZone(isInWorkflow(), dropped);

            Zone zone = Functions.getZone(droidObj);
            if (zone == null)
            {
                PetrelLogger.ErrorBox("Please, select a grid zone.");
                return;
            }
            zonePresentationBox.Text = zone.Name;
            zoneDroidTemp = zone.Droid;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (cubeSelected())
            {
                if (cubeDroidTemp == null)
                {
                    PetrelLogger.ErrorBox("Please, select a seismic cube.");
                    return;
                }
                if (comboBoxFacies.Items.Count <= 0)
                {
                    PetrelLogger.ErrorBox("Please, select a facies related to seismic cube.");
                    return;
                }
                if (cubes.Contains(cubeDroidTemp))
                {
                    PetrelLogger.ErrorBox("This cube was already selected.");
                    return;
                }
                for (int i = 0; i < dataGridViewCube.Rows.Count; i++)
                {
                    if (dataGridViewCube.Rows[i].Cells[1].Value.ToString() == comboBoxFacies.SelectedItem.ToString())
                    {
                        PetrelLogger.ErrorBox("This facies was already selected.");
                        return;
                    }
                }
                cubes.Add(cubeDroidTemp);
                dataGridViewCube.Rows.Add(Functions.getCube(cubeDroidTemp).Name, comboBoxFacies.SelectedItem.ToString());
                cubeDroidTemp = null;
                cubePresentationBox.Text = "";
            } else if (gridPropertySelected())
            {
                if (zoneDroidTemp == null)
                {
                    PetrelLogger.ErrorBox("Please, select a grid zone.");
                    return;
                }
                if (gridPropertyDroidTemp == null)
                {
                    PetrelLogger.ErrorBox("Please, select a grid property.");
                    return;
                }
                if (zones.Contains(zoneDroidTemp))
                {
                    PetrelLogger.ErrorBox("This zone was already selected.");
                    return;
                }
                
                zones.Add(zoneDroidTemp);
                dataGridViewZones.Rows.Add(Functions.getZone(zoneDroidTemp).Name);
                zoneDroidTemp = null;
                zonePresentationBox.Text = "";
            }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (cubeSelected())
                {
                    int selIdx = dataGridViewCube.CurrentRow.Index;
                    if (selIdx > -1)
                    {
                        dataGridViewCube.Rows.RemoveAt(selIdx);
                        cubes.RemoveAt(selIdx);
                        dataGridViewCube.Refresh();
                    }
                } else if (gridPropertySelected())
                {
                    int selIdx = dataGridViewZones.CurrentRow.Index;
                    if (selIdx > -1)
                    {
                        dataGridViewZones.Rows.RemoveAt(selIdx);
                        zones.RemoveAt(selIdx);
                        dataGridViewZones.Refresh();
                    }
                }
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox(except.Message);
                return;
            }
        }

        private void dataGridViewPrior_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double val;
            if (!Double.TryParse(dataGridViewPrior.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString(), out val))
            {
                PetrelLogger.ErrorBox("Only number");
                dataGridViewPrior.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "0";
                return;
            }
        }

        private void fillFaciesZone(Droid dictDroid)
        {
            DictionaryProperty dp = Functions.getDictProperty(dictDroid);
            DataGridViewComboBoxColumn fcol = (DataGridViewComboBoxColumn)dataGridViewZoneFacies.Columns[0];
            List<string> items = (List<string>)fcol.DataSource;
            if (items == null)
                items = new List<string>();

            for(int i = dp.Min; i<= dp.Max; ++i)
                if (!items.Contains(dp.GetFaciesCodeName(i)))
                    items.Add(dp.GetFaciesCodeName(i));
            fcol.DataSource = items;
            gridFacies = items;
            dataGridViewZoneFacies.Refresh();
            matchPriorGridDictFacies();
        }

        private void matchPriorGridDictFacies()
        {
            if (gridPropertySelected() && gridPropertyDroidTemp != null)
                for (int i = 0; i < dataGridViewZoneFacies.Rows.Count; ++i)
                {
                    string fname = dataGridViewZoneFacies.Rows[i].HeaderCell.Value.ToString();
                    DataGridViewComboBoxCell cell = (DataGridViewComboBoxCell)dataGridViewZoneFacies.Rows[i].Cells[0];
                    if (cell != null)
                    {
                        cell.Value = fname;
                        //cell.ReadOnly = true;
                    }
                }
        }

        private void setPriorOptsVisible(bool value)
        {
            // Prior opts
            dataGridViewPrior.Visible = value;
        }

        private void setCubeOptsVisible(bool value)
        {
            //Cube opts
            dataGridViewCube.Visible = value;
            inputCubeDrop.Visible = value;
            cubePresentationBox.Visible = value;
            labelFacie.Visible = value;
            comboBoxFacies.Visible = value;
            buttonAdd.Visible = value;
            buttonRemove.Visible = value;

        }

        private void setGridOptsVisible(bool value)
        {
            // Grid opts
            inputGridDrop.Visible = value;
            gridPropPresentationBox.Visible = value;
            dataGridViewZones.Visible = value;
            dataGridViewZoneFacies.Visible = value;
            inputZoneDrop.Visible = value;
            zonePresentationBox.Visible = value;
            buttonAdd.Visible = value;
            buttonRemove.Visible = value;
        }
    }


}
