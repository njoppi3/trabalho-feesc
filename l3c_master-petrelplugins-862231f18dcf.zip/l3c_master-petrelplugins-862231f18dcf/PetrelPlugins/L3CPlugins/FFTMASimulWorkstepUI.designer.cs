namespace UFSC_Plugins
{
    partial class FFTMASimulWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.azimuthUpDown = new System.Windows.Forms.NumericUpDown();
            this.dipUpDown = new System.Windows.Forms.NumericUpDown();
            this.rakeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.realizationsUpDown = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.stdDeviationUpDown = new System.Windows.Forms.NumericUpDown();
            this.realizationsSaveUpDown = new System.Windows.Forms.NumericUpDown();
            this.zRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.crosslineRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.maxThresholdUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlineRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.meanDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.meanPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.wellLogSelect1 = new UFSC_Plugins.WellLogSelect();
            this.prevKringCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.varianceKringPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.meanKringPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.label13 = new System.Windows.Forms.Label();
            this.varianceKringDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label16 = new System.Windows.Forms.Label();
            this.meanKringDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.saveButton = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.okButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.azimuthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dipUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rakeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realizationsUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stdDeviationUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.realizationsSaveUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.crosslineRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxThresholdUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineRangeUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // azimuthUpDown
            // 
            this.azimuthUpDown.DecimalPlaces = 2;
            this.azimuthUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.azimuthUpDown.Location = new System.Drawing.Point(359, 76);
            this.azimuthUpDown.Name = "azimuthUpDown";
            this.azimuthUpDown.Size = new System.Drawing.Size(98, 20);
            this.azimuthUpDown.TabIndex = 6;
            // 
            // dipUpDown
            // 
            this.dipUpDown.DecimalPlaces = 2;
            this.dipUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dipUpDown.Location = new System.Drawing.Point(359, 50);
            this.dipUpDown.Name = "dipUpDown";
            this.dipUpDown.Size = new System.Drawing.Size(98, 20);
            this.dipUpDown.TabIndex = 5;
            // 
            // rakeUpDown
            // 
            this.rakeUpDown.DecimalPlaces = 2;
            this.rakeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rakeUpDown.Location = new System.Drawing.Point(359, 24);
            this.rakeUpDown.Name = "rakeUpDown";
            this.rakeUpDown.Size = new System.Drawing.Size(98, 20);
            this.rakeUpDown.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(287, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 78;
            this.label5.Text = "Azimuth (�)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 13);
            this.label9.TabIndex = 84;
            this.label9.Text = "Realizations";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(287, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 77;
            this.label6.Text = "Dip (�)";
            // 
            // realizationsUpDown
            // 
            this.realizationsUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.realizationsUpDown.Location = new System.Drawing.Point(126, 46);
            this.realizationsUpDown.Name = "realizationsUpDown";
            this.realizationsUpDown.Size = new System.Drawing.Size(331, 20);
            this.realizationsUpDown.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(287, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 76;
            this.label7.Text = "Rake (�)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 79);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 13);
            this.label10.TabIndex = 86;
            this.label10.Text = "Realizations to save";
            // 
            // stdDeviationUpDown
            // 
            this.stdDeviationUpDown.DecimalPlaces = 2;
            this.stdDeviationUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stdDeviationUpDown.Location = new System.Drawing.Point(126, 102);
            this.stdDeviationUpDown.Maximum = new decimal(new int[] {
            -402653185,
            -1613725636,
            54210108,
            0});
            this.stdDeviationUpDown.Name = "stdDeviationUpDown";
            this.stdDeviationUpDown.Size = new System.Drawing.Size(126, 20);
            this.stdDeviationUpDown.TabIndex = 3;
            // 
            // realizationsSaveUpDown
            // 
            this.realizationsSaveUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.realizationsSaveUpDown.Location = new System.Drawing.Point(126, 72);
            this.realizationsSaveUpDown.Name = "realizationsSaveUpDown";
            this.realizationsSaveUpDown.Size = new System.Drawing.Size(331, 20);
            this.realizationsSaveUpDown.TabIndex = 2;
            // 
            // zRangeUpDown
            // 
            this.zRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zRangeUpDown.Location = new System.Drawing.Point(126, 76);
            this.zRangeUpDown.Name = "zRangeUpDown";
            this.zRangeUpDown.Size = new System.Drawing.Size(126, 20);
            this.zRangeUpDown.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(13, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 13);
            this.label11.TabIndex = 88;
            this.label11.Text = "Maximum threshold";
            // 
            // crosslineRangeUpDown
            // 
            this.crosslineRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crosslineRangeUpDown.Location = new System.Drawing.Point(126, 50);
            this.crosslineRangeUpDown.Name = "crosslineRangeUpDown";
            this.crosslineRangeUpDown.Size = new System.Drawing.Size(126, 20);
            this.crosslineRangeUpDown.TabIndex = 1;
            // 
            // maxThresholdUpDown
            // 
            this.maxThresholdUpDown.DecimalPlaces = 2;
            this.maxThresholdUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxThresholdUpDown.Location = new System.Drawing.Point(126, 98);
            this.maxThresholdUpDown.Maximum = new decimal(new int[] {
            -469762049,
            -590869294,
            5421010,
            0});
            this.maxThresholdUpDown.Name = "maxThresholdUpDown";
            this.maxThresholdUpDown.Size = new System.Drawing.Size(331, 20);
            this.maxThresholdUpDown.TabIndex = 3;
            // 
            // inlineRangeUpDown
            // 
            this.inlineRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineRangeUpDown.Location = new System.Drawing.Point(126, 24);
            this.inlineRangeUpDown.Name = "inlineRangeUpDown";
            this.inlineRangeUpDown.Size = new System.Drawing.Size(126, 20);
            this.inlineRangeUpDown.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 71;
            this.label4.Text = "Standard deviation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 70;
            this.label3.Text = "Z range";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 69;
            this.label2.Text = "Crossline range";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 68;
            this.label1.Text = "Inline range";
            // 
            // meanDrop
            // 
            this.meanDrop.AllowDrop = true;
            this.meanDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meanDrop.Location = new System.Drawing.Point(126, 17);
            this.meanDrop.Name = "meanDrop";
            this.meanDrop.Size = new System.Drawing.Size(26, 23);
            this.meanDrop.TabIndex = 0;
            this.meanDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.meanDrop_DragDrop);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 93;
            this.label15.Text = "Mean:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.meanPresentationBox);
            this.groupBox2.Controls.Add(this.wellLogSelect1);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.meanDrop);
            this.groupBox2.Controls.Add(this.maxThresholdUpDown);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.realizationsSaveUpDown);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.realizationsUpDown);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(464, 329);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Simulation Paremeters";
            // 
            // meanPresentationBox
            // 
            this.meanPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meanPresentationBox.Location = new System.Drawing.Point(158, 18);
            this.meanPresentationBox.Name = "meanPresentationBox";
            this.meanPresentationBox.Size = new System.Drawing.Size(299, 22);
            this.meanPresentationBox.TabIndex = 103;
            this.meanPresentationBox.TabStop = false;
            // 
            // wellLogSelect1
            // 
            this.wellLogSelect1.Location = new System.Drawing.Point(16, 124);
            this.wellLogSelect1.Name = "wellLogSelect1";
            this.wellLogSelect1.Size = new System.Drawing.Size(441, 206);
            this.wellLogSelect1.TabIndex = 4;
            // 
            // prevKringCheckBox
            // 
            this.prevKringCheckBox.AutoSize = true;
            this.prevKringCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prevKringCheckBox.Location = new System.Drawing.Point(19, 478);
            this.prevKringCheckBox.Name = "prevKringCheckBox";
            this.prevKringCheckBox.Size = new System.Drawing.Size(190, 17);
            this.prevKringCheckBox.TabIndex = 2;
            this.prevKringCheckBox.Text = "Use Previous Kriging Results";
            this.prevKringCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.varianceKringPresentationBox);
            this.groupBox1.Controls.Add(this.meanKringPresentationBox);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.varianceKringDrop);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.meanKringDrop);
            this.groupBox1.Location = new System.Drawing.Point(3, 478);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(464, 48);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // varianceKringPresentationBox
            // 
            this.varianceKringPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.varianceKringPresentationBox.Location = new System.Drawing.Point(329, 20);
            this.varianceKringPresentationBox.Name = "varianceKringPresentationBox";
            this.varianceKringPresentationBox.Size = new System.Drawing.Size(128, 22);
            this.varianceKringPresentationBox.TabIndex = 102;
            this.varianceKringPresentationBox.TabStop = false;
            // 
            // meanKringPresentationBox
            // 
            this.meanKringPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meanKringPresentationBox.Location = new System.Drawing.Point(85, 20);
            this.meanKringPresentationBox.Name = "meanKringPresentationBox";
            this.meanKringPresentationBox.Size = new System.Drawing.Size(128, 22);
            this.meanKringPresentationBox.TabIndex = 101;
            this.meanKringPresentationBox.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label13.Location = new System.Drawing.Point(239, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 100;
            this.label13.Text = "Variance:";
            // 
            // varianceKringDrop
            // 
            this.varianceKringDrop.AllowDrop = true;
            this.varianceKringDrop.Location = new System.Drawing.Point(297, 19);
            this.varianceKringDrop.Name = "varianceKringDrop";
            this.varianceKringDrop.Size = new System.Drawing.Size(26, 23);
            this.varianceKringDrop.TabIndex = 1;
            this.varianceKringDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.varianceKringDrop_DragDrop);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label16.Location = new System.Drawing.Point(13, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 98;
            this.label16.Text = "Mean:";
            // 
            // meanKringDrop
            // 
            this.meanKringDrop.AllowDrop = true;
            this.meanKringDrop.Location = new System.Drawing.Point(53, 19);
            this.meanKringDrop.Name = "meanKringDrop";
            this.meanKringDrop.Size = new System.Drawing.Size(26, 23);
            this.meanKringDrop.TabIndex = 0;
            this.meanKringDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.meanKringDrop_DragDrop);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(129, 531);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(36, 536);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 104;
            this.label14.Text = "Load Parameters";
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 532);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 4;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 531);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 7;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(395, 531);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 8;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Location = new System.Drawing.Point(234, 531);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 6;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.inlineRangeUpDown);
            this.groupBox3.Controls.Add(this.crosslineRangeUpDown);
            this.groupBox3.Controls.Add(this.zRangeUpDown);
            this.groupBox3.Controls.Add(this.stdDeviationUpDown);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.rakeUpDown);
            this.groupBox3.Controls.Add(this.dipUpDown);
            this.groupBox3.Controls.Add(this.azimuthUpDown);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(464, 133);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Variogram";
            // 
            // FFTMASimulWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.loadDrop);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.prevKringCheckBox);
            this.Controls.Add(this.groupBox1);
            this.Name = "FFTMASimulWorkstepUI";
            this.Size = new System.Drawing.Size(475, 559);
            ((System.ComponentModel.ISupportInitialize)(this.azimuthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dipUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rakeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realizationsUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stdDeviationUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.realizationsSaveUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.crosslineRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxThresholdUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineRangeUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.NumericUpDown azimuthUpDown;
        private System.Windows.Forms.NumericUpDown dipUpDown;
        private System.Windows.Forms.NumericUpDown rakeUpDown;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown realizationsUpDown;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown stdDeviationUpDown;
        private System.Windows.Forms.NumericUpDown realizationsSaveUpDown;
        private System.Windows.Forms.NumericUpDown zRangeUpDown;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown crosslineRangeUpDown;
        private System.Windows.Forms.NumericUpDown maxThresholdUpDown;
        private System.Windows.Forms.NumericUpDown inlineRangeUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Slb.Ocean.Petrel.UI.DropTarget meanDrop;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label16;
        private Slb.Ocean.Petrel.UI.DropTarget varianceKringDrop;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private Slb.Ocean.Petrel.UI.DropTarget meanKringDrop;
        private System.Windows.Forms.CheckBox prevKringCheckBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Label label14;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private WellLogSelect wellLogSelect1;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox meanPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox varianceKringPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox meanKringPresentationBox;
    }
}
