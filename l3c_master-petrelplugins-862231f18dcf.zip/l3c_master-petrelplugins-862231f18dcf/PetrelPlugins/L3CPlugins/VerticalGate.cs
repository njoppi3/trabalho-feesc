﻿using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using System;
using System.Windows.Forms;

namespace UFSC_Plugins {
    public partial class VerticalGate : Form {
        public RegularHeightFieldSurface top, baseh;

        /**
         * Constructor
         */
        public VerticalGate() {
            InitializeComponent();
        }

        /**
         * Just hide the form, opening again already opens with the values
         */
        private void okButton_Click(object sender, EventArgs e) {
            Hide();
        }

        /**
         * Get the top droid
         */
        public string getTopDroid() {
            if (top == null) {
                return "";
            }
            return top.Droid.ToString();
        }

        /**
         * Get the bottom droid
         */
        public string getBottomDroid() {
            if (baseh == null) {
                return "";
            }
            return baseh.Droid.ToString();
        }

        /**
         * Get the top offset value
         */
        public double getTopOffset() {
            return (double)topUpDown.Value;
        }

        /**
         * Get the bottom offset value
         */
        public double getBottomOffset() {
            return (double)bottomUpDown.Value;
        }

        /**
         * Set the top droid
         */
        public void setTopDroid(string droid) {
            if (droid != null && droid != "") {
                top = Functions.getRegularHeightFieldSurface(new Droid(droid));
                topPresentationBox.Text = top.Name;
            }
        }

        /**
         * Set the bottom droid
         */
        public void setBottomDroid(string droid) {
            if (droid != null && droid != "") {
                baseh = Functions.getRegularHeightFieldSurface(new Droid(droid));
                bottomPresentationBox.Text = baseh.Name;
            }
        }

        /**
         * Set the top offset value
         */
        public void setTopOffset(double value) {
            topUpDown.Value = (decimal)value;
        }

        /**
         * Set the bottom offset value
         */
        public void setBottomOffset(double value) {
            bottomUpDown.Value = (decimal)value;
        }

        /**
         * Get the object from dragDrop
         */
        private void TopDropTarget_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            if (dropped is RegularHeightFieldSurface) {
                top = dropped as RegularHeightFieldSurface;
                topPresentationBox.Text = top.Name;
                top.Deleted += horizon_Deleted;
            } else {
                PetrelLogger.ErrorBox("Error: wrong type");
                return;
            }
        }

       

        /**
         * Get the object from dragDrop
         */
        private void BottomDropTarget_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            if (dropped is RegularHeightFieldSurface) {
                baseh = dropped as RegularHeightFieldSurface;
                bottomPresentationBox.Text = baseh.Name;
                baseh.Deleted += horizon_Deleted;
            } else {
                PetrelLogger.ErrorBox("Error: wrong type");
                return;
            }
        }

        /**
         * Delete the top
         */
        private void topDeleteButtonClick(object sender, EventArgs e) {
            top = null;
            topPresentationBox.Text = "";
        }

        /**
         * Delete the bottom
         */
        private void bottomDeleteButton_Click(object sender, EventArgs e) {
            baseh = null;
            bottomPresentationBox.Text = "";
        }

        /**
         * Deleted outside plugin
         */
        private void horizon_Deleted(object sender, EventArgs e)
        {
            RegularHeightFieldSurface h = sender as RegularHeightFieldSurface;
            if (h != null && h.Droid.Equals(top.Droid))
            {
                top = null;
                topPresentationBox.Text = "";
                PetrelLogger.InfoBox(h.Name + " was deleted and removed from Vertical Gate options.");
            }

            if (h != null && h.Droid.Equals(baseh.Droid))
            {
                baseh = null;
                bottomPresentationBox.Text = "";
                PetrelLogger.InfoBox(h.Name + " was deleted and removed from Vertical Gate options.");
            }
        }

        /**
         * Listens to the event of closing the form, prevent close, just hiding
         */
        private void VerticalGate_FormClosing(object sender, FormClosingEventArgs e) {
            if (e.CloseReason == CloseReason.UserClosing) {
                Hide();
                e.Cancel = true;
            }
        }
    }
}
