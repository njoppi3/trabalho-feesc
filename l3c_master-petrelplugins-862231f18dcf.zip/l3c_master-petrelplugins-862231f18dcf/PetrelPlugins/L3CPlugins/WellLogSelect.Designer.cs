﻿namespace UFSC_Plugins
{
    partial class WellLogSelect
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dropTargetAddWell = new Slb.Ocean.Petrel.UI.DropTarget();
            this.groupBoxGlobalWlogs = new System.Windows.Forms.GroupBox();
            this.dropTargetZ = new Slb.Ocean.Petrel.UI.DropTarget();
            this.labelZ = new System.Windows.Forms.Label();
            this.presentationBoxZ = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.presentationBoxXLog = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.presentationBoxYLog = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.presentationBoxTime = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.dropTargetTimeLog = new Slb.Ocean.Petrel.UI.DropTarget();
            this.labelTimelog = new System.Windows.Forms.Label();
            this.dropTargetYlog = new Slb.Ocean.Petrel.UI.DropTarget();
            this.dropTargetXlog = new Slb.Ocean.Petrel.UI.DropTarget();
            this.labelYlog = new System.Windows.Forms.Label();
            this.labelXlog = new System.Windows.Forms.Label();
            this.buttonRemoveWell = new System.Windows.Forms.Button();
            this.dataGridViewWells = new System.Windows.Forms.DataGridView();
            this.ColWellName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColWellBin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColWellMaxBin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelWells = new System.Windows.Forms.Label();
            this.groupBoxGlobalWlogs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWells)).BeginInit();
            this.SuspendLayout();
            // 
            // dropTargetAddWell
            // 
            this.dropTargetAddWell.AllowDrop = true;
            this.dropTargetAddWell.Location = new System.Drawing.Point(50, 23);
            this.dropTargetAddWell.Name = "dropTargetAddWell";
            this.dropTargetAddWell.Size = new System.Drawing.Size(26, 23);
            this.dropTargetAddWell.TabIndex = 0;
            this.dropTargetAddWell.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropTargetAddWell_DragDrop);
            // 
            // groupBoxGlobalWlogs
            // 
            this.groupBoxGlobalWlogs.AutoSize = true;
            this.groupBoxGlobalWlogs.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBoxGlobalWlogs.Controls.Add(this.dropTargetZ);
            this.groupBoxGlobalWlogs.Controls.Add(this.labelZ);
            this.groupBoxGlobalWlogs.Controls.Add(this.presentationBoxZ);
            this.groupBoxGlobalWlogs.Controls.Add(this.presentationBoxXLog);
            this.groupBoxGlobalWlogs.Controls.Add(this.presentationBoxYLog);
            this.groupBoxGlobalWlogs.Controls.Add(this.presentationBoxTime);
            this.groupBoxGlobalWlogs.Controls.Add(this.dropTargetTimeLog);
            this.groupBoxGlobalWlogs.Controls.Add(this.labelTimelog);
            this.groupBoxGlobalWlogs.Controls.Add(this.dropTargetYlog);
            this.groupBoxGlobalWlogs.Controls.Add(this.dropTargetXlog);
            this.groupBoxGlobalWlogs.Controls.Add(this.labelYlog);
            this.groupBoxGlobalWlogs.Controls.Add(this.labelXlog);
            this.groupBoxGlobalWlogs.Location = new System.Drawing.Point(5, 101);
            this.groupBoxGlobalWlogs.Name = "groupBoxGlobalWlogs";
            this.groupBoxGlobalWlogs.Size = new System.Drawing.Size(356, 138);
            this.groupBoxGlobalWlogs.TabIndex = 2;
            this.groupBoxGlobalWlogs.TabStop = false;
            this.groupBoxGlobalWlogs.Text = "Global well logs";
            this.groupBoxGlobalWlogs.Enter += new System.EventHandler(this.groupBoxGlobalWlogs_Enter);
            // 
            // dropTargetZ
            // 
            this.dropTargetZ.AllowDrop = true;
            this.dropTargetZ.Enabled = false;
            this.dropTargetZ.Location = new System.Drawing.Point(117, 96);
            this.dropTargetZ.Name = "dropTargetZ";
            this.dropTargetZ.Size = new System.Drawing.Size(26, 23);
            this.dropTargetZ.TabIndex = 35;
            this.dropTargetZ.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropTargetZ_DragDrop);
            // 
            // labelZ
            // 
            this.labelZ.AutoSize = true;
            this.labelZ.Enabled = false;
            this.labelZ.Location = new System.Drawing.Point(6, 99);
            this.labelZ.Name = "labelZ";
            this.labelZ.Size = new System.Drawing.Size(65, 13);
            this.labelZ.TabIndex = 36;
            this.labelZ.Text = "Z global log:";
            // 
            // presentationBoxZ
            // 
            this.presentationBoxZ.Location = new System.Drawing.Point(149, 97);
            this.presentationBoxZ.Name = "presentationBoxZ";
            this.presentationBoxZ.Size = new System.Drawing.Size(201, 22);
            this.presentationBoxZ.TabIndex = 37;
            this.presentationBoxZ.TabStop = false;
            // 
            // presentationBoxXLog
            // 
            this.presentationBoxXLog.Location = new System.Drawing.Point(149, 41);
            this.presentationBoxXLog.Name = "presentationBoxXLog";
            this.presentationBoxXLog.Size = new System.Drawing.Size(201, 22);
            this.presentationBoxXLog.TabIndex = 34;
            this.presentationBoxXLog.TabStop = false;
            // 
            // presentationBoxYLog
            // 
            this.presentationBoxYLog.Location = new System.Drawing.Point(149, 69);
            this.presentationBoxYLog.Name = "presentationBoxYLog";
            this.presentationBoxYLog.Size = new System.Drawing.Size(201, 22);
            this.presentationBoxYLog.TabIndex = 32;
            this.presentationBoxYLog.TabStop = false;
            // 
            // presentationBoxTime
            // 
            this.presentationBoxTime.Location = new System.Drawing.Point(149, 13);
            this.presentationBoxTime.Name = "presentationBoxTime";
            this.presentationBoxTime.Size = new System.Drawing.Size(201, 22);
            this.presentationBoxTime.TabIndex = 31;
            this.presentationBoxTime.TabStop = false;
            // 
            // dropTargetTimeLog
            // 
            this.dropTargetTimeLog.AllowDrop = true;
            this.dropTargetTimeLog.Location = new System.Drawing.Point(117, 12);
            this.dropTargetTimeLog.Name = "dropTargetTimeLog";
            this.dropTargetTimeLog.Size = new System.Drawing.Size(26, 23);
            this.dropTargetTimeLog.TabIndex = 0;
            this.dropTargetTimeLog.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropTargetTimeLog_DragDrop);
            // 
            // labelTimelog
            // 
            this.labelTimelog.AutoSize = true;
            this.labelTimelog.Location = new System.Drawing.Point(6, 17);
            this.labelTimelog.Name = "labelTimelog";
            this.labelTimelog.Size = new System.Drawing.Size(50, 13);
            this.labelTimelog.TabIndex = 25;
            this.labelTimelog.Text = "Time log:";
            // 
            // dropTargetYlog
            // 
            this.dropTargetYlog.AllowDrop = true;
            this.dropTargetYlog.Enabled = false;
            this.dropTargetYlog.Location = new System.Drawing.Point(117, 68);
            this.dropTargetYlog.Name = "dropTargetYlog";
            this.dropTargetYlog.Size = new System.Drawing.Size(26, 23);
            this.dropTargetYlog.TabIndex = 2;
            this.dropTargetYlog.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropTargetYlog_DragDrop);
            // 
            // dropTargetXlog
            // 
            this.dropTargetXlog.AllowDrop = true;
            this.dropTargetXlog.Enabled = false;
            this.dropTargetXlog.Location = new System.Drawing.Point(117, 41);
            this.dropTargetXlog.Name = "dropTargetXlog";
            this.dropTargetXlog.Size = new System.Drawing.Size(26, 23);
            this.dropTargetXlog.TabIndex = 1;
            this.dropTargetXlog.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropTargetXlog_DragDrop);
            // 
            // labelYlog
            // 
            this.labelYlog.AutoSize = true;
            this.labelYlog.Enabled = false;
            this.labelYlog.Location = new System.Drawing.Point(6, 72);
            this.labelYlog.Name = "labelYlog";
            this.labelYlog.Size = new System.Drawing.Size(65, 13);
            this.labelYlog.TabIndex = 10;
            this.labelYlog.Text = "Y global log:";
            // 
            // labelXlog
            // 
            this.labelXlog.AutoSize = true;
            this.labelXlog.Enabled = false;
            this.labelXlog.Location = new System.Drawing.Point(6, 41);
            this.labelXlog.Name = "labelXlog";
            this.labelXlog.Size = new System.Drawing.Size(65, 13);
            this.labelXlog.TabIndex = 9;
            this.labelXlog.Text = "X global log:";
            // 
            // buttonRemoveWell
            // 
            this.buttonRemoveWell.Location = new System.Drawing.Point(5, 61);
            this.buttonRemoveWell.Name = "buttonRemoveWell";
            this.buttonRemoveWell.Size = new System.Drawing.Size(75, 23);
            this.buttonRemoveWell.TabIndex = 1;
            this.buttonRemoveWell.Text = "Remove";
            this.buttonRemoveWell.UseVisualStyleBackColor = true;
            this.buttonRemoveWell.Click += new System.EventHandler(this.buttonRemoveWell_Click_1);
            // 
            // dataGridViewWells
            // 
            this.dataGridViewWells.AllowUserToAddRows = false;
            this.dataGridViewWells.AllowUserToDeleteRows = false;
            this.dataGridViewWells.AllowUserToResizeRows = false;
            this.dataGridViewWells.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewWells.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewWells.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColWellName,
            this.ColWellBin,
            this.ColWellMaxBin});
            this.dataGridViewWells.Location = new System.Drawing.Point(86, 3);
            this.dataGridViewWells.Name = "dataGridViewWells";
            this.dataGridViewWells.ReadOnly = true;
            this.dataGridViewWells.RowHeadersVisible = false;
            this.dataGridViewWells.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewWells.Size = new System.Drawing.Size(275, 92);
            this.dataGridViewWells.TabIndex = 33;
            this.dataGridViewWells.TabStop = false;
            // 
            // ColWellName
            // 
            this.ColWellName.HeaderText = "Name";
            this.ColWellName.Name = "ColWellName";
            this.ColWellName.ReadOnly = true;
            this.ColWellName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ColWellBin
            // 
            this.ColWellBin.HeaderText = "X";
            this.ColWellBin.Name = "ColWellBin";
            this.ColWellBin.ReadOnly = true;
            // 
            // ColWellMaxBin
            // 
            this.ColWellMaxBin.HeaderText = "Y";
            this.ColWellMaxBin.Name = "ColWellMaxBin";
            this.ColWellMaxBin.ReadOnly = true;
            // 
            // labelWells
            // 
            this.labelWells.AutoSize = true;
            this.labelWells.Location = new System.Drawing.Point(11, 28);
            this.labelWells.Name = "labelWells";
            this.labelWells.Size = new System.Drawing.Size(36, 13);
            this.labelWells.TabIndex = 32;
            this.labelWells.Text = "Wells:";
            // 
            // WellLogSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dropTargetAddWell);
            this.Controls.Add(this.groupBoxGlobalWlogs);
            this.Controls.Add(this.buttonRemoveWell);
            this.Controls.Add(this.dataGridViewWells);
            this.Controls.Add(this.labelWells);
            this.Name = "WellLogSelect";
            this.Size = new System.Drawing.Size(367, 256);
            this.groupBoxGlobalWlogs.ResumeLayout(false);
            this.groupBoxGlobalWlogs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWells)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Slb.Ocean.Petrel.UI.DropTarget dropTargetAddWell;
        private System.Windows.Forms.GroupBox groupBoxGlobalWlogs;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox presentationBoxXLog;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox presentationBoxYLog;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox presentationBoxTime;
        private Slb.Ocean.Petrel.UI.DropTarget dropTargetTimeLog;
        private System.Windows.Forms.Label labelTimelog;
        private Slb.Ocean.Petrel.UI.DropTarget dropTargetYlog;
        private Slb.Ocean.Petrel.UI.DropTarget dropTargetXlog;
        private System.Windows.Forms.Label labelYlog;
        private System.Windows.Forms.Label labelXlog;
        private System.Windows.Forms.Button buttonRemoveWell;
        private System.Windows.Forms.DataGridView dataGridViewWells;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColWellName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColWellBin;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColWellMaxBin;
        private System.Windows.Forms.Label labelWells;
        private Slb.Ocean.Petrel.UI.DropTarget dropTargetZ;
        private System.Windows.Forms.Label labelZ;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox presentationBoxZ;
    }
}
