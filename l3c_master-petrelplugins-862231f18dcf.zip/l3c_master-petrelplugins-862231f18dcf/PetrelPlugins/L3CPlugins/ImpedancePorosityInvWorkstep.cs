using System;

using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject;
using static UFSC_Plugins.ImpedancePorosityInvWorkstepUI;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the ImpedancePorosityInvWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class ImpedancePorosityInvWorkstep : Workstep<ImpedancePorosityInvWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override ImpedancePorosityInvWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "af6de227-2ac9-448d-8cf5-92dbab3c2ac6";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�
                // input
                Wavelet wavelet;
                SeismicCube seismicCube, impedanceCube, porosityCube;
                try {
                    wavelet = Functions.getWaveletByReferenceVar(new Droid(args.structure.waveletDroid));
                    seismicCube = Functions.getCubeByReferenceVar(new Droid(args.structure.seismicCubeDroid));
                    impedanceCube = Functions.getCubeByReferenceVar(new Droid(args.structure.impedanceCubeDroid));
                    porosityCube = Functions.getCubeByReferenceVar(new Droid(args.structure.porosityCubeDroid));
                } catch (Exception e) {
                    PetrelLogger.ErrorBox(e.ToString());
                    return;
                }
                // parameters
                decimal impedanceUncert = args.structure.impedanceUncert;
                decimal porosityUncert = args.structure.porosityUncert;
                decimal signalToNoise = args.structure.signalToNoise;
                decimal correlation = args.structure.correlation;
                // options --- CB = checkBox
                bool optionsCB = args.structure.optionsCB;
                bool trendFreqCB = args.structure.trendFreqCB;
                decimal trendFreq = args.structure.trendFreq;
                bool inlineInvPrevCB = args.structure.inlineInvPrevCB;
                decimal inlineInvPrev = args.structure.inlineInvPrev;
                bool mergeInvTrendCB = args.structure.mergeInvTrendCB;
                // output  --- TB = textBox, LB = Label
                string impedanceTB = args.structure.impedanceTB;
                string porosityTB = args.structure.porosityTB;
                string residualTB = args.structure.residualTB;
                string impedanceLB = args.structure.impedanceLB;
                string porosityLB = args.structure.porosityLB;
                //vertGate
                RegularHeightFieldSurface top;
                if (args.structure.topDroid != "") {
                    top = Functions.getRegularHeightFieldSurface(new Droid(args.structure.topDroid));
                    PetrelLogger.InfoOutputWindow("top: " + top.Name);
                }
                RegularHeightFieldSurface bottom;
                if (args.structure.bottomDroid != "") {
                    bottom = Functions.getRegularHeightFieldSurface(new Droid(args.structure.bottomDroid));
                    PetrelLogger.InfoOutputWindow("bottom: " + bottom.Name);
                }
                double topOffset = args.structure.topOffset;
                PetrelLogger.InfoOutputWindow("topOffset: " + topOffset.ToString());
                double bottomOffset = args.structure.bottomOffset;
                PetrelLogger.InfoOutputWindow("bottomOffset: " + bottomOffset.ToString());


                // PRINTS PARA TESTAR SE TA REALMENTE PASSANDO OS ARGS
                // input
                PetrelLogger.InfoOutputWindow("wavelet: " + wavelet.Name);
                PetrelLogger.InfoOutputWindow("seismicCube: " + seismicCube.Name);
                PetrelLogger.InfoOutputWindow("impedanceCube: " + impedanceCube.Name);
                PetrelLogger.InfoOutputWindow("porosityCube: " + porosityCube.Name);
                // parameters
                PetrelLogger.InfoOutputWindow("impedanceUncert: " + impedanceUncert.ToString());
                PetrelLogger.InfoOutputWindow("porosityUncert: " + porosityUncert.ToString());
                PetrelLogger.InfoOutputWindow("signalToNoise: " + signalToNoise.ToString());
                PetrelLogger.InfoOutputWindow("correlation: " + correlation.ToString());
                // options --- CB = checkBox
                PetrelLogger.InfoOutputWindow("optionsCB: " + optionsCB.ToString());
                PetrelLogger.InfoOutputWindow("trendFreqCB: " + trendFreqCB.ToString());
                PetrelLogger.InfoOutputWindow("trendFreq: " + trendFreq.ToString());
                PetrelLogger.InfoOutputWindow("inlineInvPrevCB: " + inlineInvPrevCB.ToString());
                PetrelLogger.InfoOutputWindow("inlineInvPrev: " + inlineInvPrev.ToString());
                PetrelLogger.InfoOutputWindow("mergeInvTrendCB: " + mergeInvTrendCB.ToString());
                // output  --- TB = textBox, LB = Label
                PetrelLogger.InfoOutputWindow("impedanceTB: " + impedanceTB);
                PetrelLogger.InfoOutputWindow("porosityTB: " + porosityTB);
                PetrelLogger.InfoOutputWindow("residualTB: " + residualTB);
                PetrelLogger.InfoOutputWindow("impedanceLB: " + impedanceLB);
                PetrelLogger.InfoOutputWindow("porosityLB: " + porosityLB);

                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot sroot = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = sroot.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Bayesian Impedance-Porosity Inversion Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                CubeFromPetrel[] cubetrends_wrap = new CubeFromPetrel[2];
                CubeFromPetrel[] cuberesults_wrap = new CubeFromPetrel[2];
                // write output
                SeismicCube ip_result;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    try
                    {
                        tr.Lock(scol);
                        ip_result = scol.CreateSeismicCube(impedanceCube, impedanceCube.Template);
                        ip_result.Name = impedanceTB;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                    cubetrends_wrap[0] = new CubeFromPetrel(impedanceCube);
                    cuberesults_wrap[0] = new CubeFromPetrel(ip_result, 10);
                    cuberesults_wrap[0].prepareWriteToPetrel();
                }
                SeismicCube por_result;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    try
                    {
                        tr.Lock(scol);
                        por_result = scol.CreateSeismicCube(porosityCube, porosityCube.Template);
                        por_result.Name = porosityTB;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                    cubetrends_wrap[1] = new CubeFromPetrel(porosityCube);
                    cuberesults_wrap[1] = new CubeFromPetrel(por_result, 10);
                    cuberesults_wrap[1].prepareWriteToPetrel();
                }

                ImpporCLI.ParametersCLI p = new ImpporCLI.ParametersCLI();
                CubeFromPetrel cubeseis_wrap;
                CubeFromPetrel cuberesids_wrap;
                double[] wavelets;

                // write outputres
                p.sgm_d2 = Convert.ToDouble(signalToNoise * signalToNoise);
                SeismicCube residuals;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    try
                    {
                        tr.Lock(scol);
                        residuals = scol.CreateSeismicCube(seismicCube, PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault);
                        residuals.Name = residualTB;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                }

                cubeseis_wrap = new CubeFromPetrel(seismicCube);
                cuberesids_wrap = new CubeFromPetrel(residuals, 10);
                cuberesids_wrap.prepareWriteToPetrel();
                wavelets = wavelet.Amplitudes.ToArray();
               
                p.corr_samples = Convert.ToDouble(correlation);
                p.filter_model = trendFreqCB;
                p.merge_inversion = mergeInvTrendCB;
                //p.interval_frequency_sec = wavelet.SamplingInterval;
                p.sgm_m_phi = Convert.ToDouble(porosityUncert);
                p.sgm_m_z = Convert.ToDouble(impedanceUncert);
                
                p.trend_frequency = Convert.ToDouble(trendFreq);

                double[][] C = null;
                double[] mux = null;
                double[] muy = null;
                args.structure.cp.getPriors(ref C, ref mux, ref muy);

                p.mu_phi = mux[0];
                p.mu_z = muy[0];
                p.C_prior = C[0];
                

                ImpPorTaskSetup task = new ImpPorTaskSetup(ref cubeseis_wrap, ref cubetrends_wrap, ref p, ref cuberesults_wrap,
                                                                ref cuberesids_wrap, ref wavelets);

                List<ImpPorTaskSetup> tasks = new List<ImpPorTaskSetup>();
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, seismicCube.NumSamplesIJK.I * seismicCube.NumSamplesIJK.J))
                {
                    try
                    {
                        pbar.SetProgressText("Performing Bayesian Elastic Inversion");

                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doImpPorInversion, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    }
                    catch (Exception excep)
                    {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");

                // write the results
                try {
                    SeismicCube a = Functions.getCubeByReferenceVar(new Droid(args.structure.impedanceCubeDroid));
                    SeismicCube b = Functions.getCubeByReferenceVar(new Droid(args.structure.porosityCubeDroid));
                    SeismicCube c = Functions.getCubeByReferenceVar(new Droid(args.structure.seismicCubeDroid));

                    args.ImpedOutCube = a;
                    args.PorosityOutCube = b;
                    args.ResidualOutCube = c;
                    args.ImpedanceOutValue = 0.12;
                    args.PorosityOutValue = 0.98;
                } catch (Exception e) {
                    throw e;
                }
            }

            private void doImpPorInversion(object objJob)
            {
                var task = (ImpPorTaskSetup)objJob;
                task._statusMsg = "Reading data from input volumes";

                task._cubeseis.readFromPetrel();
                task._cubetrend[0].readFromPetrel(); // Petrel canonical unit m/s Ok
                task._cubetrend[1].readFromPetrel(); // Petrel canonical unit m/s Ok

                int nseis = (int)task._cubeseis.getNumZlines();

                ImpporCLI imppori = new ImpporCLI(nseis - 1, task._p, task._wavelet, task.srate);

                imppori.setSeismicCube(task._cubeseis);

                imppori.setTrendCubez(task._cubetrend[0]);
                imppori.setTrendCubephi(task._cubetrend[1]);

                task._statusMsg = "Processing data";
                task.imppori = imppori;
                imppori.solve();
                task._cube_ippor_out[0].setCube(imppori.invertedCubeAI());
                task._cube_ippor_out[1].setCube(imppori.invertedCubePHI());

                CubeCLI outs = imppori.synteticsCube();
                task._cuberesidout.setCube(outs);

                task._statusMsg = "Writing Ip results";
                task._cube_ippor_out[0].writeToPetrel(ref task.progressPct);
                task._statusMsg = "Writing Phi results";
                task._cube_ippor_out[1].writeToPetrel(ref task.progressPct);

                task._statusMsg = "Writing Seismic results";
                task._cuberesidout.writeToPetrel(ref task.progressPct);
            }

        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for ImpedancePorosityInvWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {

            public ImpedancePorosityInvStruct structure;
            private SeismicCube impedanceOutCube;
            private SeismicCube porosityOutCube;
            private SeismicCube residualOutCube;
            private double impedanceOutValue;
            private double porosityOutValue;

            [Description("Impedance Output Cube", "Impedance Output Cube")]
            public SeismicCube ImpedOutCube {
                get { return impedanceOutCube; }
                internal set { impedanceOutCube = value; }
            }

            [Description("Porosity Output Cube", "Porosity Output Cube")]
            public SeismicCube PorosityOutCube {
                get { return porosityOutCube; }
                internal set { porosityOutCube = value; }
            }

            [Description("Residual Output Cube", "Residual Output Cube")]
            public SeismicCube ResidualOutCube {
                get { return residualOutCube; }
                internal set { residualOutCube = value; }
            }

            [Description("Impedance Output Value", "Impedance Output Value")]
            public double ImpedanceOutValue {
                get { return impedanceOutValue; }
                internal set { impedanceOutValue = value; }
            }

            [Description("Porosity Output Value", "Porosity Output Value")]
            public double PorosityOutValue {
                get { return porosityOutValue; }
                internal set { porosityOutValue = value; }
            }

            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the ImpedancePorosityInvWorkstep
        /// </summary>
        public IDescription Description {
            get { return ImpedancePorosityInvWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the ImpedancePorosityInvWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class ImpedancePorosityInvWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static ImpedancePorosityInvWorkstepDescription instance = new ImpedancePorosityInvWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static ImpedancePorosityInvWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of ImpedancePorosityInvWorkstep
            /// </summary>
            public string Name {
                get { return "Bayesian Linearized Impedance and Porosity MAP Inversion"; }
            }
            /// <summary>
            /// Gets the short description of ImpedancePorosityInvWorkstep
            /// </summary>
            public string ShortDescription {
                get { return ""; }
            }
            /// <summary>
            /// Gets the detailed description of ImpedancePorosityInvWorkstep
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new ImpedancePorosityInvWorkstepUI((ImpedancePorosityInvWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}