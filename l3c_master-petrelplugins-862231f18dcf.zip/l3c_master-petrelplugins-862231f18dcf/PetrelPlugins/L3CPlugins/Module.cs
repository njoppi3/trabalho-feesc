using System;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;

namespace UFSC_Plugins {
    /// <summary>
    /// This class will control the lifecycle of the Module.
    /// The order of the methods are the same as the calling order.
    /// </summary>
    public class Module : IModule {
        #region Private Variables
        private Process m_cpdataworkstepInstance;
        private Process m_acousticinvworkstepInstance;
        private Process m_fftmasimulworkstepInstance;
        private Process m_kohonenfaciesworkstepInstance;
        private Process m_impedanceporosityinvworkstepInstance;
        private Process m_elasticinversionworkstepInstance;
        private Process m_mainworkstepInstance;
        private Process m_elasticfaciesworkstepInstance;
        #endregion
        public Module() {
            //
            // TODO: Add constructor logic here
            //
        }

        #region IModule Members

        /// <summary>
        /// This method runs once in the Module life; when it loaded into the petrel.
        /// This method called first.
        /// </summary>
        public void Initialize() {
            // TODO:  Add Module.Initialize implementation
        }

        /// <summary>
        /// This method runs once in the Module life. 
        /// In this method, you can do registrations of the not UI related components.
        /// (eg: datasource, plugin)
        /// </summary>
        public void Integrate() {

            // TODO:  Add Module.Integrate implementation

            // Register AcousticInvDataSourceFactory
            PetrelSystem.AddDataSourceFactory(new GenericDataSourceFactory());

            // Register CPDataWorkstep
            CPDataWorkstep cpdataworkstepInstance = new CPDataWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<CPDataWorkstep.Arguments>(new CPDataWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(cpdataworkstepInstance);
            m_cpdataworkstepInstance = new WorkstepProcessWrapper(cpdataworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_cpdataworkstepInstance, "L3C-UFSC-V3o2");
            
            // Register AcousticInvWorkstep
            AcousticInvWorkstep acousticinvworkstepInstance = new AcousticInvWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<AcousticInvWorkstep.Arguments>(new AcousticInvWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(acousticinvworkstepInstance);
            m_acousticinvworkstepInstance = new WorkstepProcessWrapper(acousticinvworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_acousticinvworkstepInstance, "L3C-UFSC-V3o2");

            // Register FFTMASimulWorkstep
            FFTMASimulWorkstep fftmasimulworkstepInstance = new FFTMASimulWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<FFTMASimulWorkstep.Arguments>(new FFTMASimulWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(fftmasimulworkstepInstance);
            m_fftmasimulworkstepInstance = new WorkstepProcessWrapper(fftmasimulworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_fftmasimulworkstepInstance, "L3C-UFSC-V3o2");

            // Register KohonenFaciesWorkstep
            KohonenFaciesWorkstep kohonenfaciesworkstepInstance = new KohonenFaciesWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<KohonenFaciesWorkstep.Arguments>(new KohonenFaciesWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(kohonenfaciesworkstepInstance);
            m_kohonenfaciesworkstepInstance = new WorkstepProcessWrapper(kohonenfaciesworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_kohonenfaciesworkstepInstance, "L3C-UFSC-V3o2");

            // Register ImpedancePorosityInvWorkstep
            ImpedancePorosityInvWorkstep impedanceporosityinvworkstepInstance = new ImpedancePorosityInvWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<ImpedancePorosityInvWorkstep.Arguments>(new ImpedancePorosityInvWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(impedanceporosityinvworkstepInstance);
            m_impedanceporosityinvworkstepInstance = new WorkstepProcessWrapper(impedanceporosityinvworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_impedanceporosityinvworkstepInstance, "L3C-UFSC-V3o2");
            
            // Register MainWorkstep
            MainWorkstep mainworkstepInstance = new MainWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<MainWorkstep.Arguments>(new MainWorkstep.UIFactory());
            //PetrelSystem.WorkflowEditor.Add(mainworkstepInstance);
            m_mainworkstepInstance = new Slb.Ocean.Petrel.Workflow.WorkstepProcessWrapper(mainworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_mainworkstepInstance, "L3C-UFSC-V3o2");

            // Register ElasticInversionWorkstep
            ElasticInversionWorkstep elasticinversionworkstepInstance = new ElasticInversionWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<ElasticInversionWorkstep.Arguments>(new ElasticInversionWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(elasticinversionworkstepInstance);
            m_elasticinversionworkstepInstance = new Slb.Ocean.Petrel.Workflow.WorkstepProcessWrapper(elasticinversionworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_elasticinversionworkstepInstance, "L3C-UFSC-V3o2");
            
            // Register ElasticFaciesWorInversionkstep
            ElasticFaciesInversionWorkstep elasticfaciesinversionworkstepInstance = new ElasticFaciesInversionWorkstep();
            PetrelSystem.WorkflowEditor.AddUIFactory<ElasticFaciesInversionWorkstep.Arguments>(new ElasticFaciesInversionWorkstep.UIFactory());
            PetrelSystem.WorkflowEditor.Add(elasticfaciesinversionworkstepInstance);
            m_elasticfaciesworkstepInstance = new Slb.Ocean.Petrel.Workflow.WorkstepProcessWrapper(elasticfaciesinversionworkstepInstance);
            PetrelSystem.ProcessDiagram.Add(m_elasticfaciesworkstepInstance, "L3C-UFSC-V3o2");
        }

        /// <summary>
        /// This method runs once in the Module life. 
        /// In this method, you can do registrations of the UI related components.
        /// (eg: settingspages, treeextensions)
        /// </summary>
        public void IntegratePresentation() {

            // TODO:  Add Module.IntegratePresentation implementation

            // Add Ribbon Configuration file
            PetrelSystem.ConfigurationService.AddConfiguration(Properties.Resources.OceanRibbonConfiguration1);

            string helpDirectory1 = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            HelpService helpService1 = PetrelSystem.HelpService;
            PluginHelpManifest helpContent2 = new PluginHelpManifest(System.IO.Path.Combine(helpDirectory1, @"HelpFiles\manual_plugins_l3c.pdf"))
            {
                Text = "UFSC L3C Invers�o, geoestat�stica e redes neurais (pdf)",
            };
            helpService1.Add(helpContent2);

        }

        /// <summary>
        /// This method called once in the life of the module; 
        /// right before the module is unloaded. 
        /// It is usually when the application is closing.
        /// </summary>
        public void Disintegrate() {
            // TODO:  Add Module.Disintegrate implementation
            // Unregister CPDataWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<CPDataWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_cpdataworkstepInstance);
            // Unregister AcousticInvWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<AcousticInvWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_acousticinvworkstepInstance);
            // Unregister FFTMASimulWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<FFTMASimulWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_fftmasimulworkstepInstance);
            // Unregister KohonenFaciesWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<KohonenFaciesWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_kohonenfaciesworkstepInstance);
            // Unregister ImpedancePorosityInvWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<ImpedancePorosityInvWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_impedanceporosityinvworkstepInstance);
            // Unregister MainWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<MainWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_mainworkstepInstance);
            // Unregister ElasticInversionWorkstep
            PetrelSystem.WorkflowEditor.RemoveUIFactory<ElasticInversionWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_elasticinversionworkstepInstance);
            // Unregister ElasticFaciesInversion
            PetrelSystem.WorkflowEditor.RemoveUIFactory<ElasticFaciesInversionWorkstep.Arguments>();
            PetrelSystem.ProcessDiagram.Remove(m_elasticfaciesworkstepInstance);
        }

        #endregion

        #region IDisposable Members

        public void Dispose() {
            // TODO:  Add Module.Dispose implementation
        }

        #endregion

    }


}