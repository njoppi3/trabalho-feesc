namespace UFSC_Plugins
{
    partial class KohonenFaciesWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.plotButton = new System.Windows.Forms.Button();
            this.retrainNetCheckBox = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.immersionRadioButton = new System.Windows.Forms.RadioButton();
            this.watershedRadioButton = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.saveNetButton = new System.Windows.Forms.Button();
            this.loadNetButton = new System.Windows.Forms.Button();
            this.discretizationUpDown = new System.Windows.Forms.NumericUpDown();
            this.neuronsYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.neuronsXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.inlinePrevUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlinePrevCheckBox = new System.Windows.Forms.CheckBox();
            this.verticalGateButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.addVolumeCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.removeWellButton = new System.Windows.Forms.Button();
            this.volumeListBox = new System.Windows.Forms.ListBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.okButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBoxSomOut = new System.Windows.Forms.GroupBox();
            this.kohonenOutBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.discretizationUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.neuronsYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.neuronsXUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlinePrevUpDown)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBoxSomOut.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.plotButton);
            this.groupBox2.Controls.Add(this.retrainNetCheckBox);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.saveNetButton);
            this.groupBox2.Controls.Add(this.loadNetButton);
            this.groupBox2.Controls.Add(this.discretizationUpDown);
            this.groupBox2.Controls.Add(this.neuronsYUpDown);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.neuronsXUpDown);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 187);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(469, 204);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Network Options";
            // 
            // plotButton
            // 
            this.plotButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plotButton.Location = new System.Drawing.Point(122, 167);
            this.plotButton.Name = "plotButton";
            this.plotButton.Size = new System.Drawing.Size(141, 23);
            this.plotButton.TabIndex = 7;
            this.plotButton.Text = "Plot Cluster Map";
            this.plotButton.UseVisualStyleBackColor = true;
            this.plotButton.Click += new System.EventHandler(this.PlotButton_Click);
            // 
            // retrainNetCheckBox
            // 
            this.retrainNetCheckBox.AutoSize = true;
            this.retrainNetCheckBox.Checked = true;
            this.retrainNetCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.retrainNetCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.retrainNetCheckBox.Location = new System.Drawing.Point(122, 84);
            this.retrainNetCheckBox.Name = "retrainNetCheckBox";
            this.retrainNetCheckBox.Size = new System.Drawing.Size(103, 17);
            this.retrainNetCheckBox.TabIndex = 3;
            this.retrainNetCheckBox.Text = "Retrain Network";
            this.retrainNetCheckBox.UseVisualStyleBackColor = true;
            this.retrainNetCheckBox.Visible = false;
            this.retrainNetCheckBox.CheckedChanged += new System.EventHandler(this.RetrainNetCheckBox_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.immersionRadioButton);
            this.panel1.Controls.Add(this.watershedRadioButton);
            this.panel1.Location = new System.Drawing.Point(122, 107);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(339, 25);
            this.panel1.TabIndex = 4;
            // 
            // immersionRadioButton
            // 
            this.immersionRadioButton.AutoSize = true;
            this.immersionRadioButton.Checked = true;
            this.immersionRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.immersionRadioButton.Location = new System.Drawing.Point(7, 2);
            this.immersionRadioButton.Name = "immersionRadioButton";
            this.immersionRadioButton.Size = new System.Drawing.Size(72, 17);
            this.immersionRadioButton.TabIndex = 1;
            this.immersionRadioButton.TabStop = true;
            this.immersionRadioButton.Text = "Immersion";
            this.immersionRadioButton.UseVisualStyleBackColor = true;
            // 
            // watershedRadioButton
            // 
            this.watershedRadioButton.AutoSize = true;
            this.watershedRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.watershedRadioButton.Location = new System.Drawing.Point(198, 4);
            this.watershedRadioButton.Name = "watershedRadioButton";
            this.watershedRadioButton.Size = new System.Drawing.Size(77, 17);
            this.watershedRadioButton.TabIndex = 0;
            this.watershedRadioButton.Text = "Watershed";
            this.watershedRadioButton.UseVisualStyleBackColor = true;
            this.watershedRadioButton.CheckedChanged += new System.EventHandler(this.ClassificationRadioButton_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(33, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Classification:";
            // 
            // saveNetButton
            // 
            this.saveNetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveNetButton.Location = new System.Drawing.Point(320, 138);
            this.saveNetButton.Name = "saveNetButton";
            this.saveNetButton.Size = new System.Drawing.Size(141, 23);
            this.saveNetButton.TabIndex = 6;
            this.saveNetButton.Text = "Save Network";
            this.saveNetButton.UseVisualStyleBackColor = true;
            this.saveNetButton.Visible = false;
            // 
            // loadNetButton
            // 
            this.loadNetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadNetButton.Location = new System.Drawing.Point(122, 138);
            this.loadNetButton.Name = "loadNetButton";
            this.loadNetButton.Size = new System.Drawing.Size(141, 23);
            this.loadNetButton.TabIndex = 5;
            this.loadNetButton.Text = "Load Network";
            this.loadNetButton.UseVisualStyleBackColor = true;
            this.loadNetButton.Visible = false;
            // 
            // discretizationUpDown
            // 
            this.discretizationUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.discretizationUpDown.Location = new System.Drawing.Point(122, 58);
            this.discretizationUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.discretizationUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.discretizationUpDown.Name = "discretizationUpDown";
            this.discretizationUpDown.Size = new System.Drawing.Size(339, 20);
            this.discretizationUpDown.TabIndex = 2;
            this.discretizationUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // neuronsYUpDown
            // 
            this.neuronsYUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neuronsYUpDown.Location = new System.Drawing.Point(320, 32);
            this.neuronsYUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.neuronsYUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.neuronsYUpDown.Name = "neuronsYUpDown";
            this.neuronsYUpDown.Size = new System.Drawing.Size(141, 20);
            this.neuronsYUpDown.TabIndex = 1;
            this.neuronsYUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(372, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Y";
            // 
            // neuronsXUpDown
            // 
            this.neuronsXUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.neuronsXUpDown.Location = new System.Drawing.Point(122, 32);
            this.neuronsXUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.neuronsXUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.neuronsXUpDown.Name = "neuronsXUpDown";
            this.neuronsXUpDown.Size = new System.Drawing.Size(141, 20);
            this.neuronsXUpDown.TabIndex = 0;
            this.neuronsXUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(187, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "X";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Discretization:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Neurons Grid:";
            // 
            // inlinePrevUpDown
            // 
            this.inlinePrevUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlinePrevUpDown.Location = new System.Drawing.Point(122, 19);
            this.inlinePrevUpDown.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.inlinePrevUpDown.Name = "inlinePrevUpDown";
            this.inlinePrevUpDown.Size = new System.Drawing.Size(141, 20);
            this.inlinePrevUpDown.TabIndex = 1;
            this.inlinePrevUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // inlinePrevCheckBox
            // 
            this.inlinePrevCheckBox.AutoSize = true;
            this.inlinePrevCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlinePrevCheckBox.Location = new System.Drawing.Point(9, 20);
            this.inlinePrevCheckBox.Name = "inlinePrevCheckBox";
            this.inlinePrevCheckBox.Size = new System.Drawing.Size(95, 17);
            this.inlinePrevCheckBox.TabIndex = 0;
            this.inlinePrevCheckBox.Text = "Inline Preview:";
            this.inlinePrevCheckBox.UseVisualStyleBackColor = true;
            // 
            // verticalGateButton
            // 
            this.verticalGateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verticalGateButton.Location = new System.Drawing.Point(320, 19);
            this.verticalGateButton.Name = "verticalGateButton";
            this.verticalGateButton.Size = new System.Drawing.Size(141, 23);
            this.verticalGateButton.TabIndex = 2;
            this.verticalGateButton.Text = "Vertical Gate";
            this.verticalGateButton.UseVisualStyleBackColor = true;
            this.verticalGateButton.Click += new System.EventHandler(this.verticalGateButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(119, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Volumes";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.addVolumeCubeDrop);
            this.groupBox1.Controls.Add(this.removeWellButton);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.volumeListBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(469, 178);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label8.Location = new System.Drawing.Point(7, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 100;
            this.label8.Text = "Input Volume:";
            // 
            // addVolumeCubeDrop
            // 
            this.addVolumeCubeDrop.AllowDrop = true;
            this.addVolumeCubeDrop.Location = new System.Drawing.Point(78, 83);
            this.addVolumeCubeDrop.Name = "addVolumeCubeDrop";
            this.addVolumeCubeDrop.Size = new System.Drawing.Size(26, 23);
            this.addVolumeCubeDrop.TabIndex = 0;
            this.addVolumeCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.addVolumeCubeDrop_DragDrop);
            // 
            // removeWellButton
            // 
            this.removeWellButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeWellButton.Location = new System.Drawing.Point(122, 149);
            this.removeWellButton.Name = "removeWellButton";
            this.removeWellButton.Size = new System.Drawing.Size(90, 23);
            this.removeWellButton.TabIndex = 2;
            this.removeWellButton.Text = "Remove";
            this.removeWellButton.UseVisualStyleBackColor = true;
            this.removeWellButton.Click += new System.EventHandler(this.removeVolumeButton_Click);
            // 
            // volumeListBox
            // 
            this.volumeListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.volumeListBox.FormattingEnabled = true;
            this.volumeListBox.Location = new System.Drawing.Point(122, 38);
            this.volumeListBox.Name = "volumeListBox";
            this.volumeListBox.Size = new System.Drawing.Size(339, 108);
            this.volumeListBox.TabIndex = 1;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(129, 529);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(395, 529);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 8;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Location = new System.Drawing.Point(234, 529);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 6;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 534);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Load Parameters";
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 530);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 4;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 529);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 7;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.verticalGateButton);
            this.groupBox4.Controls.Add(this.inlinePrevCheckBox);
            this.groupBox4.Controls.Add(this.inlinePrevUpDown);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(3, 397);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(469, 60);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Subselection";
            // 
            // groupBoxSomOut
            // 
            this.groupBoxSomOut.Controls.Add(this.kohonenOutBox);
            this.groupBoxSomOut.Controls.Add(this.label9);
            this.groupBoxSomOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSomOut.Location = new System.Drawing.Point(3, 463);
            this.groupBoxSomOut.Name = "groupBoxSomOut";
            this.groupBoxSomOut.Size = new System.Drawing.Size(469, 60);
            this.groupBoxSomOut.TabIndex = 3;
            this.groupBoxSomOut.TabStop = false;
            this.groupBoxSomOut.Text = "Output";
            // 
            // kohonenOutBox
            // 
            this.kohonenOutBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kohonenOutBox.Location = new System.Drawing.Point(122, 19);
            this.kohonenOutBox.Name = "kohonenOutBox";
            this.kohonenOutBox.Size = new System.Drawing.Size(339, 20);
            this.kohonenOutBox.TabIndex = 0;
            this.kohonenOutBox.Text = "Facies Classes";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Kohonen cube output:";
            // 
            // KohonenFaciesWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBoxSomOut);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.loadDrop);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.applyButton);
            this.Name = "KohonenFaciesWorkstepUI";
            this.Size = new System.Drawing.Size(480, 696);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.discretizationUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.neuronsYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.neuronsXUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlinePrevUpDown)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBoxSomOut.ResumeLayout(false);
            this.groupBoxSomOut.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox retrainNetCheckBox;
        private System.Windows.Forms.NumericUpDown discretizationUpDown;
        private System.Windows.Forms.NumericUpDown neuronsYUpDown;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown neuronsXUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button verticalGateButton;
        private System.Windows.Forms.Button saveNetButton;
        private System.Windows.Forms.Button loadNetButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton immersionRadioButton;
        private System.Windows.Forms.RadioButton watershedRadioButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button plotButton;
        private System.Windows.Forms.NumericUpDown inlinePrevUpDown;
        private System.Windows.Forms.CheckBox inlinePrevCheckBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox volumeListBox;
        private System.Windows.Forms.Label label8;
        private Slb.Ocean.Petrel.UI.DropTarget addVolumeCubeDrop;
        private System.Windows.Forms.Button removeWellButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.Label label10;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBoxSomOut;
        private System.Windows.Forms.TextBox kohonenOutBox;
        private System.Windows.Forms.Label label9;
    }
}
