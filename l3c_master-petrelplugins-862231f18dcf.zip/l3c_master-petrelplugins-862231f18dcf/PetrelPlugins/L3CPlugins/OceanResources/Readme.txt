Instruction for OceanRibbon.xml:

1) OceanRibbon.xml configures Ocean Ribbon where the command you created will be available. 
2) Use Ctrl+F2 to launch Configuration designer in Petrel 2015 after installing your plug-in.
3) More instruction can be found in Ocean CHM help file under ''QuickStart For Ocean UX'' on how to customized your UI using Configuration Designer.
