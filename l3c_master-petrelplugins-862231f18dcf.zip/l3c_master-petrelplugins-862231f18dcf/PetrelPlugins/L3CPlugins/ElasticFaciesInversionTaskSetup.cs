﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UFSC_Plugins
{
    class ElasticFaciesInversionTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel[] _cubeseis;
        public FaciesElasticInversionCLI.ParametersCLI _p;
        public CubeFromPetrel[] _cuberesidout, _cube_vpvsrho_out, _cube_facies_prop_out;
        public CubeFromPetrel _cube_most_likely_facies_out;
        public int progressPct = 0;
        public String _statusMsg = "";
        public Tuple<double[], double>[] _wavelets;
        public double srate = 0.004;
        public double[] _angles;
        public FaciesElasticInversionCLI belfi = null;

        public ElasticFaciesInversionTaskSetup(ref CubeFromPetrel[] seis,
            ref FaciesElasticInversionCLI.ParametersCLI pars, ref CubeFromPetrel[] vpvsrho, ref CubeFromPetrel[] resid_out,
            ref CubeFromPetrel most_likely_facies, ref CubeFromPetrel[] facies_prob,
            ref double[][] wavelets, double[] angles)
        {
            _cubeseis = seis;
            _p = pars;
            _cuberesidout = resid_out;
            _cube_vpvsrho_out = vpvsrho;
            _cube_most_likely_facies_out = most_likely_facies;
            _cube_facies_prop_out = facies_prob;
            _angles = angles;
            _wavelets = new Tuple<double[], double>[wavelets.Length];
            int i = 0;
            foreach (var w in wavelets)
                _wavelets[i++] = new Tuple<double[], double>(w, pars.interval_frequency_sec * 1000);
        }

        public int progress()
        {
            if (belfi != null)
            {
                int prog = belfi.getProgress();
                return prog;
            }
            return 0;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}
