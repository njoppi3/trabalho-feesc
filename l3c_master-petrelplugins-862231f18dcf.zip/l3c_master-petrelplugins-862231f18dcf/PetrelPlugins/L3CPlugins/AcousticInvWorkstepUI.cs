using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject;
using Newtonsoft.Json;
using Slb.Ocean.Petrel;
using Slb.Ocean.Core;

namespace UFSC_Plugins {
    partial class AcousticInvWorkstepUI : UserControl {
        private AcousticInvWorkstep workstep;
        private AcousticInvWorkstep.Arguments args;
        private WorkflowContext context;
        Droid waveletDroid;
        Droid waveletCubeDroid;
        Droid seismicCubeDroid;
        Droid impedanceCubeDroid;

        VerticalGate vertGate;

        string type;

        /**
         * Constructor
         */
        public AcousticInvWorkstepUI(AcousticInvWorkstep workstep, AcousticInvWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            vertGate = new VerticalGate();

            type = "AcousticInv";

            if (context != null)
                try {
                    // when workstep is reopen in workflow, this fill the interface with the args
                    fillInterface(args.structure);
                } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Open Vertical Gate
         */
        private void verticalGateButton_Click(object sender, EventArgs e) {
            vertGate.Show(this);
        }

        /**
         * Get Wavelet or the Cube from Petrel
         */
        private void waveletDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (singleWvltRadio.Checked) {
                Droid droidObj = Functions.dragDropWavelet(isInWorkflow(), dropped);

                ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
                if (refVar != null) {
                    waveletDroid = droidObj;
                    typeWaveletPresentationBox.Text = refVar.Name;
                } else {
                    Wavelet wvlt = Functions.getWavelet(droidObj);
                    if (wvlt != null) {
                        waveletDroid = droidObj;
                        typeWaveletPresentationBox.Text = wvlt.Name;
                        wvlt.Deleted += inputWavelet_Deleted;
                    }
                }
            } else {
                Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

                ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
                if (refVar != null) {
                    waveletCubeDroid = droidObj;
                    typeWaveletPresentationBox.Text = refVar.Name;
                } else {
                    SeismicCube cubeTemp = Functions.getCube(droidObj);
                    if (cubeTemp != null) {
                        waveletCubeDroid = droidObj;
                        typeWaveletPresentationBox.Text = cubeTemp.Name;
                        cubeTemp.Deleted += inputWaveletCube_Deleted;
                    }
                }
            }
        }

        private void inputWavelet_Deleted(object sender, EventArgs e)
        {
            Wavelet w = sender as Wavelet;
            if (w != null && w.Droid.Equals(waveletDroid))
            {
                waveletDroid = null;
                typeWaveletPresentationBox.Text = "";
                PetrelLogger.InfoBox(w.Name + "was deleted and removed from Acoustic Inversion inputs.");
            }
        }

        private void inputWaveletCube_Deleted(object sender, EventArgs e)
        {
            SeismicCube wc = sender as SeismicCube;
            if (wc != null && wc.Droid.Equals(waveletCubeDroid))
            {
                waveletCubeDroid = null;
                typeWaveletPresentationBox.Text = "";
                PetrelLogger.InfoBox(wc.Name + "was deleted and removed from Acoustic Inversion inputs.");
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void seismicCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                seismicCubeDroid = droidObj;
                seismicCubePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    seismicCubeDroid = droidObj;
                    seismicCubePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += inputVolume_Deleted;
                }

                Cursor.Current = Cursors.WaitCursor;
                double seisstd = Functions.computeStd(cubeTemp);
                Cursor.Current = Cursors.Default;
                labelSeisStd.Text = seisstd.ToString("0.#####");
                labelSuggStd.Text = (seisstd / 2.645).ToString("0.#####");  // SNR = 7, thus diving std by sqrt(7)
            }
        }

        private void inputVolume_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s != null && s.Droid.Equals(seismicCubeDroid))
            {
                seismicCubeDroid = null;
                seismicCubePresentationBox.Text = "";
                PetrelLogger.InfoBox(s.Name + "was deleted and removed from Acoustic Inversion inputs.");
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void impedanceDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                impedanceCubeDroid = droidObj;
                impedanceCubePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    impedanceCubeDroid = droidObj;
                    impedanceCubePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += impedanceVolume_Deleted;
                }
            }
        }

        private void impedanceVolume_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s != null && s.Droid.Equals(seismicCubeDroid))
            {
                impedanceCubeDroid = null;
                impedanceCubePresentationBox.Text = "";
                PetrelLogger.InfoBox(s.Name + "was deleted and removed from Acoustic Inversion inputs.");
            }
        }

        /**
         * Listens to the wavelet radio status to change the displayed text
         */
        private void singleWvltRadio_CheckedChanged(object sender, EventArgs e) {
            typeWaveletPresentationBox.Text = "";
        }

        /**
         * Check if the wavelet is filled
         */
        private bool checkWavelet() {
            if (waveletDroid == null) {
                PetrelLogger.ErrorBox("Please select a wavelet");
                return false;
            }
            return true;
        }

        /**
         * Check if the cubes are filled
         */
        private bool checkCubes() {
            if (seismicCubeDroid == null || impedanceCubeDroid == null) {
                PetrelLogger.ErrorBox("Please select a Seismic Cube and a Trend Cube");
                return false;
            }
            return true;
        }

        /**
         * Acoustic Struct
         */
        public struct AcousticInvStruct {
            //inputs
            public bool loadSingleWavlt;
            public string waveletDroid, seismicCubeDroid, impedanceCubeDroid;
            //parameters
            public decimal impedUncertainty, signaltoNoise, correlRange;
            //options     -- CB = CheckBox  -- pra diferenciar os bool dos double
            public bool trendFreqCB, inlineInvCB, horizonCorrelCB, mergeInv;
            public decimal trendFreq, inlineInv, horizonCorrel;
            public decimal windowSize;
            //output
            public string impedOut, residual;
            public double posteriorStdDev;
            //vertGate
            public string topDroid, bottomDroid;
            public double topOffset, bottomOffset;

            public AcousticInvStruct(AcousticInvWorkstepUI workstepUI) {
                try {
                    //inputs
                    loadSingleWavlt = workstepUI.singleWvltRadio.Checked;
                    if (loadSingleWavlt) {
                        waveletDroid = workstepUI.waveletDroid.ToString();
                    } else {
                        waveletDroid = workstepUI.waveletCubeDroid.ToString();
                    }
                    seismicCubeDroid = workstepUI.seismicCubeDroid.ToString();
                    impedanceCubeDroid = workstepUI.impedanceCubeDroid.ToString();
                    //parameters
                    impedUncertainty = workstepUI.impedUncertaintyUpDown.Value;
                    signaltoNoise = workstepUI.signalToNoiseUpDown.Value;
                    correlRange = workstepUI.correlationRangeUpDown.Value;
                    //options
                    trendFreqCB = workstepUI.TrendFreqCheck.Checked;
                    inlineInvCB = workstepUI.inlineInversionCheck.Checked;
                    horizonCorrelCB = workstepUI.horizonCorrelatCheck.Checked;
                    mergeInv = workstepUI.mergeInvTrendCheck.Checked;
                    trendFreq = workstepUI.trendFreqUpDown.Value;
                    inlineInv = workstepUI.inlineInversionUpDown.Value;
                    horizonCorrel = workstepUI.horizonCorrelatUpDown.Value;
                    windowSize = workstepUI.windowSizeUpDown.Value;
                    //output
                    impedOut = workstepUI.impedOutBox.Text;
                    residual = workstepUI.residualBox.Text;
                    posteriorStdDev = Convert.ToDouble(workstepUI.posteriorStdDevLabel.Text);
                    //vertGate
                    topDroid = workstepUI.vertGate.getTopDroid();
                    bottomDroid = workstepUI.vertGate.getBottomDroid();
                    topOffset = workstepUI.vertGate.getTopOffset();
                    bottomOffset = workstepUI.vertGate.getBottomOffset();
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            AcousticInvStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<AcousticInvStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: Não é um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            fillInterface(result);
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        void fillInterface(AcousticInvStruct structure) {
            try {
                //inputs
                if (structure.loadSingleWavlt) {
                    singleWvltRadio.Checked = true;
                    if (structure.waveletDroid != null) {
                        waveletDroid = new Droid(structure.waveletDroid);
                        Wavelet wavelet = Functions.getWavelet(waveletDroid);
                        if (wavelet != null) {
                            typeWaveletPresentationBox.Text = wavelet.Name;
                        } else {
                            typeWaveletPresentationBox.Text = Functions.getReferenceVariable(waveletDroid).Name;
                        }
                    }
                } else {
                    cubeWvltRadio.Checked = true;
                    if (structure.waveletDroid != null) {
                        waveletCubeDroid = new Droid(structure.seismicCubeDroid);
                        SeismicCube cube = Functions.getCube(waveletCubeDroid);
                        if (cube != null) {
                            typeWaveletPresentationBox.Text = cube.Name;
                        } else {
                            typeWaveletPresentationBox.Text = Functions.getReferenceVariable(waveletCubeDroid).Name;
                        }
                    } else {
                        waveletCubeDroid = null;
                    }
                }
                if (structure.seismicCubeDroid != null) {
                    seismicCubeDroid = new Droid(structure.seismicCubeDroid);
                    SeismicCube cube = Functions.getCube(seismicCubeDroid);
                    if (cube != null) {
                        seismicCubePresentationBox.Text = cube.Name;
                    } else {
                        seismicCubePresentationBox.Text = Functions.getReferenceVariable(seismicCubeDroid).Name;
                    }
                }
                if (structure.impedanceCubeDroid != null) {
                    impedanceCubeDroid = new Droid(structure.impedanceCubeDroid);
                    SeismicCube cube = Functions.getCube(impedanceCubeDroid);
                    if (cube != null) {
                        impedanceCubePresentationBox.Text = cube.Name;
                    } else {
                        impedanceCubePresentationBox.Text = Functions.getReferenceVariable(impedanceCubeDroid).Name;
                    }
                }
                //parameters
                impedUncertaintyUpDown.Value = structure.impedUncertainty;
                signalToNoiseUpDown.Value = structure.signaltoNoise;
                correlationRangeUpDown.Value = structure.correlRange;
                //options
                TrendFreqCheck.Checked = structure.trendFreqCB;
                inlineInversionCheck.Checked = structure.inlineInvCB;
                horizonCorrelatCheck.Checked = structure.horizonCorrelCB;
                mergeInvTrendCheck.Checked = structure.mergeInv;
                trendFreqUpDown.Value = structure.trendFreq;
                inlineInversionUpDown.Value = structure.inlineInv;
                horizonCorrelatUpDown.Value = structure.horizonCorrel;
                windowSizeUpDown.Value = structure.windowSize;
                //output
                impedOutBox.Text = structure.impedOut;
                residualBox.Text = structure.residual;
                posteriorStdDevLabel.Text = structure.posteriorStdDev.ToString("0.###");
                //vertGate
                vertGate.setTopDroid(structure.topDroid);
                vertGate.setBottomDroid(structure.bottomDroid);
                vertGate.setTopOffset(structure.topOffset);
                vertGate.setBottomOffset(structure.bottomOffset);

            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // create the structure
            AcousticInvStruct myStruct = new AcousticInvStruct(this);
            // call saveCustomObject function
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {
            if (!checkCubes() || !checkWavelet())
                return false;
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form) this.TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            // if the fields are correct
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new AcousticInvStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new AcousticInvStruct(this);
                    try {
                        Enabled = false;
                        fillInterface(args.structure);
                        workstep.GetExecutor(args, null).ExecuteSimple();
                        Enabled = true;
                        fillInterface(args.structure);
                    } catch (Exception err) {
                        PetrelLogger.ErrorBox(err.ToString());
                        Enabled = true;
                        fillInterface(args.structure);
                    }
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            // if the fields are correct
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new AcousticInvStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new AcousticInvStruct(this);
                    try {
                        Enabled = false;
                        fillInterface(args.structure);
                        workstep.GetExecutor(args, null).ExecuteSimple();
                        Enabled = true;
                        fillInterface(args.structure);
                    } catch (Exception err) {
                        PetrelLogger.ErrorBox(err.ToString());
                        Enabled = true;
                        fillInterface(args.structure);
                    }
                }
                ((Form) TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }
    }
}
