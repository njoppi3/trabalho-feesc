using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using System.Collections.Generic;
using Slb.Ocean.Petrel;
using Newtonsoft.Json;
using System.Linq;

namespace UFSC_Plugins {
    partial class KohonenFaciesWorkstepUI : UserControl {
        private KohonenFaciesWorkstep workstep;
        private KohonenFaciesWorkstep.Arguments args;
        private WorkflowContext context;
        private KohonenFaciesWorkstep.Executor kex;
        private Plot plot_;

        List<Droid> volumeCubeDroidList;
        VerticalGate vertGate;

        string type;

        /**
         * Constructor
         */
        public KohonenFaciesWorkstepUI(KohonenFaciesWorkstep workstep, KohonenFaciesWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            volumeCubeDroidList = new List<Droid>();

            vertGate = new VerticalGate();

            type = "Kohonen";

            if (context != null)
            {
                try
                {
                    // when workstep is reopen in workflow, this fill the interface with the args
                    fillInterface(args.structure);
                }
                catch (Exception) { }
            }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Open Vertical Gate
         */
        private void verticalGateButton_Click(object sender, EventArgs e) {
            vertGate.Show(this);
        }

        /**
         * Get Cube from Petrel
         */
        private void addVolumeCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                foreach (Droid droid in volumeCubeDroidList) {
                    if (droid == droidObj) {
                        PetrelLogger.InfoBox("This volume has already been added to the list.");
                        return;
                    }
                }
                volumeCubeDroidList.Add(refVar.Droid);
                int volumeCount = volumeCubeDroidList.Count;
                volumeListBox.Items.Add(volumeCount.ToString() + " - " + refVar.Name);
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    foreach (Droid droid in volumeCubeDroidList) {
                        if (droid == cubeTemp.Droid) {
                            PetrelLogger.InfoBox("This volume has already been added to the list.");
                            return;
                        }
                    }
                    volumeCubeDroidList.Add(cubeTemp.Droid);
                    int volumeCount = volumeCubeDroidList.Count;
                    volumeListBox.Items.Add(volumeCount.ToString() + " - " + cubeTemp.Name);
                    cubeTemp.Deleted += inputVolume_Deleted;
                }
            }
        }

        private void inputVolume_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            var volCubeDroid_tmp = volumeCubeDroidList;
            for (int i = 0; i < volumeCubeDroidList.Count; ++i)
            {
                if (volumeCubeDroidList[i].Equals(s.Droid))
                {
                    volCubeDroid_tmp.RemoveAt(i);
                    volumeListBox.Items.RemoveAt(i);
                    PetrelLogger.WarnBox(s.Name + " was deleted and removed from Kohonen input volumes list.");
                }
            }
            volumeCubeDroidList = volCubeDroid_tmp;
        }

        /**
         * Remove Well and refresh the list
         */
        private void removeVolumeButton_Click(object sender, EventArgs e) {

            int indexRemove = volumeListBox.SelectedIndex;
            if (indexRemove < 0) {
                PetrelLogger.InfoBox("Select a cube");
                return;
            }
            volumeCubeDroidList.RemoveAt(indexRemove);
            volumeListBox.Items.Clear();
            int i = 0;
            foreach (Droid droid in volumeCubeDroidList) {
                SeismicCube cube = Functions.getCube(droid);
                if (cube != null) {
                    volumeListBox.Items.Add(++i + " - " + cube.Name);
                } else {
                    string referenceVarName = Functions.getReferenceVariable(droid).Name;
                    volumeListBox.Items.Add(++i + " - " + referenceVarName);
                }
            }
        }

        /**
         * Kohonen Facies Struct 
         */
        public struct KohonenFaciesStruct {
            //inputs
            public string[] volumeCubeListDroid;
            //options
            public decimal neuronsX, neuronsY, discretization;
            public bool retrainNetCB, inlinePrevCB;
            public decimal inlinePrev;
            public bool watershed;
            //vertGate
            public string topDroid, bottomDroid;
            public double topOffset, bottomOffset;
            //output
            public string cubeOutName;

            public KohonenFaciesStruct(KohonenFaciesWorkstepUI workstepUI) {
                try {
                    //inputs
                    volumeCubeListDroid = null;
                    if (workstepUI.volumeCubeDroidList.Count > 0) {
                        volumeCubeListDroid = new string[workstepUI.volumeCubeDroidList.Count];
                        int i = 0;
                        foreach (Droid cubeDroid in workstepUI.volumeCubeDroidList) {
                            volumeCubeListDroid[i++] = cubeDroid.ToString();
                        }
                    }
                    //parameters
                    neuronsX = workstepUI.neuronsXUpDown.Value;
                    neuronsY = workstepUI.neuronsYUpDown.Value;
                    discretization = workstepUI.discretizationUpDown.Value;
                    retrainNetCB = workstepUI.retrainNetCheckBox.Checked;
                    inlinePrevCB = workstepUI.inlinePrevCheckBox.Checked;
                    inlinePrev = workstepUI.inlinePrevUpDown.Value;
                    watershed = workstepUI.watershedRadioButton.Checked;
                    //vertGate
                    topDroid = workstepUI.vertGate.getTopDroid();
                    bottomDroid = workstepUI.vertGate.getBottomDroid();
                    topOffset = workstepUI.vertGate.getTopOffset();
                    bottomOffset = workstepUI.vertGate.getBottomOffset();
                    cubeOutName = workstepUI.kohonenOutBox.Text;

                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            KohonenFaciesStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<KohonenFaciesStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: N�o � um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            // fill the interface atributs with result
            fillInterface(result);
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        private void fillInterface(KohonenFaciesStruct structure) {
            try {
                //inputs
                volumeCubeDroidList.Clear();
                volumeListBox.Items.Clear();
                if (structure.volumeCubeListDroid != null) {
                    int i = 0;
                    foreach (string droidStr in structure.volumeCubeListDroid) {
                        Droid cubeDroid = new Droid(droidStr);
                        volumeCubeDroidList.Add(cubeDroid);
                        SeismicCube cube = Functions.getCube(cubeDroid);
                        if (cube != null) {
                            volumeListBox.Items.Add(++i + " - " + cube.Name);
                            cube.Deleted += inputVolume_Deleted;
                        } else {
                            string referenceVarName = Functions.getReferenceVariable(cubeDroid).Name;
                            volumeListBox.Items.Add(++i + " - " + referenceVarName);
                        }
                    }
                }
                //parameters
                neuronsXUpDown.Value = structure.neuronsX;
                neuronsYUpDown.Value = structure.neuronsY;
                discretizationUpDown.Value = structure.discretization;
                retrainNetCheckBox.Checked = structure.retrainNetCB;
                inlinePrevCheckBox.Checked = structure.inlinePrevCB;
                inlinePrevUpDown.Value = structure.inlinePrev;
                if (structure.watershed) {
                    watershedRadioButton.Checked = true;
                } else {
                    immersionRadioButton.Checked = true;
                }
                //vertGate
                vertGate.setTopDroid(structure.topDroid);
                vertGate.setBottomDroid(structure.bottomDroid);
                vertGate.setTopOffset(structure.topOffset);
                vertGate.setBottomOffset(structure.bottomOffset);

            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // cria a estrutura
            KohonenFaciesStruct myStruct = new KohonenFaciesStruct(this);
            // call saveCustomObject function with the JSON serialized struct
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {
            // inputs
            if (volumeCubeDroidList.Count < 1)
                return false;
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)this.TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new KohonenFaciesStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new KohonenFaciesStruct(this);
                    kex = (KohonenFaciesWorkstep.Executor)workstep.GetExecutor(args, null);
                    kex.ExecuteSimple();
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new KohonenFaciesStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new KohonenFaciesStruct(this);
                    try {
                        Enabled = false;
                        kex = (KohonenFaciesWorkstep.Executor)workstep.GetExecutor(args, null);
                        kex.ExecuteSimple();
                        Enabled = true;
                    } catch (Exception err) {
                        PetrelLogger.ErrorBox(err.ToString());
                        Enabled = true;
                    }
                }
                ((Form)TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }
        private void PlotButton_Click(object sender, EventArgs e)
        {
            if (plot_ != null)
                plot_.Close();
            plot_ = new Plot();
            double[] d = null;
            if (kex != null)
                if (kex.ktask != null)
                    if (kex.ktask.kf != null)
                        d = kex.ktask.kf.getImmOrWatershedM(args.structure.watershed);
            else
            {
                PetrelLogger.ErrorBox("No network was trained.");
                return;
            }
            try
            {
                plot_.setMapData(d, Convert.ToInt32(args.structure.neuronsX), Convert.ToInt32(args.structure.neuronsY), args.structure.watershed);
                plot_.Show();
            }
            catch (Exception ex)
            {
                PetrelLogger.ErrorBox("Could not plot Kohonen results: " + ex.Message);
            }
        }

        private void ClassificationRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            args.structure.watershed = watershedRadioButton.Checked;
        }

        private void RetrainNetCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            args.structure.retrainNetCB = retrainNetCheckBox.Checked;
        }
    }
}
