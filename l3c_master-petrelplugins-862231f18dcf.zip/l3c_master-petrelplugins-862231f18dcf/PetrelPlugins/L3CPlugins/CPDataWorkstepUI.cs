﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Slb.Ocean.Petrel.DomainObject.Well;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Newtonsoft.Json;

namespace UFSC_Plugins {
    partial class CPDataWorkstepUI : UserControl {

        private CPDataWorkstep workstep;
        private CPDataWorkstep.Arguments args;
        private WorkflowContext context;

        Droid cubeXDroid, cubeYDroid;

        crossplot cp;
        double[][] data;
        double[] mu_x;
        double[] mu_y;
        double[] priorProbs;
        string type;

        /**
         * Constructor
         */
        public CPDataWorkstepUI(CPDataWorkstep workstep, CPDataWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            data = null;
            mu_x = null;
            mu_y = null;
            cubeXDroid = null;
            cubeYDroid = null;

            cp = new crossplot();

            type = "CrossPlot";

            wellLogSelect1.enableLogDrops(true, 2);
            wellLogSelect1.setTimeText("Facies log");
            wellLogSelect1.needsTWT = false;
            wellLogSelect1.disableZlog();

            try {
                // when workstep is reopen in workflow, this fill the interface with the args
                fillInterface(args.structure);
            } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Joins the data and separates by line, to write to a file, then opens the standalone_priors.exe
         */
        private void buttonOpenCrossP_Click(object sender, EventArgs e) {

            if (wellLogSelect1.m_xLog == null || wellLogSelect1.m_yLog == null) {
                PetrelLogger.ErrorBox("Plese select at least one log for X and Y.");
                return;
            }

            priorProbs = getPriorsProbs();

            string logXDroid = null;
            if (wellLogSelect1.m_xLog != null)
                logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
            string logYDroid = null;
            if (wellLogSelect1.m_yLog != null)
                logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
            string faciesDroid = null;
            if (wellLogSelect1.m_timeLog != null)
                faciesDroid = wellLogSelect1.m_timeLog.Droid.ToString();
            if (wellLogSelect1.m_faciesLog != null)
                faciesDroid = wellLogSelect1.m_faciesLog.Droid.ToString();

            List<string> wellDroid = wellLogSelect1.getWellDroids();
            List<WellLogSample> aiList;
            List<WellLogSample> phiList;
            List<WellLogSample> faciesList;

            Functions.getAllLists(wellDroid, logXDroid, logYDroid, faciesDroid, out aiList, out phiList, out faciesList);
            WellLogVersion globalxLog = Functions.getWellLogVersion(new Droid(logXDroid));
            WellLogVersion globalyLog = Functions.getWellLogVersion(new Droid(logYDroid));

            try {
                // fill the standalone_priors.exe with the data and open it
                CPDataWorkstep.setCPData(aiList, phiList, faciesList, cp);
                cp.setXText(globalxLog.Name + " (" + globalxLog.Template.PetrelMeasurement.Units.First().DisplaySymbol + ")");
                cp.setYText(globalyLog.Name + " (" + globalyLog.Template.PetrelMeasurement.Units.First().DisplaySymbol + ")");
                cp.show();
                loadPriors();
            } catch (Exception except) {
                PetrelLogger.InfoBox("Error:\n\n" + except.ToString());
                return;
            }
        }


        /**
         * Load the Priors data and mean, display the means in the dataGridView2
         */
        private void loadPriors() {
            data = null;
            mu_x = null;
            mu_y = null;
            cp.getPriors(ref data, ref mu_x, ref mu_y);
            
            dataGridView2.Rows.Clear();
            for (int i = 0; i < mu_x.Count(); i++) {
                double priorprop = 1;
                if (priorProbs.Length > i)
                    priorprop = priorProbs[i];
                dataGridView2.Rows.Add(cp.getPriorName(i), priorprop,  mu_x[i], mu_y[i]);
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void dropCube1_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                cubeXDroid = droidObj;
                cube1PresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    cubeXDroid = droidObj;
                    cube1PresentationBox.Text = cubeTemp.Name;
                }
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void dropCube2_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                cubeYDroid = droidObj;
                cube2PresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    cubeYDroid = droidObj;
                    cube2PresentationBox.Text = cubeTemp.Name;
                }
            }
        }

        /**
         * CrossPlot Struct
         */
        public struct CPDataStruct {
            public string logXDroid, logYDroid, faciesDroid;
            public double[] muX, muY;
            public double[][] data;
            public string cubeXDroid, cubeYDroid;
            public string output;
            public List<string> wellDroids;
            public double[] priorProbs;
            public List<string> priorNames;

            public CPDataStruct(CPDataWorkstepUI workstepUI) {
                try {
                    logXDroid = null;
                    logYDroid = null;
                    faciesDroid = null;

                    WellLogSelect wellLogSelect1 = workstepUI.wellLogSelect1;
                    if (wellLogSelect1.m_xLog != null)
                        logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
                    if (wellLogSelect1.m_yLog != null)
                        logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
                    if (wellLogSelect1.m_timeLog != null)
                        faciesDroid = wellLogSelect1.m_timeLog.Droid.ToString();

                    wellDroids = wellLogSelect1.getWellDroids();
                    data = null;
                    muX = null;
                    muY = null;
                    priorProbs = null;
                    priorProbs = workstepUI.getPriorsProbs();
                    priorNames = workstepUI.getPriorNames();
                    workstepUI.cp.getPriors(ref data, ref muX, ref muY);
                    if (workstepUI.cubeXDroid != null)
                        cubeXDroid = workstepUI.cubeXDroid.ToString();
                    else
                        cubeXDroid = null;
                    if (workstepUI.cubeYDroid != null)
                        cubeYDroid = workstepUI.cubeYDroid.ToString();
                    else
                        cubeYDroid = null;
                    output = workstepUI.outputCubeName.Text;
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        private List<string> getPriorNames()
        {
            List<string> probNames = new List<string>();

            foreach (DataGridViewRow r in dataGridView2.Rows)
            {
                probNames.Add(r.Cells[0].Value.ToString());
            }

            return probNames;
        }

        private double[] getPriorsProbs()
        {
            double[] probs = new double[dataGridView2.RowCount];
            int i = 0;

            foreach (DataGridViewRow r in dataGridView2.Rows)
            {
                probs[i] = Convert.ToDouble(r.Cells[1].Value.ToString());
                i++;
            }

            return probs;
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            CPDataStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<CPDataStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: Não é um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            fillInterface(result);
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        void fillInterface(CPDataStruct structure) {
            try {
                data = structure.data;
                mu_x = structure.muX;
                mu_y = structure.muY;
                priorProbs = structure.priorProbs;

                dataGridView2.Rows.Clear();

                string logXDroid = structure.logXDroid;
                string logYDroid = structure.logYDroid;
                string faciesDroid = structure.faciesDroid;
                List<string> wellDroid = structure.wellDroids;
                List<WellLogSample> aiList;
                List<WellLogSample> phiList;
                List<WellLogSample> faciesList;

                Functions.getAllLists(wellDroid, logXDroid, logYDroid, faciesDroid, out aiList, out phiList, out faciesList);

                wellLogSelect1.clearWellsLogs();
                if (faciesDroid != null)
                    wellLogSelect1.setLogTime(Functions.getWellLogVersion(new Droid(faciesDroid)));
                if (logXDroid != null)
                    wellLogSelect1.setLogX(Functions.getWellLogVersion(new Droid(logXDroid)));
                if (logYDroid != null)
                    wellLogSelect1.setLogY(Functions.getWellLogVersion(new Droid(logYDroid)));
                if (wellDroid != null && wellDroid.Count > 0)
                    wellLogSelect1.addWells(wellDroid);


                if ((data != null) && (mu_x != null) && (mu_y != null)) {
                    CPDataWorkstep.setCPData(aiList, phiList, faciesList, cp);
                    if (mu_x.Count() > 0)
                        cp.setPriors(ref data, ref mu_x, ref mu_y);
                    for (int i = 0; i < mu_x.Count(); i++) {
                        dataGridView2.Rows.Add(structure.priorNames[i], priorProbs[i], mu_x[i], mu_y[i]);
                    }
                }

                if (structure.cubeXDroid != null) {
                    cubeXDroid = new Droid(structure.cubeXDroid);
                    SeismicCube cube = Functions.getCube(cubeXDroid);
                    if (cube != null) {
                        cube1PresentationBox.Text = cube.Name;
                    } else {
                        cube1PresentationBox.Text = Functions.getReferenceVariable(cubeXDroid).Name;
                    }
                } else {
                    cubeXDroid = null;
                    cube1PresentationBox.Text = "";
                }
                if (structure.cubeYDroid != null) {
                    cubeYDroid = new Droid(structure.cubeYDroid);
                    SeismicCube cube = Functions.getCube(cubeYDroid);
                    if (cube != null) {
                        cube2PresentationBox.Text = cube.Name;
                    } else {
                        cube2PresentationBox.Text = Functions.getReferenceVariable(cubeYDroid).Name;
                    }
                } else {
                    cubeYDroid = null;
                    cube2PresentationBox.Text = "";
                }

                outputCubeName.Text = structure.output;
            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // cria a estrutura
            CPDataStruct myStruct = new CPDataStruct(this);
            // call saveCustomObject function
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {

            if (wellLogSelect1.m_xLog == null || wellLogSelect1.m_yLog == null) {
                PetrelLogger.InfoBox("Error:\n\nSelect the Log X and Log Y");
                return false;
            }
            if (mu_x.Count() <= 0) {
                PetrelLogger.InfoBox("Error:\n\nInsufficient number of priors!\nOpen the Cross Plot and set the prior(s).");
                return false;
            }
            if (cubeXDroid == null) {
                PetrelLogger.InfoBox("Error:\n\nCube 1 is null!");
                return false;
            }
            if (cubeYDroid == null) {
                PetrelLogger.InfoBox("Error:\n\nCube 2 is null!");
                return false;
            }
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)this.TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new CPDataStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new CPDataStruct(this);
                    try {
                        Enabled = false;
                        workstep.GetExecutor(args, null).ExecuteSimple();
                        Enabled = true;
                    } catch (Exception err) {
                        PetrelLogger.ErrorBox(err.ToString());
                        Enabled = true;
                    }
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new CPDataStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new CPDataStruct(this);
                    try {
                        Enabled = false;
                        workstep.GetExecutor(args, null).ExecuteSimple();
                        Enabled = true;
                    } catch (Exception err) {
                        PetrelLogger.ErrorBox(err.ToString());
                        Enabled = true;
                    }
                }
                ((Form)TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

    }
}