﻿namespace UFSC_Plugins {
    partial class aiVsPhiPrior {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.Okbutton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.wellLogSelect1 = new UFSC_Plugins.WellLogSelect();
            this.SuspendLayout();
            // 
            // Okbutton
            // 
            this.Okbutton.Location = new System.Drawing.Point(298, 243);
            this.Okbutton.Name = "Okbutton";
            this.Okbutton.Size = new System.Drawing.Size(75, 23);
            this.Okbutton.TabIndex = 6;
            this.Okbutton.Text = "OK";
            this.Okbutton.UseVisualStyleBackColor = true;
            this.Okbutton.Click += new System.EventHandler(this.OkbuttonClick);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(217, 243);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 7;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // wellLogSelect1
            // 
            this.wellLogSelect1.Location = new System.Drawing.Point(12, 12);
            this.wellLogSelect1.Name = "wellLogSelect1";
            this.wellLogSelect1.Size = new System.Drawing.Size(374, 225);
            this.wellLogSelect1.TabIndex = 8;
            // 
            // aiVsPhiPrior
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 287);
            this.Controls.Add(this.wellLogSelect1);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.Okbutton);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "aiVsPhiPrior";
            this.Text = "Select Wells and logs for crossplot";
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Button Okbutton;
        public System.Windows.Forms.Button CancelButton;
        public WellLogSelect wellLogSelect1;
    }
}