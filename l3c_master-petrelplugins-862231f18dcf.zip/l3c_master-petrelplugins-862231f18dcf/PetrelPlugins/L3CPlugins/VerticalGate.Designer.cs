﻿namespace UFSC_Plugins {
    partial class VerticalGate {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.topUpDown = new System.Windows.Forms.NumericUpDown();
            this.okButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bottomUpDown = new System.Windows.Forms.NumericUpDown();
            this.topPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.topDropTarget = new Slb.Ocean.Petrel.UI.DropTarget();
            this.bottomPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.bottomDropTarget = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label7 = new System.Windows.Forms.Label();
            this.topDeleteButton = new System.Windows.Forms.Button();
            this.bottomDeleteButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.topUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // topUpDown
            // 
            this.topUpDown.Location = new System.Drawing.Point(83, 115);
            this.topUpDown.Maximum = new decimal(new int[] {
            276447231,
            23283,
            0,
            0});
            this.topUpDown.Minimum = new decimal(new int[] {
            -727379969,
            232,
            0,
            -2147483648});
            this.topUpDown.Name = "topUpDown";
            this.topUpDown.Size = new System.Drawing.Size(277, 20);
            this.topUpDown.TabIndex = 4;
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(159, 166);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 6;
            this.okButton.Text = "Ok";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Top:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Base:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(170, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Horizons";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(139, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Offset";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Base (ms):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Top (ms):";
            // 
            // bottomUpDown
            // 
            this.bottomUpDown.Location = new System.Drawing.Point(84, 141);
            this.bottomUpDown.Maximum = new decimal(new int[] {
            1316134911,
            2328,
            0,
            0});
            this.bottomUpDown.Minimum = new decimal(new int[] {
            -1530494977,
            232830,
            0,
            -2147483648});
            this.bottomUpDown.Name = "bottomUpDown";
            this.bottomUpDown.Size = new System.Drawing.Size(276, 20);
            this.bottomUpDown.TabIndex = 5;
            // 
            // topPresentationBox
            // 
            this.topPresentationBox.Location = new System.Drawing.Point(115, 36);
            this.topPresentationBox.Name = "topPresentationBox";
            this.topPresentationBox.Size = new System.Drawing.Size(211, 22);
            this.topPresentationBox.TabIndex = 34;
            this.topPresentationBox.TabStop = false;
            // 
            // topDropTarget
            // 
            this.topDropTarget.AllowDrop = true;
            this.topDropTarget.Location = new System.Drawing.Point(83, 35);
            this.topDropTarget.Name = "topDropTarget";
            this.topDropTarget.Size = new System.Drawing.Size(26, 23);
            this.topDropTarget.TabIndex = 0;
            this.topDropTarget.DragDrop += new System.Windows.Forms.DragEventHandler(this.TopDropTarget_DragDrop);
            // 
            // bottomPresentationBox
            // 
            this.bottomPresentationBox.Location = new System.Drawing.Point(115, 64);
            this.bottomPresentationBox.Name = "bottomPresentationBox";
            this.bottomPresentationBox.Size = new System.Drawing.Size(211, 22);
            this.bottomPresentationBox.TabIndex = 36;
            this.bottomPresentationBox.TabStop = false;
            // 
            // bottomDropTarget
            // 
            this.bottomDropTarget.AllowDrop = true;
            this.bottomDropTarget.Location = new System.Drawing.Point(83, 63);
            this.bottomDropTarget.Name = "bottomDropTarget";
            this.bottomDropTarget.Size = new System.Drawing.Size(26, 23);
            this.bottomDropTarget.TabIndex = 2;
            this.bottomDropTarget.DragDrop += new System.Windows.Forms.DragEventHandler(this.BottomDropTarget_DragDrop);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(177, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 37;
            this.label7.Text = "Offset";
            // 
            // topDeleteButton
            // 
            this.topDeleteButton.Location = new System.Drawing.Point(332, 36);
            this.topDeleteButton.Name = "topDeleteButton";
            this.topDeleteButton.Size = new System.Drawing.Size(28, 22);
            this.topDeleteButton.TabIndex = 1;
            this.topDeleteButton.Text = "X";
            this.topDeleteButton.UseVisualStyleBackColor = true;
            this.topDeleteButton.Click += new System.EventHandler(this.topDeleteButtonClick);
            // 
            // bottomDeleteButton
            // 
            this.bottomDeleteButton.Location = new System.Drawing.Point(332, 64);
            this.bottomDeleteButton.Name = "bottomDeleteButton";
            this.bottomDeleteButton.Size = new System.Drawing.Size(28, 22);
            this.bottomDeleteButton.TabIndex = 3;
            this.bottomDeleteButton.Text = "X";
            this.bottomDeleteButton.UseVisualStyleBackColor = true;
            this.bottomDeleteButton.Click += new System.EventHandler(this.bottomDeleteButton_Click);
            // 
            // VerticalGate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 201);
            this.ControlBox = false;
            this.Controls.Add(this.bottomDeleteButton);
            this.Controls.Add(this.topDeleteButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bottomPresentationBox);
            this.Controls.Add(this.bottomDropTarget);
            this.Controls.Add(this.topPresentationBox);
            this.Controls.Add(this.topDropTarget);
            this.Controls.Add(this.bottomUpDown);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.topUpDown);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "VerticalGate";
            this.ShowIcon = false;
            this.Text = "Vertical Gate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.VerticalGate_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.topUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown topUpDown;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown bottomUpDown;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox topPresentationBox;
        private Slb.Ocean.Petrel.UI.DropTarget topDropTarget;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox bottomPresentationBox;
        private Slb.Ocean.Petrel.UI.DropTarget bottomDropTarget;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button topDeleteButton;
        private System.Windows.Forms.Button bottomDeleteButton;
    }
}