namespace UFSC_Plugins
{
    partial class ElasticFaciesInversionWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Wavelett = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correlationRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.waveletDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.SNR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Angle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cube = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.inputCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.verticalGateButton = new System.Windows.Forms.Button();
            this.optionsCheckBox = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.inlineInvPreviewUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlineInvPreviewCheckBox = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.angleUpDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.signalToNoiseUpDown = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.aiVsPhiButton = new System.Windows.Forms.Button();
            this.openCPbutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.inputCubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.waveletPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.removeButton = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.labelFaciesProp = new System.Windows.Forms.Label();
            this.faciesPropOutTextBox = new System.Windows.Forms.TextBox();
            this.labelMostLikelyFacies = new System.Windows.Forms.Label();
            this.mostLikelyFaciesTextBox = new System.Windows.Forms.TextBox();
            this.labelResOut = new System.Windows.Forms.Label();
            this.labelRhoOut = new System.Windows.Forms.Label();
            this.labelVsOut = new System.Windows.Forms.Label();
            this.labelVpOut = new System.Windows.Forms.Label();
            this.residualCubeTextBox = new System.Windows.Forms.TextBox();
            this.rhoCubeTextBox = new System.Windows.Forms.TextBox();
            this.vsCubeTextBox = new System.Windows.Forms.TextBox();
            this.vpCubeTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.faciesPriorProportionUI1 = new UFSC_Plugins.FaciesPriorProportionUI();
            this.labelTransitionMatrix = new System.Windows.Forms.Label();
            this.faciesTransitionMatrixUI1 = new UFSC_Plugins.FaciesTransitionMatrixUI();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.labelSuggStd = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelSeisStd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPreviewUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angleUpDown)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // Wavelett
            // 
            this.Wavelett.HeaderText = "Wavelet";
            this.Wavelett.Name = "Wavelett";
            this.Wavelett.ReadOnly = true;
            // 
            // correlationRangeUpDown
            // 
            this.correlationRangeUpDown.DecimalPlaces = 2;
            this.correlationRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correlationRangeUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.correlationRangeUpDown.Location = new System.Drawing.Point(226, 48);
            this.correlationRangeUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.correlationRangeUpDown.Name = "correlationRangeUpDown";
            this.correlationRangeUpDown.Size = new System.Drawing.Size(212, 20);
            this.correlationRangeUpDown.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(99, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(112, 13);
            this.label17.TabIndex = 21;
            this.label17.Text = "Correlation range (ms):";
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(11, 101);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(91, 23);
            this.addButton.TabIndex = 4;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // waveletDrop
            // 
            this.waveletDrop.AllowDrop = true;
            this.waveletDrop.Location = new System.Drawing.Point(88, 17);
            this.waveletDrop.Name = "waveletDrop";
            this.waveletDrop.Size = new System.Drawing.Size(24, 22);
            this.waveletDrop.TabIndex = 0;
            this.waveletDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.waveletDrop_DragDrop);
            // 
            // SNR
            // 
            this.SNR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SNR.HeaderText = "SNR";
            this.SNR.Name = "SNR";
            this.SNR.ReadOnly = true;
            this.SNR.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Angle
            // 
            this.Angle.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Angle.HeaderText = "Angle";
            this.Angle.Name = "Angle";
            this.Angle.ReadOnly = true;
            // 
            // Cube
            // 
            this.Cube.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Cube.HeaderText = "Cube";
            this.Cube.Name = "Cube";
            this.Cube.ReadOnly = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Wavelett,
            this.Cube,
            this.Angle,
            this.SNR});
            this.dataGridView1.Location = new System.Drawing.Point(11, 130);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView1.Size = new System.Drawing.Size(428, 85);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 16;
            this.label19.Text = "Input Wavelet:";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(36, 858);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 13);
            this.label18.TabIndex = 62;
            this.label18.Text = "Load Parameters";
            // 
            // saveButton
            // 
            this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.saveButton.Location = new System.Drawing.Point(129, 853);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 58;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.applyButton.Location = new System.Drawing.Point(234, 853);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 59;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 853);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 60;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.closeButton.Location = new System.Drawing.Point(395, 853);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 61;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // inputCubeDrop
            // 
            this.inputCubeDrop.AllowDrop = true;
            this.inputCubeDrop.Location = new System.Drawing.Point(306, 18);
            this.inputCubeDrop.Name = "inputCubeDrop";
            this.inputCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.inputCubeDrop.TabIndex = 1;
            this.inputCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputCubeDrop_DragDrop);
            // 
            // verticalGateButton
            // 
            this.verticalGateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verticalGateButton.Location = new System.Drawing.Point(246, 16);
            this.verticalGateButton.Name = "verticalGateButton";
            this.verticalGateButton.Size = new System.Drawing.Size(191, 23);
            this.verticalGateButton.TabIndex = 5;
            this.verticalGateButton.Text = "Vertical Gate";
            this.verticalGateButton.UseVisualStyleBackColor = true;
            this.verticalGateButton.Click += new System.EventHandler(this.verticalGateButton_Click);
            // 
            // optionsCheckBox
            // 
            this.optionsCheckBox.AutoSize = true;
            this.optionsCheckBox.Checked = true;
            this.optionsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.optionsCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionsCheckBox.Location = new System.Drawing.Point(13, 599);
            this.optionsCheckBox.Name = "optionsCheckBox";
            this.optionsCheckBox.Size = new System.Drawing.Size(69, 17);
            this.optionsCheckBox.TabIndex = 3;
            this.optionsCheckBox.Text = "Options";
            this.optionsCheckBox.UseVisualStyleBackColor = true;
            this.optionsCheckBox.CheckedChanged += new System.EventHandler(this.optionsCheckBox_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(230, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Input Seismic:";
            // 
            // inlineInvPreviewUpDown
            // 
            this.inlineInvPreviewUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPreviewUpDown.Location = new System.Drawing.Point(148, 19);
            this.inlineInvPreviewUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.inlineInvPreviewUpDown.Name = "inlineInvPreviewUpDown";
            this.inlineInvPreviewUpDown.Size = new System.Drawing.Size(81, 20);
            this.inlineInvPreviewUpDown.TabIndex = 3;
            // 
            // inlineInvPreviewCheckBox
            // 
            this.inlineInvPreviewCheckBox.AutoSize = true;
            this.inlineInvPreviewCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPreviewCheckBox.Location = new System.Drawing.Point(6, 20);
            this.inlineInvPreviewCheckBox.Name = "inlineInvPreviewCheckBox";
            this.inlineInvPreviewCheckBox.Size = new System.Drawing.Size(136, 17);
            this.inlineInvPreviewCheckBox.TabIndex = 2;
            this.inlineInvPreviewCheckBox.Text = "Inline inversion preview";
            this.inlineInvPreviewCheckBox.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(199, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Seismic Noise Standard Deviation";
            // 
            // angleUpDown
            // 
            this.angleUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angleUpDown.Location = new System.Drawing.Point(91, 66);
            this.angleUpDown.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.angleUpDown.Name = "angleUpDown";
            this.angleUpDown.Size = new System.Drawing.Size(66, 20);
            this.angleUpDown.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Angle (degrees)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Parameters";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.verticalGateButton);
            this.groupBox4.Controls.Add(this.inlineInvPreviewUpDown);
            this.groupBox4.Controls.Add(this.inlineInvPreviewCheckBox);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(4, 603);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(450, 47);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            // 
            // signalToNoiseUpDown
            // 
            this.signalToNoiseUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signalToNoiseUpDown.Location = new System.Drawing.Point(372, 46);
            this.signalToNoiseUpDown.Maximum = new decimal(new int[] {
            -402653185,
            -1613725636,
            54210108,
            0});
            this.signalToNoiseUpDown.Name = "signalToNoiseUpDown";
            this.signalToNoiseUpDown.Size = new System.Drawing.Size(66, 20);
            this.signalToNoiseUpDown.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.optionsCheckBox);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Location = new System.Drawing.Point(4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(473, 846);
            this.panel1.TabIndex = 56;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.correlationRangeUpDown);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.aiVsPhiButton);
            this.groupBox6.Controls.Add(this.openCPbutton);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(4, 227);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(450, 75);
            this.groupBox6.TabIndex = 63;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Property prior p(m | k)";
            // 
            // aiVsPhiButton
            // 
            this.aiVsPhiButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aiVsPhiButton.Location = new System.Drawing.Point(11, 19);
            this.aiVsPhiButton.Name = "aiVsPhiButton";
            this.aiVsPhiButton.Size = new System.Drawing.Size(197, 23);
            this.aiVsPhiButton.TabIndex = 6;
            this.aiVsPhiButton.Text = "Settings";
            this.aiVsPhiButton.UseVisualStyleBackColor = true;
            this.aiVsPhiButton.Click += new System.EventHandler(this.aiVsPhiButton_Click);
            // 
            // openCPbutton
            // 
            this.openCPbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openCPbutton.Location = new System.Drawing.Point(226, 19);
            this.openCPbutton.Name = "openCPbutton";
            this.openCPbutton.Size = new System.Drawing.Size(213, 23);
            this.openCPbutton.TabIndex = 7;
            this.openCPbutton.Text = "Configure";
            this.openCPbutton.UseVisualStyleBackColor = true;
            this.openCPbutton.Click += new System.EventHandler(this.openCPbutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelSuggStd);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.labelSeisStd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.inputCubePresentationBox);
            this.groupBox1.Controls.Add(this.waveletPresentationBox);
            this.groupBox1.Controls.Add(this.removeButton);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.addButton);
            this.groupBox1.Controls.Add(this.waveletDrop);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.inputCubeDrop);
            this.groupBox1.Controls.Add(this.signalToNoiseUpDown);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.angleUpDown);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, -2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 223);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inputs (d)";
            // 
            // inputCubePresentationBox
            // 
            this.inputCubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputCubePresentationBox.Location = new System.Drawing.Point(336, 18);
            this.inputCubePresentationBox.Name = "inputCubePresentationBox";
            this.inputCubePresentationBox.Size = new System.Drawing.Size(103, 22);
            this.inputCubePresentationBox.TabIndex = 3;
            this.inputCubePresentationBox.TabStop = false;
            // 
            // waveletPresentationBox
            // 
            this.waveletPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waveletPresentationBox.Location = new System.Drawing.Point(118, 18);
            this.waveletPresentationBox.Name = "waveletPresentationBox";
            this.waveletPresentationBox.Size = new System.Drawing.Size(103, 22);
            this.waveletPresentationBox.TabIndex = 2;
            this.waveletPresentationBox.TabStop = false;
            // 
            // removeButton
            // 
            this.removeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeButton.Location = new System.Drawing.Point(117, 101);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(91, 23);
            this.removeButton.TabIndex = 5;
            this.removeButton.Text = "Remove";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.labelFaciesProp);
            this.groupBox5.Controls.Add(this.faciesPropOutTextBox);
            this.groupBox5.Controls.Add(this.labelMostLikelyFacies);
            this.groupBox5.Controls.Add(this.mostLikelyFaciesTextBox);
            this.groupBox5.Controls.Add(this.labelResOut);
            this.groupBox5.Controls.Add(this.labelRhoOut);
            this.groupBox5.Controls.Add(this.labelVsOut);
            this.groupBox5.Controls.Add(this.labelVpOut);
            this.groupBox5.Controls.Add(this.residualCubeTextBox);
            this.groupBox5.Controls.Add(this.rhoCubeTextBox);
            this.groupBox5.Controls.Add(this.vsCubeTextBox);
            this.groupBox5.Controls.Add(this.vpCubeTextBox);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(4, 656);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(449, 187);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Output";
            // 
            // labelFaciesProp
            // 
            this.labelFaciesProp.AutoSize = true;
            this.labelFaciesProp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFaciesProp.Location = new System.Drawing.Point(7, 161);
            this.labelFaciesProp.Name = "labelFaciesProp";
            this.labelFaciesProp.Size = new System.Drawing.Size(91, 13);
            this.labelFaciesProp.TabIndex = 18;
            this.labelFaciesProp.Text = "Facies probability:";
            // 
            // faciesPropOutTextBox
            // 
            this.faciesPropOutTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faciesPropOutTextBox.Location = new System.Drawing.Point(116, 158);
            this.faciesPropOutTextBox.Name = "faciesPropOutTextBox";
            this.faciesPropOutTextBox.Size = new System.Drawing.Size(322, 20);
            this.faciesPropOutTextBox.TabIndex = 17;
            this.faciesPropOutTextBox.Text = "facies_prop_output";
            // 
            // labelMostLikelyFacies
            // 
            this.labelMostLikelyFacies.AutoSize = true;
            this.labelMostLikelyFacies.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMostLikelyFacies.Location = new System.Drawing.Point(7, 135);
            this.labelMostLikelyFacies.Name = "labelMostLikelyFacies";
            this.labelMostLikelyFacies.Size = new System.Drawing.Size(90, 13);
            this.labelMostLikelyFacies.TabIndex = 16;
            this.labelMostLikelyFacies.Text = "Most likely facies:";
            // 
            // mostLikelyFaciesTextBox
            // 
            this.mostLikelyFaciesTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mostLikelyFaciesTextBox.Location = new System.Drawing.Point(116, 132);
            this.mostLikelyFaciesTextBox.Name = "mostLikelyFaciesTextBox";
            this.mostLikelyFaciesTextBox.Size = new System.Drawing.Size(322, 20);
            this.mostLikelyFaciesTextBox.TabIndex = 15;
            this.mostLikelyFaciesTextBox.Text = "most_likely_facies_output";
            // 
            // labelResOut
            // 
            this.labelResOut.AutoSize = true;
            this.labelResOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResOut.Location = new System.Drawing.Point(8, 109);
            this.labelResOut.Name = "labelResOut";
            this.labelResOut.Size = new System.Drawing.Size(103, 13);
            this.labelResOut.TabIndex = 14;
            this.labelResOut.Text = "Residual cube prefix";
            // 
            // labelRhoOut
            // 
            this.labelRhoOut.AutoSize = true;
            this.labelRhoOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRhoOut.Location = new System.Drawing.Point(8, 80);
            this.labelRhoOut.Name = "labelRhoOut";
            this.labelRhoOut.Size = new System.Drawing.Size(87, 13);
            this.labelRhoOut.TabIndex = 13;
            this.labelRhoOut.Text = "Rho cube output";
            // 
            // labelVsOut
            // 
            this.labelVsOut.AutoSize = true;
            this.labelVsOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVsOut.Location = new System.Drawing.Point(8, 51);
            this.labelVsOut.Name = "labelVsOut";
            this.labelVsOut.Size = new System.Drawing.Size(79, 13);
            this.labelVsOut.TabIndex = 12;
            this.labelVsOut.Text = "Vs cube output";
            // 
            // labelVpOut
            // 
            this.labelVpOut.AutoSize = true;
            this.labelVpOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVpOut.Location = new System.Drawing.Point(8, 22);
            this.labelVpOut.Name = "labelVpOut";
            this.labelVpOut.Size = new System.Drawing.Size(80, 13);
            this.labelVpOut.TabIndex = 11;
            this.labelVpOut.Text = "Vp cube output";
            // 
            // residualCubeTextBox
            // 
            this.residualCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.residualCubeTextBox.Location = new System.Drawing.Point(117, 106);
            this.residualCubeTextBox.Name = "residualCubeTextBox";
            this.residualCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.residualCubeTextBox.TabIndex = 3;
            this.residualCubeTextBox.Text = "residual_cube_output";
            // 
            // rhoCubeTextBox
            // 
            this.rhoCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhoCubeTextBox.Location = new System.Drawing.Point(117, 77);
            this.rhoCubeTextBox.Name = "rhoCubeTextBox";
            this.rhoCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.rhoCubeTextBox.TabIndex = 2;
            this.rhoCubeTextBox.Text = "rho_cube_output";
            // 
            // vsCubeTextBox
            // 
            this.vsCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsCubeTextBox.Location = new System.Drawing.Point(117, 48);
            this.vsCubeTextBox.Name = "vsCubeTextBox";
            this.vsCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.vsCubeTextBox.TabIndex = 1;
            this.vsCubeTextBox.Text = "vs_cube_output";
            // 
            // vpCubeTextBox
            // 
            this.vpCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpCubeTextBox.Location = new System.Drawing.Point(117, 19);
            this.vpCubeTextBox.Name = "vpCubeTextBox";
            this.vpCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.vpCubeTextBox.TabIndex = 0;
            this.vpCubeTextBox.Text = "vp_cube_output";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.faciesPriorProportionUI1);
            this.groupBox3.Controls.Add(this.labelTransitionMatrix);
            this.groupBox3.Controls.Add(this.faciesTransitionMatrixUI1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 308);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 285);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Facies prior p(k)";
            // 
            // faciesPriorProportionUI1
            // 
            this.faciesPriorProportionUI1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faciesPriorProportionUI1.Location = new System.Drawing.Point(12, 150);
            this.faciesPriorProportionUI1.Name = "faciesPriorProportionUI1";
            this.faciesPriorProportionUI1.Size = new System.Drawing.Size(432, 132);
            this.faciesPriorProportionUI1.TabIndex = 23;
            // 
            // labelTransitionMatrix
            // 
            this.labelTransitionMatrix.AutoSize = true;
            this.labelTransitionMatrix.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTransitionMatrix.Location = new System.Drawing.Point(9, 20);
            this.labelTransitionMatrix.Name = "labelTransitionMatrix";
            this.labelTransitionMatrix.Size = new System.Drawing.Size(84, 13);
            this.labelTransitionMatrix.TabIndex = 22;
            this.labelTransitionMatrix.Text = "Transition Matrix";
            // 
            // faciesTransitionMatrixUI1
            // 
            this.faciesTransitionMatrixUI1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.faciesTransitionMatrixUI1.Location = new System.Drawing.Point(8, 36);
            this.faciesTransitionMatrixUI1.Name = "faciesTransitionMatrixUI1";
            this.faciesTransitionMatrixUI1.Size = new System.Drawing.Size(431, 107);
            this.faciesTransitionMatrixUI1.TabIndex = 0;
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 853);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 57;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // labelSuggStd
            // 
            this.labelSuggStd.AutoSize = true;
            this.labelSuggStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuggStd.Location = new System.Drawing.Point(346, 104);
            this.labelSuggStd.Name = "labelSuggStd";
            this.labelSuggStd.Size = new System.Drawing.Size(13, 13);
            this.labelSuggStd.TabIndex = 24;
            this.labelSuggStd.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(230, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Suggested noise Std:";
            // 
            // labelSeisStd
            // 
            this.labelSeisStd.AutoSize = true;
            this.labelSeisStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeisStd.Location = new System.Drawing.Point(346, 76);
            this.labelSeisStd.Name = "labelSeisStd";
            this.labelSeisStd.Size = new System.Drawing.Size(13, 13);
            this.labelSeisStd.TabIndex = 22;
            this.labelSeisStd.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(230, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Selected Seismic Std:";
            // 
            // ElasticFaciesInversionWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label18);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.loadDrop);
            this.Name = "ElasticFaciesInversionWorkstepUI";
            this.Size = new System.Drawing.Size(480, 882);
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPreviewUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angleUpDown)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn Wavelett;
        private System.Windows.Forms.NumericUpDown correlationRangeUpDown;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button addButton;
        private Slb.Ocean.Petrel.UI.DropTarget waveletDrop;
        private System.Windows.Forms.DataGridViewTextBoxColumn SNR;
        private System.Windows.Forms.DataGridViewTextBoxColumn Angle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cube;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button closeButton;
        private Slb.Ocean.Petrel.UI.DropTarget inputCubeDrop;
        private System.Windows.Forms.Button verticalGateButton;
        private System.Windows.Forms.CheckBox optionsCheckBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown inlineInvPreviewUpDown;
        private System.Windows.Forms.CheckBox inlineInvPreviewCheckBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown angleUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown signalToNoiseUpDown;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox inputCubePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox waveletPresentationBox;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label labelResOut;
        private System.Windows.Forms.Label labelRhoOut;
        private System.Windows.Forms.Label labelVsOut;
        private System.Windows.Forms.Label labelVpOut;
        private System.Windows.Forms.TextBox residualCubeTextBox;
        private System.Windows.Forms.TextBox rhoCubeTextBox;
        private System.Windows.Forms.TextBox vsCubeTextBox;
        private System.Windows.Forms.TextBox vpCubeTextBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button aiVsPhiButton;
        private System.Windows.Forms.Button openCPbutton;
        private System.Windows.Forms.Label labelTransitionMatrix;
        private FaciesTransitionMatrixUI faciesTransitionMatrixUI1;
        private System.Windows.Forms.Label labelFaciesProp;
        private System.Windows.Forms.TextBox faciesPropOutTextBox;
        private System.Windows.Forms.Label labelMostLikelyFacies;
        private System.Windows.Forms.TextBox mostLikelyFaciesTextBox;
        private FaciesPriorProportionUI faciesPriorProportionUI1;
        private System.Windows.Forms.Label labelSuggStd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelSeisStd;
        private System.Windows.Forms.Label label1;
    }
}
