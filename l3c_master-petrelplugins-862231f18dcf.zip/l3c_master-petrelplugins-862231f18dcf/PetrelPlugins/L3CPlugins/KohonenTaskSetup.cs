﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class KohonenTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel[] _cubes;
        public CubeFromPetrel _cube_class_out;
        public KohonenCLI.ParametersCLI _p;
        public KohonenCLI kf = null;
        public int progressPct = 0;
        public String _statusMsg = "";
        public KohonenTaskSetup(ref CubeFromPetrel[] cubes, ref KohonenCLI.ParametersCLI pars, ref CubeFromPetrel class_out)
        {
            _cubes = cubes;
            _p = pars;
            _cube_class_out = class_out;
        }

        public int progress()
        {
            if (kf != null)
            {
                int prog = kf.getProgress();
                return prog;
            }
            return 0;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}
