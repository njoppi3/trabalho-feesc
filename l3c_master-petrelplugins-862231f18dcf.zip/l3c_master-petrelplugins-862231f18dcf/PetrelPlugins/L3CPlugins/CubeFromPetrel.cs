﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Slb.Ocean.Petrel.Seismic;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Basics;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using Slb.Ocean.Geometry;

namespace UFSC_Plugins
{
    class CubeFromPetrel : CubeCLI
    {
        private SeismicCube _fromPetrel = null;
        private IAsyncSubCube _readerCube = null;
        private IAsyncSubCube _writerCube = null;
        private Index3 _origin = null;
        private Index3 _end = null;
        private double[,] _horizon = null;

        public CubeFromPetrel(SeismicCube cube, bool readItNow=false) : base((ulong) cube.NumSamplesIJK.I,(ulong) cube.NumSamplesIJK.J, (ulong)cube.NumSamplesIJK.K)
        {
            _fromPetrel = cube;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            _origin = min;
            _end = max;
            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);

            if (readItNow)
                readFromPetrel();
        }

        public CubeFromPetrel(SeismicCube cube, int initWithSmallCube) : base(1,1,1)
        {
            // int dummy only for creating a cube cli with size = 1 for replacing it later
            _fromPetrel = cube;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            _origin = min;
            _end = max;
            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);

        }

        public CubeFromPetrel(SeismicCube cube, double[,] hor, double maxHorSamples, int initWithSmallCube) : base(1, 1, 1)
        {
            // int dummy only for creating a cube cli with size = 1 for replacing it later
            _fromPetrel = cube;
            _horizon = hor;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            _origin = min;
            _end = max;
            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);

        }

        public CubeFromPetrel(SeismicCube cube, int inlinePrev, bool readItNow) : base((ulong) 1, (ulong) cube.NumSamplesIJK.J, (ulong) cube.NumSamplesIJK.K)
        {
            _fromPetrel = cube;
            setInlinePreview(cube, inlinePrev);

            if (readItNow)
                readFromPetrel();
        }

        public CubeFromPetrel(SeismicCube cube, int inlinePrev, double[,] hor, double maxHorSamples, bool readItNow = false) : base((ulong)1, (ulong)cube.NumSamplesIJK.J, (ulong)maxHorSamples)
        {
            _horizon = hor;
            _fromPetrel = cube;
            setInlinePreview(cube, inlinePrev);

            if (readItNow)
                readFromPetrel();
        }

        public CubeFromPetrel(SeismicCube cube, double[,] hor, double maxHorSamples, bool readItNow = false) : base((ulong)cube.NumSamplesIJK.I, (ulong)cube.NumSamplesIJK.J, (ulong)maxHorSamples)
        {
            _horizon = hor;
            _fromPetrel = cube;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            _origin = min;
            _end = max;
            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);

            if (readItNow)
                readFromPetrel();
        }

        ~CubeFromPetrel()
        {
            if (_writerCube != null)
                _writerCube.Dispose();
            if (_readerCube != null)
                _readerCube.Dispose();
            System.GC.Collect();
        }

        private void setInlinePreview(SeismicCube cube, int inlinePrev)
        {
            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;

            IndexDouble3 min_annot = cube.AnnotationAtIndex(min.ToIndexDouble3());
            IndexDouble3 max_annot = cube.AnnotationAtIndex(max.ToIndexDouble3());

            min_annot.I = inlinePrev;
            max_annot.I = inlinePrev;

            min = cube.IndexAtAnnotation(min_annot).ToIndex3();
            max = cube.IndexAtAnnotation(max_annot).ToIndex3();

            _origin = min;
            _end = max;

            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);
        }

        public CubeFromPetrel(SeismicCube cube, double[,] hor, int maxHorSamples,  bool readItNow = false) : base((ulong)cube.NumSamplesIJK.I, (ulong)cube.NumSamplesIJK.J, (ulong)maxHorSamples)
        {
            _horizon = hor;
            _fromPetrel = cube;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            _origin = min;
            _end = max;
            _readerCube = _fromPetrel.GetAsyncSubCubeReadOnly(min, max);

            if (readItNow)
                readFromPetrel();

        }

        public void setCube(CubeCLI c)
        {
            base.set(c);
        }

        public void readFromPetrel(double scaleFactor = 1.0)
        {
            if (_horizon == null)
                readWithoutHor(scaleFactor);
            else
                readWithHor(scaleFactor);
        }

        private void readWithoutHor(double scaleFactor)
        {
            int nz = (int)getNumZlines();
            for (int i = 0; i < (int)getNumInlines(); i++)
            {
                for (int j = 0; j < (int)getNumCrosslines(); j++)
                {
                    for (int k = 0; k < nz; k++)
                        this.setValueAt(Convert.ToUInt64(i), Convert.ToUInt64(j), Convert.ToUInt64(k), scaleFactor * _readerCube[i + _origin.I, j + _origin.J, k + _origin.K]);
                }
            }
        }

        private void readWithHor(double scaleFactor)
        {
            int nz = (int)getNumZlines();
            for (int i = 0; i < (int)getNumInlines(); i++)
                for (int j = 0; j < (int)getNumCrosslines(); j++)
                    for (int k = 0; k < nz; k++)
                    {
                        int kreader = Convert.ToInt32(_horizon[i + _origin.I, j + _origin.J]) + k;
                        this.setValueAt(Convert.ToUInt64(i), Convert.ToUInt64(j), Convert.ToUInt64(k), scaleFactor * _readerCube[i + _origin.I, j + _origin.J, kreader + _origin.K]);
                    }
        }

        public void writeToPetrel(ref int progress, CubeFromPetrel mask = null, double scaleFactor = 1)
        {
            if (_horizon==null)
                progress = writeWithoutHor(progress, mask, scaleFactor);
            else
                progress = writeWithHor(progress, mask, scaleFactor);
            _writerCube.Dispose();
            _writerCube = null;
            System.GC.Collect();
        }

        private int writeWithoutHor(int progress, CubeFromPetrel mask = null, double scaleFactor = 1)
        {
            double[] traceCubeSimple = new double[getNumZlines()];
            for (ulong i = 0; i < getNumInlines(); i++)
            {
                for (ulong j = 0; j < getNumCrosslines(); j++)
                {
                    getTraceAt(i, j, traceCubeSimple);
                    for (int k = 0; k < traceCubeSimple.Length; k++)
                    {
                        if (mask == null || mask.getAt(i, j, Convert.ToUInt64(k)) != 0)
                            _writerCube[(int)i + _origin.I, (int)j + _origin.J, k + _origin.K] = Convert.ToSingle(scaleFactor * traceCubeSimple[k]);
                    }
                    progress = (int)(i * getNumCrosslines() + j);
                }

            }

            return progress;
        }

        private int writeWithHor(int progress, CubeFromPetrel mask = null, double scaleFactor = 1)
        {
            double[] traceCubeSimple = new double[getNumZlines()];
            for (ulong i = 0; i < getNumInlines(); i++)
            {
                for (ulong j = 0; j < getNumCrosslines(); j++)
                {
                    getTraceAt(i, j, traceCubeSimple);
                    for (int k = 0; k < traceCubeSimple.Length; k++)
                    {
                        int kwriter = Convert.ToInt32(_horizon[(int)i + _origin.I, (int)j + _origin.J])  + k;
                        if (mask == null || mask.getAt(i,j, Convert.ToUInt64(k))!=0)
                            _writerCube[(int)i + _origin.I, (int)j + _origin.J, kwriter + _origin.K] = Convert.ToSingle(scaleFactor * traceCubeSimple[k]);
                    }
                    progress = (int)(i * getNumCrosslines() + j);
                }

            }

            return progress;
        }

        public void prepareWriteToPetrel(ref SeismicCube cubeToWriteToPetrel)

        {
            using (ITransaction wrr =
                    DataManager.NewTransaction())
            {
                wrr.Lock(cubeToWriteToPetrel.SeismicCollection);
                wrr.Lock(cubeToWriteToPetrel);
                _writerCube = cubeToWriteToPetrel.GetAsyncSubCubeReadWrite(_origin, _end);
                wrr.Commit();
            }
            foreach (var s in _writerCube)
                _writerCube[s] = float.NaN;
        }

        public void prepareWriteToPetrel()

        {
            prepareWriteToPetrel(ref _fromPetrel);
        }

        public SeismicCube GetSeismicCube()
        {
            return _fromPetrel;
        }
    }
}
