﻿using Microsoft.VisualBasic;
using Slb.Ocean.Basics;
using Slb.Ocean.Core;
using Slb.Ocean.Geometry;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.Data;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using Slb.Ocean.Petrel.DomainObject.Well;
using Slb.Ocean.Petrel.DomainObject.PillarGrid;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.Workflow.ProcessGroups;
using Slb.Ocean.Petrel.Workflow.OperationGroups;
using Slb.Ocean.Petrel.Workflow.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Modeling;
using Slb.Ocean.Petrel.PropertyModeling;
using Slb.Ocean.Petrel.DomainObject.ColorTables;
using System.Text.RegularExpressions;

namespace UFSC_Plugins
{
    public struct Face
    {
        public IndexDouble3[] v { get; set; }

        public IndexDouble3 normal()
        {
            IndexDouble3 dir1 = v[1] - v[0];
            IndexDouble3 dir2 = v[2] - v[0];
            /*
               y * p.z - p.y * z,
               z * p.x - p.z * x,
               x * p.y - p.x * y
             */
            IndexDouble3 n = new IndexDouble3(dir1.J * dir2.K - dir2.J * dir1.K,
                                              dir1.K * dir2.I - dir2.K * dir1.I,
                                              dir1.I * dir2.J - dir2.I * dir1.J);
            double d = Math.Sqrt(n.I * n.I + n.J * n.J + n.K * n.K);
            return new IndexDouble3(n.I / d, n.J / d, n.K / d);
        }
    }

    class Functions
    {
        public static ReferenceVariable getReferenceVariable(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as ReferenceVariable;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the variable was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }
        public static SeismicCube getCube(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as SeismicCube;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the cube was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static Wavelet getWavelet(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as Wavelet;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the wavelet was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }

            return null;
        }

        public static Borehole getWell(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as Borehole;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the well was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static DictionaryProperty getDictProperty(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as DictionaryProperty;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the grid dictionary property was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone getZone(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the zone was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static IEnumerable<WellLogSample> getlist(Droid droidLog, Droid well)
        {
            WellLogVersion wlv = getWellLogVersion(droidLog);
            Borehole bh = getWell(well);

            if (wlv != null && bh != null) {

                foreach (var wlog in bh.LogCollection.WellLogs)
                {
                    Template t = wlog.WellLogVersion.Template;
                    if (wlog.WellLogVersion == wlv)
                    {
                        List<WellLogSample> samplesConverted = new List<WellLogSample>();
                        foreach (WellLogSample item in wlog.Samples.ToList())
                            samplesConverted.Add(new WellLogSample(item.MD, PetrelUnitSystem.ConvertToUI(t, item.Value)));
                        return samplesConverted;
                    }
                }

            }
            return null;

        }

        public static IEnumerable<WellLogSample> getlistDict(Droid droidDictLog, Droid well)
        {
            DictionaryWellLogVersion dwlv = getDictWellLogVersion(droidDictLog);
            Borehole bh = getWell(well);
            if (dwlv != null && bh != null)
            {

                foreach (var wlog in bh.LogCollection.DictionaryWellLogs)
                {
                    DictionaryTemplate t = wlog.DictionaryWellLogVersion.DictionaryTemplate;
                    if (wlog.DictionaryWellLogVersion == dwlv)
                    {
                        List<WellLogSample> samplesConverted = new List<WellLogSample>();
                        foreach (DictionaryWellLogSample item in wlog.Samples.ToList())
                            if (item.Value== DictionaryWellLogSample.UndefinedValue)
                                samplesConverted.Add(new WellLogSample(item.MD, float.NaN));
                            else
                                samplesConverted.Add(new WellLogSample(item.MD, item.Value));

                        return samplesConverted;
                    }
                }
            }
            return null;
        }

        public static void getAllLists(List<string> wellDroid, string logXDroid, string logYDroid, string faciesDroid,
            out List<WellLogSample> xList, out List<WellLogSample> ylist, out List<WellLogSample> timeList)
        {
            xList = new List<WellLogSample>();
            ylist = new List<WellLogSample>();
            timeList = new List<WellLogSample>();

            if ((logXDroid != null) && (logYDroid != null))
            {
                try
                {
                    Droid logxD = new Droid(logXDroid);
                    Droid logyD = new Droid(logYDroid);
                    foreach (string well in wellDroid)
                    {
                        Droid wellD = new Droid(well);
                        xList.AddRange(getlist(logxD, wellD).ToList());
                        ylist.AddRange(getlist(logyD, wellD).ToList());
                        if (faciesDroid != null)
                            if (getlist(new Droid(faciesDroid), wellD) != null)
                                timeList.AddRange(getlist(new Droid(faciesDroid), wellD).ToList());
                            else if (getlistDict(new Droid(faciesDroid), wellD) != null)
                                timeList.AddRange(getlistDict(new Droid(faciesDroid), wellD).ToList());
                    }
                }
                catch (Exception except)
                {
                    PetrelLogger.InfoBox("Erro: " + except.ToString());
                    return;
                }
            }
        }

        public static decimal getStackAngle(String cube_name)
        {
            return Convert.ToDecimal(Regex.Split(cube_name, @"\D+").Select<string, Func<int, int?>>(s => (n) => int.TryParse(s, out n) ? (int?)n : (int?)null).Where(λ => λ(0) != null).Select(λ => λ(0).Value).Sum() / 2);
        }

        internal static double computeStd(SeismicCube cube)
        {
            double std = 0;

            Index3 min = new Index3(0, 0, 0);
            Index3 max = cube.NumSamplesIJK - 1;
            IAsyncSubCube readerCube = cube.GetAsyncSubCubeReadOnly(min, max);

            double mean = 0;
            double numelem = cube.NumSamplesIJK.I * cube.NumSamplesIJK.J * cube.NumSamplesIJK.K;
            int nz = cube.NumSamplesIJK.K;
            for (int i = 0; i < cube.NumSamplesIJK.I; i++)
                for (int j = 0; j < cube.NumSamplesIJK.J; j++)
                    for (int k = 0; k < nz; k++)
                    {
                        mean = mean + readerCube[i , j , k]/numelem;
                    }
            for (int i = 0; i < cube.NumSamplesIJK.I; i++)
                for (int j = 0; j < cube.NumSamplesIJK.J; j++)
                    for (int k = 0; k < nz; k++)
                    {
                         std = std + (Math.Pow(readerCube[i, j, k] - mean, 2) / numelem);
                    }
            std = Math.Sqrt(std);

            return std;
        }

        public static void getAllLists(List<string> wellDroid, string logXDroid, string logYDroid, string logZDroid, string faciesDroid,
            out List<WellLogSample> xList, out List<WellLogSample> ylist, out List<WellLogSample> zlist, out List<WellLogSample> timeList)
        {
            xList = new List<WellLogSample>();
            ylist = new List<WellLogSample>();
            zlist = new List<WellLogSample>();
            timeList = new List<WellLogSample>();

            if ((logXDroid != null) && (logYDroid != null) && (logZDroid != null))
            {
                try
                {
                    Droid logxD = new Droid(logXDroid);
                    Droid logyD = new Droid(logYDroid);
                    Droid logzD = new Droid(logZDroid);
                    foreach (string well in wellDroid)
                    {
                        Droid wellD = new Droid(well);
                        xList.AddRange(getlist(logxD, wellD).ToList());
                        ylist.AddRange(getlist(logyD, wellD).ToList());
                        zlist.AddRange(getlist(logzD, wellD).ToList());
                        if (faciesDroid != null)
                        {
                            if (getlist(new Droid(faciesDroid), wellD) != null)
                                timeList.AddRange(getlist(new Droid(faciesDroid), wellD).ToList());
                            else if (getlistDict(new Droid(faciesDroid), wellD) != null)
                                timeList.AddRange(getlistDict(new Droid(faciesDroid), wellD).ToList());
                        }

                    }
                }
                catch (Exception except)
                {
                    PetrelLogger.InfoBox("Erro: " + except.ToString());
                    return;
                }
            }
        }

        public static WellLog getLog(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as WellLog;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the log was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }



        public static WellLogVersion getWellLogVersion(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as WellLogVersion;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the log was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static DictionaryWellLogVersion getDictWellLogVersion(Droid droidCmp)
        {
            try
            {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as DictionaryWellLogVersion;
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Maybe the log was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        public static RegularHeightFieldSurface getRegularHeightFieldSurface(Droid droidCmp) {
            try {
                if (DataManager.DataSourceManager.CanResolve(droidCmp))
                    return DataManager.DataSourceManager.Resolve(droidCmp) as RegularHeightFieldSurface;
            } catch (Exception except) {
                PetrelLogger.InfoBox("Maybe the cube was not found!");
                PetrelLogger.InfoBox(except.ToString());
            }
            return null;
        }

        // --------------------------------------------------------------

        public static SeismicCube getCubeByReferenceVar(Droid droidCmp)
        {
            ReferenceVariable refVariable;
            SeismicCube seismicCube;

            refVariable = getReferenceVariable(droidCmp);
            if (refVariable != null)
            {
                seismicCube = refVariable.GetTarget<SeismicCube>();
                if (seismicCube != null)
                {
                    return seismicCube;
                }
                else
                {
                    throw new Exception("Null ReferenceVariable or wrong target type");
                }
            }
            else
            {
                seismicCube = getCube(droidCmp);
                if (seismicCube != null)
                {
                    return seismicCube;
                }
                else
                {
                    throw new Exception("");
                }
            }
        }

        public static Wavelet getWaveletByReferenceVar(Droid droidCmp)
        {
            ReferenceVariable refVariable;
            Wavelet wavelet;

            refVariable = getReferenceVariable(droidCmp);
            if (refVariable != null)
            {
                wavelet = refVariable.GetTarget<Wavelet>();
                if (wavelet != null)
                {
                    return wavelet;
                }
                else
                {
                    throw new Exception("Null ReferenceVariable or wrong target type");
                }
            }
            else
            {
                wavelet = getWavelet(droidCmp);
                if (wavelet != null)
                {
                    return wavelet;
                }
                else
                {
                    throw new Exception("");
                }
            }
        }

        public static Borehole getWellByReferenceVar(Droid droidCmp)
        {
            ReferenceVariable refVariable;
            Borehole well;

            refVariable = getReferenceVariable(droidCmp);
            if (refVariable != null)
            {
                well = refVariable.GetTarget<Borehole>();
                if (well != null)
                {
                    return well;
                }
                else
                {
                    throw new Exception("Null ReferenceVariable or wrong target type");
                }
            }
            else
            {
                well = getWell(droidCmp);
                if (well != null)
                {
                    return well;
                }
                else
                {
                    throw new Exception("");
                }
            }
        }

        public static WellLog getLogByReferenceVar(Droid droidCmp)
        {
            ReferenceVariable refVariable;
            WellLog well;

            refVariable = getReferenceVariable(droidCmp);
            if (refVariable != null)
            {
                well = refVariable.GetTarget<WellLog>();
                if (well != null)
                {
                    return well;
                }
                else
                {
                    throw new Exception("Null ReferenceVariable or wrong target type");
                }
            }
            else
            {
                well = getLog(droidCmp);
                if (well != null)
                {
                    return well;
                }
                else
                {
                    throw new Exception("");
                }
            }
        }

        public static bool isInConvexPoly(IndexDouble3 p, Face[] fs)
        {
            foreach (var f in fs)
            {
                IndexDouble3 p2f = f.v[0] - p;
                IndexDouble3 fn = f.normal();
                /*
                 *  double dot(Vector p) const {
                     return x * p.x + y * p.y + z * p.z;
                */
                double d = p2f.I * fn.I + p2f.J * fn.J + p2f.K * fn.K; //p2f.dot(f.normal())
                d /= Math.Sqrt(p2f.I * p2f.I + p2f.J * p2f.J + p2f.K * p2f.K);
                double bound = -1E-15; // use 1e15 to exclude boundaries
                if (d < bound)
                {
                    return false;
                }
            }
            return true;
        }

        public static Dictionary<string, string> getCubeFaciesFromGrid(string propGridDroid, List<string> zonesDroid, string resolutionCubeDroid)
        {
            List<string> cubes = new List<string>();
            DictionaryProperty grid = getDictProperty(new Droid(propGridDroid));
            List<Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone> zones = new List<Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone>();
            foreach (var droid in zonesDroid)
                zones.Add(Functions.getZone(new Droid(droid)));

            //-- Create collection --//
            Project proj = PetrelProject.PrimaryProject;
            SeismicRoot sroot = SeismicRoot.Get(proj);

            SeismicProject sproj;
            using (ITransaction tr = DataManager.NewTransaction())
            {
                tr.Lock(PetrelProject.PrimaryProject);
                sproj = sroot.GetOrCreateSeismicProject();
                tr.Commit();
            }
            string colName = "Cubes from " + grid.Name;
            SeismicCollection scol;

            using (ITransaction tr = DataManager.NewTransaction())
            {
                tr.Lock(sproj);
                scol = sproj.CreateSeismicCollection(colName);
                tr.Commit();
            }

            //-- Create Out Cubes --//
            // <FacieCode,SeismicCube>
            Dictionary<string, string> faciesCube = new Dictionary<string, string>();
            Dictionary<int, CubeFromPetrel> faciesCubeWrap = new Dictionary<int, CubeFromPetrel>();
            SeismicCube resolutionCube = Functions.getCube(new Droid(resolutionCubeDroid));
            ColorTableRoot root = ColorTableRoot.Get(PetrelProject.PrimaryProject);
            Slb.Ocean.Petrel.DomainObject.ColorTables.ColorTable ct = root.WellKnownColorTables.Other.GeneralContinuous;
            for (int i = grid.Min; i <= grid.Max; ++i)
            {
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    try
                    {
                        tr.Lock(scol);
                        SeismicCube sc = scol.CreateSeismicCube(resolutionCube, typeof(Single), PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault, resolutionCube.ClippingRange);
                        sc.Name = grid.Name + " - " + grid.GetFaciesCodeName(i);
                        sc.Template = PetrelProject.WellKnownTemplates.MiscellaneousGroup.Probability;
                        faciesCube.Add(sc.Droid.ToString(), grid.GetFaciesCodeName(i));
                        CubeFromPetrel cfp = new CubeFromPetrel(sc);
                        faciesCubeWrap.Add(i, cfp);
                        faciesCubeWrap[i].prepareWriteToPetrel();
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes from selected grid");
                        return null;
                    }
                }
            }

            //-- Get Facis props from Grid to CubeFromPetrel --//
            try
            {
                IndexDouble3 origin = resolutionCube.AnnotationAtIndex(resolutionCube.IndexAtPosition(resolutionCube.Origin));
                IndexDouble3 end = resolutionCube.AnnotationAtIndex(new IndexDouble3(resolutionCube.NumSamplesIJK.I-1,
                                                                                     resolutionCube.NumSamplesIJK.J-1,
                                                                                     resolutionCube.NumSamplesIJK.K-1));
                int sizeI = grid.Grid.NumCellsIJK.I;
                int sizeJ = grid.Grid.NumCellsIJK.J;
                int sizeK = grid.Grid.NumCellsIJK.K;
                IndexDouble3 shift_top = new IndexDouble3(0, 0, 1);
                IndexDouble3 shift_base = new IndexDouble3(0, 0, -1);
                IndexDouble3 shif_front = new IndexDouble3(0, -1, 0);
                IndexDouble3 shif_back = new IndexDouble3(0, 1, 0);
                IndexDouble3 shif_left = new IndexDouble3(-1, 0, 0);
                IndexDouble3 shif_right = new IndexDouble3(1, 0, 0);
                FastDictionaryPropertyIndexer indexer = grid.SpecializedAccess.OpenFastDictionaryPropertyIndexer();
                FaciesVerticalProbabilities fvp;
                using (IProgress progressBar = PetrelLogger.NewProgress(0, sizeI*sizeJ*sizeK))
                {
                    progressBar.SetProgressText("Creating facies cubes probabilities from grid.");
                    int pstatus = 0;
                    for (int i = 0; i < sizeI; i++)
                    {
                        for (int j = 0; j < sizeJ; j++)
                        {
                            for (int k = 0; k < sizeK; k++)
                            {
                                pstatus++;
                                progressBar.ProgressStatus = pstatus;
                                Point3[] points = grid.Grid.GetCellCorners(new Index3(i, j, k), CellCornerSet.All);
                                IndexDouble3[] cidxd = points.Select(x => resolutionCube.IndexAtPosition(x)).ToArray();
                                IndexDouble3[] aidx = cidxd.Select(x => resolutionCube.AnnotationAtIndex(x)).ToArray();
                                Index3 start_cell = new IndexDouble3(aidx.Min(x => x.I), aidx.Min(x => x.J), aidx.Min(x => x.K)).ToIndex3();
                                Index3 end_cell = new IndexDouble3(aidx.Max(x => x.I), aidx.Max(x => x.J), aidx.Max(x => x.K)).ToIndex3();

                                if ((start_cell.I < origin.I || start_cell.J < origin.J || start_cell.K < origin.K) &&
                                    (end_cell.I > end.I || end_cell.J > end.J || end_cell.K > end.K))
                                    continue;

                                Index3 gridIndex = new Index3(i, j, k);
                                if (indexer[gridIndex] == DictionaryProperty.UndefinedValue)
                                    continue;

                                start_cell = new IndexDouble3(cidxd.Min(x => x.I), cidxd.Min(x => x.J), cidxd.Min(x => x.K)).ToIndex3();
                                end_cell = new IndexDouble3(cidxd.Max(x => x.I), cidxd.Max(x => x.J), cidxd.Max(x => x.K)).ToIndex3();
                                Index3[] cidx = cidxd.Select(x => x.ToIndex3()).ToArray<Index3>();
                                

                                for (int z = 0; z < zones.Count; z++)
                                {
                                    fvp = getDictPropertyZoneFaciesProbabilities(new Droid(propGridDroid), new Droid(zonesDroid[z]));
                                    if (gridIndex.K >= zones[z].TopK && gridIndex.K <= zones[z].BaseK)
                                    {
                                        Face[] cell_facies = new Face[6];
                                        Face ft = new Face();

                                        //front
                                        ft.v = new[] {cidx[7].ToIndexDouble3()+shif_front,
                                                      cidx[6].ToIndexDouble3()+shif_front,
                                                      cidx[2].ToIndexDouble3()+shif_front,
                                                      cidx[3].ToIndexDouble3()+shif_front};
                                        cell_facies[0] = ft;
                                        //back
                                        ft.v = new[] {cidx[4].ToIndexDouble3()+shif_back,
                                                      cidx[0].ToIndexDouble3()+shif_back,
                                                      cidx[1].ToIndexDouble3()+shif_back,
                                                      cidx[5].ToIndexDouble3()+shif_back};
                                        cell_facies[1] = ft;
                                        //left
                                        ft.v = new[] {cidx[7].ToIndexDouble3()+shif_left,
                                                      cidx[3].ToIndexDouble3()+shif_left,
                                                      cidx[0].ToIndexDouble3()+shif_left,
                                                      cidx[4].ToIndexDouble3()+shif_left};
                                        cell_facies[2] = ft;
                                        //right
                                        ft.v = new[] {cidx[6].ToIndexDouble3()+shif_right,
                                                      cidx[5].ToIndexDouble3()+shif_right,
                                                      cidx[1].ToIndexDouble3()+shif_right,
                                                      cidx[2].ToIndexDouble3()+shif_right};
                                        cell_facies[3] = ft;
                                        //top
                                        ft.v = new[] {cidx[3].ToIndexDouble3()+shift_top,
                                                      cidx[2].ToIndexDouble3()+shift_top,
                                                      cidx[1].ToIndexDouble3()+shift_top,
                                                      cidx[0].ToIndexDouble3()+shift_top};
                                        cell_facies[4] = ft;
                                        //base
                                        ft.v = new[] {cidx[7].ToIndexDouble3()+shift_base,
                                                      cidx[4].ToIndexDouble3()+shift_base,
                                                      cidx[5].ToIndexDouble3()+shift_base,
                                                      cidx[6].ToIndexDouble3()+shift_base};
                                        cell_facies[5] = ft;

                                        foreach (var facieProp in fvp[gridIndex.K].FaciesProbabilities.ToList())
                                        {
                                            int max_ic = (int)faciesCubeWrap[facieProp.FaciesCode].getNumInlines();
                                            int max_jc = (int)faciesCubeWrap[facieProp.FaciesCode].getNumCrosslines();
                                            int max_kc = (int)faciesCubeWrap[facieProp.FaciesCode].getNumZlines();
                                            for (int ic = start_cell.I; ic <= end_cell.I && ic < max_ic ; ++ic)
                                            {
                                                for (int jc = start_cell.J; jc <= end_cell.J && jc < max_jc; ++jc)
                                                {
                                                    for (int kc = start_cell.K; kc <= end_cell.K && kc < max_kc; ++kc)
                                                    {
                                                        if (isInConvexPoly(new IndexDouble3(ic, jc, kc), cell_facies))
                                                            faciesCubeWrap[facieProp.FaciesCode].setValueAt((ulong)ic, (ulong)jc, (ulong)kc, Convert.ToSingle(facieProp.Probability));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    progressBar.Dispose();
                }
                using (IProgress progressBar = PetrelLogger.NewProgress(0,faciesCubeWrap.Count))
                {
                    progressBar.SetProgressText("Writing cubes from facies");
                    for (int i = 0; i < faciesCubeWrap.Count; ++i)
                    {
                        int p = 0;
                        faciesCubeWrap.Values.ToList()[i].writeToPetrel(ref p);
                        progressBar.ProgressStatus = i++;
                    }
                    progressBar.Dispose();
                }   
            }
            catch (Exception e)
            {
                PetrelLogger.InfoBox(e.Message);
                return null;
            }
            return faciesCube;
        }

        public static FaciesVerticalProbabilities getDictPropertyZoneFaciesProbabilities(Droid dictPropDroid, Droid zoneDroid)
        {
            DataAnalysisService das = ModelingSystem.DataAnalysisService;
            FaciesVerticalProbabilities fvp = das.GetFaciesVerticalProbabilities(getDictProperty(dictPropDroid), getZone(zoneDroid));
            return fvp;
        }

        public static bool isTooLightYIQ(string hexcolor)
        {
            Color c = ColorTranslator.FromHtml(hexcolor);
            var yiq = ((c.R * 299) + (c.G * 587) + (c.B * 114)) / 1000;
            return yiq >= 128;
        }

        // --------------------------------------------------------------

        public static Droid dragDropCube(bool isInWorkflow, object obj)
        {
            if (isInWorkflow)
            {
                try
                {
                    if (obj is ReferenceVariable)
                    {
                        return (obj as ReferenceVariable).Droid;
                    }
                    else if (obj is SeismicCube)
                    {
                        return (obj as SeismicCube).Droid;
                    }
                    else
                    {
                        PetrelLogger.ErrorBox("Error: wrong type");
                        return null;
                    }
                }
                catch (Exception ers)
                {
                    PetrelLogger.InfoBox("Error:\n\n" + ers.ToString());
                }
            }
            else
            {
                try
                {
                    SeismicCube cube = obj as SeismicCube;
                    if (cube.NumSamplesIJK.I <= 0)
                    {
                        PetrelLogger.InfoBox("Invalid cube!");
                        return null;
                    }
                    return cube.Droid;
                }
                catch (Exception)
                {
                    PetrelLogger.InfoBox("Error:\n\nThis is not a cube!");
                }
            }
            return null;
        }

        public static Droid dragDropWavelet(bool isInWorkflow, object obj)
        {
            if (isInWorkflow)
            {
                try
                {
                    if (obj is ReferenceVariable)
                    {
                        return (obj as ReferenceVariable).Droid;
                    }
                    else if (obj is Wavelet)
                    {
                        return (obj as Wavelet).Droid;
                    }
                    else
                    {
                        PetrelLogger.ErrorBox("Error: wrong type");
                        return null;
                    }
                }
                catch (Exception ers)
                {
                    PetrelLogger.InfoBox("Error:\n\n" + ers.ToString());
                }
            }
            else
            {
                try
                {
                    Wavelet wvlt = obj as Wavelet;
                    if (wvlt.SampleCount <= 0)
                    {
                        PetrelLogger.InfoBox("Invalid cube!");
                        return null;
                    }
                    return wvlt.Droid;
                }
                catch (Exception)
                {
                    PetrelLogger.InfoBox("Error:\n\nThis is not a wavelet!");
                }
            }
            return null;
        }
        public static Droid dragDropWell(bool isInWorkflow, object obj)
        {
            if (isInWorkflow)
            {
                try
                {
                    if (obj is ReferenceVariable)
                    {
                        return (obj as ReferenceVariable).Droid;
                    }
                    else if (obj is Borehole)
                    {
                        return (obj as Borehole).Droid;
                    }
                    else
                    {
                        PetrelLogger.ErrorBox("Error: wrong type");
                        return null;
                    }
                }
                catch (Exception ers)
                {
                    PetrelLogger.InfoBox("Error:\n\n" + ers.ToString());
                }
            }
            else
            {
                try
                {
                    Borehole well = obj as Borehole;
                    return well.Droid;
                }
                catch (Exception)
                {
                    PetrelLogger.InfoBox("Error:\n\nThis is not a well!");
                }
            }
            return null;
        }

        public static Droid dragDropDictProperty(bool isInWorkflow, object obj)
        {
            if (isInWorkflow)
            {
                try
                {
                    if (obj is ReferenceVariable)
                    {
                        return (obj as ReferenceVariable).Droid;
                    }
                    else if (obj is DictionaryProperty)
                    {
                        return (obj as DictionaryProperty).Droid;
                    }
                    else
                    {
                        PetrelLogger.ErrorBox("Error: wrong type");
                        return null;
                    }
                }
                catch (Exception ers)
                {
                    PetrelLogger.InfoBox("Error:\n\n" + ers.ToString());
                }
            }
            else
            {
                try
                {
                    DictionaryProperty dprop = obj as DictionaryProperty;
                    if (dprop.NumCellsIJK.I <= 0)
                    {
                        PetrelLogger.InfoBox("Invalid grid property!");
                        return null;
                    }
                    return dprop.Droid;
                }
                catch (Exception)
                {
                    PetrelLogger.InfoBox("Error:\n\nThis is not a grid property!");
                }
            }
            return null;
        }

        public static Droid dragDropZone(bool isInWorkflow, object obj)
        {
            if (isInWorkflow)
            {
                try
                {
                    if (obj is ReferenceVariable)
                    {
                        return (obj as ReferenceVariable).Droid;
                    }
                    else if (obj is Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone)
                    {
                        return (obj as Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone).Droid;
                    }
                    else
                    {
                        PetrelLogger.ErrorBox("Error: wrong type");
                        return null;
                    }
                }
                catch (Exception ers)
                {
                    PetrelLogger.InfoBox("Error:\n\n" + ers.ToString());
                }
            }
            else
            {
                try
                {
                    Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone dprop = obj as Slb.Ocean.Petrel.DomainObject.PillarGrid.Zone;
                    if (!dprop.IsGood)
                    {
                        PetrelLogger.InfoBox("Invalid grid zone!");
                        return null;
                    }
                    return dprop.Droid;
                }
                catch (Exception)
                {
                    PetrelLogger.InfoBox("Error:\n\nThis is not a grid zone!");
                }
            }
            return null;
        }

        // --------------------------------------------------------------

        public static void saveCustomObject(string type, string param)
        {

            // isto é para atribuir o name com o nome do obj que está selecionado na arvore
            // caso seja um obj do tipo correto, caso contrário ele abre a caixa de dialogo com um nome padrão
            string name = type + " Object";
            try
            {
                name = PetrelProject.ActiveTree.GetSelected<GenericDomainObject>().First().NameInfo.Name.ToString();
            }
            catch (Exception) { }

            // mostra a janela pedindo qual o name o usuario quer para o objeto
            // rever a mensagem
            name = Interaction.InputBox("What is the name you want to give to the object?", "Save", name);
            if (name == "")
            {
                return;
            }

            // filtra se tiver algum elemento do tipo GenericDomainObject tem o nome == name
            GenericDomainObject obj = null;
            try
            {
                obj = PetrelProject.Inputs.OfType<GenericDomainObject>().Where(o => (o.NameInfo.Name == name)).First();
            }
            catch (Exception) { }
            // caso não houver algum elemento no filtro acima, entra no if e cria o objeto
            //caso contrário ele entra no else e apenas atualiza o campo 'Parameters'
            if (obj == null)
            {
                // add to the tree
                Project p = PetrelProject.PrimaryProject;
                using (ITransaction txn = DataManager.NewTransaction())
                {
                    txn.Lock(p);
                    IDataSourceManager dsm = DataManager.DataSourceManager;
                    StructuredArchiveDataSource genDF = GenericDataSourceFactory.Get(dsm);
                    GenericDomainObject domainObj = new GenericDomainObject(genDF, name, type, param);
                    p.Extensions.Add(domainObj);
                    txn.Commit();
                }
            }
            else
            {
                var confirmResult = MessageBox.Show("An object with this name already exists, do you want to overwrite it?",
                                     "Confirmation", MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    // deletando objeto e criando outro pois se só editasse e salvasse o projeto
                    // o parametro editado voltava ao estado anterior --- rever depois
                    Project p = PetrelProject.PrimaryProject;
                    using (ITransaction txn = DataManager.NewTransaction())
                    {
                        Droid droid = obj.Droid;
                        txn.Lock(p);
                        IDataSourceManager dsm = DataManager.DataSourceManager;
                        StructuredArchiveDataSource genDF = GenericDataSourceFactory.Get(dsm);
                        obj.Delete();
                        genDF.RemoveItem(droid);
                        GenericDomainObject domainObj = new GenericDomainObject(genDF, name, type, param, droid);
                        p.Extensions.Add(domainObj);
                        txn.Commit();
                    }
                }
                else
                {
                    saveCustomObject(type, param);
                }
            }

        }

        public static void setTraceAtWell(CubeFromPetrel cubeFP, Borehole well, WellLogVersion propertyLog, WellLogVersion timeLog)
        {
            SeismicCube cube = cubeFP.GetSeismicCube();
            float sample_rate = Convert.ToSingle(cube.SampleSpacingIJK.Z);
            Point2 ptr = well.WellHead;
            IndexDouble3 itr = cube.IndexAtPosition(new Point3(ptr.X, ptr.Y, 0.0));
            
            List<double> md = new List<double>();
            List<float> logProperty = new List<float>();
            List<float> logTime = new List<float>();

            foreach (var wlog in well.LogCollection.WellLogs)
            {
                Template t = wlog.WellLogVersion.Template;
                if (wlog.WellLogVersion == propertyLog)
                {
                    foreach (WellLogSample wls in wlog.Samples)
                    {
                        logProperty.Add(PetrelUnitSystem.ConvertToUI(t, wls.Value));
                        md.Add(wls.MD);
                    }
                }
            }
            foreach (var wlog in well.LogCollection.WellLogs)
            {
                if (wlog.WellLogVersion == timeLog)
                {
                    foreach (double v in md)
                        logTime.Add(wlog[Convert.ToInt32(wlog.IndexAtMD(v))].Value);
                }
            }

            float t0 = logTime.First();
            for (int i = 0; i < logTime.Count; i++)
                if (!(float.IsNaN(logTime[i]) || float.IsInfinity(logTime[i])))
                {
                    t0 = logTime[i];
                    i = logTime.Count + 1;
                    break;
                }

            List<float> new_log;
            List<float> new_time;
            upscaleWellLog(logProperty, logTime, out new_log, out new_time, t0, sample_rate);

            if (new_time.Count < 1)
                return;
            double cubeT0 = -1*cube.Origin.Z;
            double cubeTend = cubeT0 + cube.SampleSpacingIJK.Z * cube.NumSamplesIJK.K;
            if (new_time[0] > cubeTend || new_time.Last() < cubeT0)
                return;

            int j = 0;
            while (new_time[j] < cubeT0)
                j++;
            
            for (int i = 0; i < (int) cubeFP.getNumZlines(); i++)
            {
                if (j < new_log.Count)
                    cubeFP.setValueAt((ulong) itr.I,(ulong) itr.J, (ulong) i, new_log[j++]);
                else
                    break;
            }
        }


        public static void upscaleWellLog(List<float> log, List<float> time_log,
            out List<float> property, out List<float> time, float t0, float srate)
        {
            property = new List<float>();
            time = new List<float>();
            bool window_time_full = true;
            int i = 0;
            float sratel2 = srate / 2.0f;
            int initialK = 0;
            float well_srate = time_log[1] - time_log[0];
            float deltaT = 0.0f;
            float initial_time = 0.0f;
            float time0 = 0.0f;
            for (int k = 0; k < time_log.Count - 2; k++)
            {
                if (time_log[k] >= t0 - sratel2)
                { // para estrar na s�smica
                    if (window_time_full == true)
                    {
                        initialK = k;
                        window_time_full = false;
                        initial_time = (int)(time_log[k] / srate - 0.5) * srate + sratel2;
                        if (i == 0)
                        {
                            time0 = initial_time + sratel2;
                        }
                    }
                    if (k != 0)
                    {
                        List<float> DIFF = diff(
                                time_log.GetRange(initialK, k + 2 - initialK)); // cuidado indices -1 ou -2?
                        well_srate = DIFF.Average();
                    }
                    if (i == 0)
                    {
                        deltaT = time_log[k] - initial_time;
                    }
                    else
                    {
                        deltaT = time_log[k] - (time[i - 1] + sratel2);
                    }
                    if (window_time_full != true)
                    {
                        if (deltaT > srate - well_srate / 2)
                        {
                            property.Add(median(log.GetRange(initialK,
                                                    k + 2 - initialK))); // cuidado indices -1 ou -2?
                            time.Add((time0 + ((float)i) * (float)srate));
                            //VectorXd timeSegment = time_log.segment(initialK-1,k+2-initialK);
                            //time(i) = timeSegment.mean();
                            window_time_full = true;
                            i = i + 1;
                        }

                    }

                }
            }

        }

        public static List<float> diff(List<float> X)
        {
            int J = X.Count;
            List<float> delta = new List<float>();
            for (int j = 0; j < J - 1; ++j)
                delta.Add(X[j + 1] - X[j]);
            return delta;
        }


        public static float median(List<float> X)
        {
            X.Sort();
            int length = X.Count;
            float result;
            if (length % 2 == 0)
            {
                result = (X[length / 2 - 1] + X[length / 2]) / 2;
            }
            else
            {
                result = X[(int)(length / 2)];
            }
            return result;
        }

        // creates a horizon as the mean horizon minus half the maximum thickness in K indexing
        public static double[,] StartMeanHorizonFromTwo(ILattice horizonLattice,
            IEnumerable<RegularHeightFieldSample> horizonSamplesTop,
            IEnumerable<RegularHeightFieldSample> horizonSamplesBot,
            double shiftTop,
            double shiftBot,
            LatticeInfo lattice,
            double tstart_ms,
            double tstep_ms,
            double tend_ms,
            out double maxSamplesThickness)
        {

            // check if horizon lattice contains the selected lattice
            //ILattice intersect = LatticeUtils.Intersect(lattice, horlat, lattice, LatticeSampling.Reference);
            //if (!intersect.Operations.Equals(lattice))
            //    throw new Exception("Horizon does not cover selected inline and crossline range");

            Index2 ijsize = lattice.Corners.SizeIJ;
            int numSamples = ijsize.I * ijsize.J;

            double[,] horizonMat = new double[ijsize.I, ijsize.J];

            double[] x, y;
            x = new double[1];
            y = new double[1];

            double[,] hordouble = new double[horizonLattice.Corners.SizeIJ.I, horizonLattice.Corners.SizeIJ.J];

            foreach (RegularHeightFieldSample samp in horizonSamplesTop)
            {
                hordouble[samp.I, samp.J] = samp.Value;
            }

            double[,] hordoubleBot = new double[horizonLattice.Corners.SizeIJ.I, horizonLattice.Corners.SizeIJ.J];

            foreach (RegularHeightFieldSample samp in horizonSamplesBot)
            {
                hordoubleBot[samp.I, samp.J] = samp.Value;
            }

            double nVertsamples = -1 * (tend_ms - tstart_ms) / tstep_ms;

            double maxHorThickness = 0;
            for (int i = 0; i < ijsize.I; i++)
            {
                for (int j = 0; j < ijsize.J; j++)
                {
                    x[0] = i; y[0] = j;
                    lattice.Operations.IndexToWorld(x, y);
                    horizonLattice.Operations.WorldToIndex(x, y);

                    Index2 ij = new Index2(Convert.ToInt32(x[0]), Convert.ToInt32(y[0]));
                    // array out of bounds;

                    double top = -1 * (hordouble[ij.I, ij.J] * 1000 - tstart_ms - shiftTop) / tstep_ms;

                    double bott = -1 * (hordoubleBot[ij.I, ij.J] * 1000 - tstart_ms - shiftBot) / tstep_ms;

                    horizonMat[i, j] = (top + bott)/2;

                    if (bott - top > maxHorThickness)
                        maxHorThickness = bott - top;

                }
            }

            if (maxHorThickness > nVertsamples)
                throw new Exception("Your shifted horizons have more samples than the selected inversion area");

            for (int i = 0; i < ijsize.I; i++)
            {
                for (int j = 0; j < ijsize.J; j++)
                {
                    horizonMat[i, j] -= maxHorThickness / 2;

                    if (horizonMat[i, j] + maxHorThickness > nVertsamples)
                    {
                        horizonMat[i, j] = nVertsamples + 1 - maxHorThickness;
                    }

                    if (horizonMat[i, j] < 0.1)
                    {
                        horizonMat[i, j] = 0;
                    }

                }
            }

            maxSamplesThickness = maxHorThickness;
            return horizonMat;
        }
    }
}
