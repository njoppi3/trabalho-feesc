﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class FFTMATaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel _mean;
        public CubeFromPetrel _krigMeanInp = null;
        public CubeFromPetrel _krigVarInp = null;
        public CubeFromPetrel _condPoints = null;
        public CubeFromPetrel _krigMeanOut = null;
        public CubeFromPetrel _krigVarOut = null;

        public List<CubeFromPetrel> _results;
        public FFTMASimulWorkstepUI.FFTMASimulStruct _p;

        public int progressPct = 0;
        public String _statusMsg = "";

        public FFTMATaskSetup(ref CubeFromPetrel mean, ref List<CubeFromPetrel> results,
            ref FFTMASimulWorkstepUI.FFTMASimulStruct pars, CubeFromPetrel krigMeanInp = null,
            CubeFromPetrel krigVarInp = null, CubeFromPetrel krigMeanOut = null, 
            CubeFromPetrel krigVarOut = null, CubeFromPetrel condPoints = null)
        {
            _mean = mean;
            _p = pars;
            _results = results;
            _krigMeanInp = krigMeanInp;
            _krigVarInp = krigVarInp;
            _condPoints = condPoints;
            _krigMeanOut = krigMeanOut;
            _krigVarOut = krigVarOut;
    }

        public int progress()
        {
            return progressPct;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}