﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Slb.Ocean.Petrel.DomainObject.Well;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel.DomainObject.Basics;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.DomainObject.ColorTables;
using System.Drawing;

namespace UFSC_Plugins {
    public partial class WellLogSelect : UserControl {
        public List<Borehole> wells;
        public DictionaryWellLogVersion m_faciesLog; // facies discrete case
        public WellLogVersion m_timeLog; // time or facies continuous case
        public WellLogVersion m_xLog;
        public WellLogVersion m_yLog;
        public WellLogVersion m_zLog;
        public bool needsTWT = true;

        /**
         * Constructor
         */
        public WellLogSelect() {
            wells = new List<Borehole>();
            InitializeComponent();
        }

        /**
         * Disable the dropTargetTimeLog, the labelTimelog and the presentationBoxTime
         */
        public void disableTimeDrop() {
            dropTargetTimeLog.Dispose();
            presentationBoxTime.Dispose();
            labelTimelog.Dispose();
            dropTargetTimeLog = null;
            presentationBoxTime = null;
            labelTimelog = null;
            Refresh();
        }


        /**
         * disable the Zdrop, the labelTimelog and the presentationBoxTime
         */
        public void disableZlog()
        {
            dropTargetZ.Dispose();
            presentationBoxZ.Dispose();
            labelZ.Dispose();
            dropTargetZ = null;
            presentationBoxZ = null;
            labelZ = null;
            Refresh();
        }

        /**
         * Just clones WellLogSelect
         */
        public WellLogSelect Clone() {
            WellLogSelect ret = new WellLogSelect();

            ret.setAll(this);

            return ret;
        }

        /**
         * Set the data in the class by calling some methods
         */
        public void setAll(WellLogSelect wls) {
            clearWellsLogs();
            if (presentationBoxTime != null)
                presentationBoxTime.Text = "";
            presentationBoxXLog.Text = "";
            if (presentationBoxYLog != null)
                presentationBoxYLog.Text = "";
            if (presentationBoxZ != null)
                presentationBoxZ.Text = "";

            addWells(wls.wells);
            setLogTime(wls.m_timeLog);
            setLogX(wls.m_xLog);
            setLogY(wls.m_yLog);
            setLogZ(wls.m_zLog);

            setXText(wls.labelXlog.Text);
            if (wls.labelYlog != null)
                setYText(wls.labelYlog.Text);

            if (wls.labelZ != null)
            {
                enableLogDrops(true, 3);
                setZText(wls.labelZ.Text);
                return;
            }

            if (wls.labelYlog != null)
                enableLogDrops(true, 2);
            else
                enableLogDrops(true, 1);
        }

        public void setLogZ(WellLogVersion propertyLog)
        {
            m_zLog = propertyLog;
            if (propertyLog != null)
                presentationBoxZ.Text = propertyLog.Name;
        }

        public void setZText(string text)
        {
            if (labelZ != null)
                labelZ.Text = text;
        }

        /**
         * Set the text in the labelXlog
         */
        public void setXText(string xname) {
            labelXlog.Text = xname;
        }

        /**
         * Set the text in the labelTimelog
         */
        internal void setTimeText(string v) {
            if (labelTimelog != null)
                labelTimelog.Text = v;
        }

        /**
         * Set the text in the labelYlog
         */
        public void setYText(string yname) {
            if (labelYlog != null)
                labelYlog.Text = yname;
        }

        /**
         * Enables LogDrops according to the parameters
         */
        public void enableLogDrops(bool enabled, int numLogs) {
            presentationBoxXLog.Enabled = enabled;
            dropTargetXlog.Enabled = enabled;
            labelXlog.Enabled = enabled;

            if (numLogs == 3)
                if (presentationBoxZ != null)
                {
                    presentationBoxZ.Enabled = enabled;
                    dropTargetZ.Enabled = enabled;
                    labelZ.Enabled = enabled;
                }

            if (numLogs > 1) {
                if (presentationBoxYLog != null) {
                    presentationBoxYLog.Enabled = enabled;
                    dropTargetYlog.Enabled = enabled;
                    labelYlog.Enabled = enabled;
                }
            } else {
                presentationBoxYLog.Dispose();
                dropTargetYlog.Dispose();
                labelYlog.Dispose();
                presentationBoxYLog = null;
                dropTargetYlog = null;
                labelYlog = null;
                groupBoxGlobalWlogs.Refresh();
            }
        }

        /**
         * Disable the LogDrops
         */
        public void disableLogDrops() {
            enableLogDrops(false, 3);
        }

        /**
         * Get facies color table 
         */
        public List<DictionaryColorTableEntry> getFacieColorTable()
        {
            DictionaryColorTableAccess da = getDictFaciesAccess();
            if (da == null)
                return null;
            List<DictionaryColorTableEntry> faciesColorTable = new List<DictionaryColorTableEntry>();
            for (int i = 0; i < da.Size; ++i)
                faciesColorTable.Add(da.GetEntryAt(i));
            return faciesColorTable;
        }

        /**
         * Get facies undef color table
         */
        public DictionaryColorTableEntry getFaciesColorTableUndef()
        {
            DictionaryColorTableAccess da = getDictFaciesAccess();
            if (da == null)
                return null;
            return da.UndefinedEntry;
        }

        /**
         * Get facies names
         */
        public Dictionary<string, Color> getFaciesInfo()
        {
            if (getFacieColorTable() != null)
            {
                Dictionary<string, Color> fnames = new Dictionary<string, Color>();
                foreach (var f in getFacieColorTable())
                {
                    fnames.Add(f.Name, f.Color);
                }
                return fnames;
            }
            return null;
        }        

        /**
         * Add the selected well to the dataGridViewWells
         */
        private void dropTargetAddWell_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            Borehole well = dropped as Borehole;
            if (well == null) {
                PetrelLogger.WarnBox("Well not provided or given object is of wrong type.");
                return;
            }
            if (wells.Contains(well)) {
                PetrelLogger.WarnBox("Well has already been added to QC.");
                return;
            }
            wells.Add(well);
            dataGridViewWells.Rows.Add(well.Name, well.WellHead.X, well.WellHead.Y);
            well.Deleted += inputWell_Deleted;
        }

        
        /**
         * Remove the selected well of dataGridViewWells
         */
        private void buttonRemoveWell_Click_1(object sender, EventArgs e) {
            foreach (DataGridViewRow row in dataGridViewWells.SelectedRows) {
                if (wells[row.Index] != null) {
                    wells[row.Index].Deleted -= inputWell_Deleted;
                    wells.RemoveAt(row.Index);
                    dataGridViewWells.Rows.RemoveAt(row.Index);
                }
            }
        }

        /**
         * Well deleted outside the plugin
         */ 
        private void inputWell_Deleted(object sender, EventArgs e)
        {
            Borehole w = sender as Borehole;
            if (w != null)
            {
                List<Borehole> wells_tmp = wells;
                int idx = 0;
                foreach(Borehole wt in wells_tmp)
                {
                    if (wt.Droid.Equals(w.Droid))
                    {
                        wells.RemoveAt(idx);
                        dataGridViewWells.Rows.RemoveAt(idx);
                        PetrelLogger.WarnBox(wt.Name + " was deleted and removed from L3C plugin");
                    }
                    idx++;
                }
            }
        }

        /**
         * Get the global well log
         */
        private void dropTargetTimeLog_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            WellLogVersion t_timeLog = dropped as WellLogVersion;
            DictionaryWellLogVersion t_facies = dropped as DictionaryWellLogVersion;
            if (t_timeLog == null && t_facies == null) {
                PetrelLogger.WarnBox("Global Well Log not provided or given object is of wrong type.");
                return;
            }
            if (needsTWT && t_timeLog != null) { 
                if (t_timeLog.Template != Domain.TWT.Template)
                {
                    PetrelLogger.WarnBox("Global Well Log is not a Two Way Time Template.");
                    return;
                }
            } 

            if (t_timeLog != null)
            {
                m_timeLog = t_timeLog;
                m_timeLog.Deleted += M_timeLog_Deleted;
                presentationBoxTime.Text = m_timeLog.Name;
            } else if (t_facies != null)
            {
                m_faciesLog = t_facies;
                m_faciesLog.Deleted += M_faciesLog_Deleted;
                presentationBoxTime.Text = m_faciesLog.Name;
            }
            enableLogDrops(true, 3);
            
        }

        /**
         * Listens if global well log is deleted, if deleted set default text in presentationBoxTime
         */
        private void M_timeLog_Deleted(object sender, EventArgs e) {
            m_timeLog = null;
            if (presentationBoxTime != null)
                presentationBoxTime.Name = "";
        }

        private void M_faciesLog_Deleted(object sender, EventArgs e) {
            m_faciesLog = null;
            if (presentationBoxTime != null)
                presentationBoxTime.Name = "";
        }

        /**
         * Get the global well log
         */
        private void dropTargetXlog_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            WellLogVersion t_vpLog = dropped as WellLogVersion;
            if (t_vpLog == null) {
                PetrelLogger.WarnBox("Global Well Log not provided or given object is of wrong type.");
                return;
            } else {
                m_xLog = t_vpLog;
                presentationBoxXLog.Text = m_xLog.Name;
                m_xLog.Deleted += M_vpLog_Deleted;
            }
        }

        /**
         * Listens if global well log is deleted, if deleted set default text in presentationBoxXLog
         */
        private void M_vpLog_Deleted(object sender, EventArgs e) {
            m_xLog = null;
            presentationBoxXLog.Text = "";
        }

        /**
         * Get the global well log
         */
        private void dropTargetYlog_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            WellLogVersion t_vsLog = dropped as WellLogVersion;
            if (t_vsLog == null) {
                PetrelLogger.WarnBox("Global Well Log not provided or given object is of wrong type.");
                return;
            } else {
                m_yLog = t_vsLog;
                presentationBoxYLog.Text = m_yLog.Name;
                m_yLog.Deleted += M_vsLog_Deleted;
            }
        }

        /**
         * Listens if global well log is deleted, if deleted set default text in presentationBoxYLog
         */
        private void M_vsLog_Deleted(object sender, EventArgs e) {
            m_yLog = null;
            if (presentationBoxYLog != null) {
                presentationBoxYLog.Text = "";
            }
        }

        /**
         * Clear the well logs
         */
        public void clearWellsLogs() {
            wells.Clear();
            dataGridViewWells.Rows.Clear();
            if (presentationBoxTime != null)
                presentationBoxTime.Text = "";
            m_faciesLog = null;
            m_timeLog = null;
            m_xLog = null;
            m_yLog = null;
            m_zLog = null;
            presentationBoxXLog.Text = "";
            if (presentationBoxYLog != null) {
                presentationBoxYLog.Text = "";
            }
            if (presentationBoxZ != null)
            {
                presentationBoxZ.Text = "";
            }
        }

        /**
         * 
         */
        private void groupBoxGlobalWlogs_Enter(object sender, EventArgs e) {

        }

        /**
         * Set the m_timeLog
         */
        internal void setLogTime(WellLogVersion timelog) {
            m_timeLog = timelog;
            if (timelog != null)
                presentationBoxTime.Text = timelog.Name;
        }

        /**
         * Set the m_faciesLog
         */
        internal void setLogFacies(DictionaryWellLogVersion faciesLog)
        {
            m_faciesLog = faciesLog;
            if (faciesLog != null)
                presentationBoxTime.Text = faciesLog.Name;
        }

        /**
         * Set the m_xLog
         */
        internal void setLogX(WellLogVersion propertyLog) {
            m_xLog = propertyLog;
            if (propertyLog != null)
                presentationBoxXLog.Text = propertyLog.Name;
        }

        /**
         * Set the m_yLog
         */
        internal void setLogY(WellLogVersion propertyLog) {
            m_yLog = propertyLog;
            if (propertyLog != null)
                presentationBoxYLog.Text = propertyLog.Name;
        }

        /**
         * Add a list of wells in the dataGridViewWells
         */
        internal void addWells(List<Borehole> wellsToadd) {
            foreach (Borehole well in wellsToadd) {
                wells.Add(well);
                dataGridViewWells.Rows.Add(well.Name, well.WellHead.X, well.WellHead.Y);
            }
        }

        /**
         * Add a well in the dataGridViewWells
         */
        internal void addWell(Borehole well) {
            wells.Add(well);
            dataGridViewWells.Rows.Add(well.Name, well.WellHead.X, well.WellHead.Y);
        }

        /**
         * Get a list of WellDroid
         */
        public List<string> getWellDroids() {
            List<string> wellDroids = new List<string>();
            foreach (Borehole well in wells)
                wellDroids.Add(well.Droid.ToString());
            return wellDroids;

        }

        /**
         * Add a list of wells in the dataGridViewWells by their droids
         */
        internal void addWells(List<string> wellDroid) {
            foreach (string well in wellDroid) {
                Borehole b = null;
                if (well != null && well != "")
                    b = Functions.getWell(new Droid(well));

                if (b != null)
                    addWell(b);
            }
        }

        private DictionaryColorTableAccess getDictFaciesAccess()
        {
            if (m_faciesLog == null)
                return null;
            ColorTableRoot ctRoot;
            ctRoot = ColorTableRoot.Get(PetrelProject.PrimaryProject);
            return ctRoot.GetDictionaryColorTableAccess(m_faciesLog);
        }

        private void dropTargetZ_DragDrop(object sender, DragEventArgs e)
        {
            object dropped = e.Data.GetData(typeof(object));
            if (dropped == null)
                return;
            WellLogVersion t_vsLog = dropped as WellLogVersion;
            if (t_vsLog == null)
            {
                PetrelLogger.WarnBox("Global Well Log not provided or given object is of wrong type.");
                return;
            }
            else
            {
                m_zLog = t_vsLog;
                presentationBoxZ.Text = m_zLog.Name;
                m_zLog.Deleted += M_zLog_Deleted;
            }
        }

        private void M_zLog_Deleted(object sender, EventArgs e)
        {
            m_zLog = null;
            if (presentationBoxZ != null)
            {
                presentationBoxZ.Text = "";
            }
        }

    }
}