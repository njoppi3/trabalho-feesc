namespace UFSC_Plugins
{
    partial class ElasticInversionWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Slb.Ocean.Petrel.UI.Controls.ToolTipInfo toolTipInfo1 = new Slb.Ocean.Petrel.UI.Controls.ToolTipInfo();
            Slb.Ocean.Petrel.UI.Controls.ToolTipItem toolTipItem1 = new Slb.Ocean.Petrel.UI.Controls.ToolTipItem();
            Slb.Ocean.Petrel.UI.Controls.ToolTipItem toolTipItem2 = new Slb.Ocean.Petrel.UI.Controls.ToolTipItem();
            Slb.Ocean.Petrel.UI.Controls.ToolTipItem toolTipItem3 = new Slb.Ocean.Petrel.UI.Controls.ToolTipItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ElasticInversionWorkstepUI));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rhoPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.vsPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.vpPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.rhoDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.vsDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.vpDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.rhoTrendText = new System.Windows.Forms.Label();
            this.vsTrendText = new System.Windows.Forms.Label();
            this.vpTrendText = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.labelVPVSOut = new System.Windows.Forms.Label();
            this.VPVSCubetextBox = new System.Windows.Forms.TextBox();
            this.labelIPOut = new System.Windows.Forms.Label();
            this.IPCubetextBox = new System.Windows.Forms.TextBox();
            this.ComputeIP_VPVS_CheckBox = new System.Windows.Forms.CheckBox();
            this.labelResOut = new System.Windows.Forms.Label();
            this.labelRhoOut = new System.Windows.Forms.Label();
            this.labelVsOut = new System.Windows.Forms.Label();
            this.labelVpOut = new System.Windows.Forms.Label();
            this.residualCubeTextBox = new System.Windows.Forms.TextBox();
            this.rhoCubeTextBox = new System.Windows.Forms.TextBox();
            this.vsCubeTextBox = new System.Windows.Forms.TextBox();
            this.vpCubeTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.correlationRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.vsRhoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.vpRhoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.vpVsUpDown = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.rhoUpDown = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.vsUpDown = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.vpUpDown = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.toolTipHotspot1 = new Slb.Ocean.Petrel.UI.Controls.ToolTipHotspot(this.components);
            this.labelSuggStd = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelSeisStd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.inputCubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.waveletPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.removeButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Wavelett = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cube = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Angle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SNR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addButton = new System.Windows.Forms.Button();
            this.waveletDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label19 = new System.Windows.Forms.Label();
            this.inputCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.signalToNoiseUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.angleUpDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.verticalGateButton = new System.Windows.Forms.Button();
            this.mergeInvCheckBox = new System.Windows.Forms.CheckBox();
            this.inlineInvPreviewUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlineInvPreviewCheckBox = new System.Windows.Forms.CheckBox();
            this.trendFreqCutUpDown = new System.Windows.Forms.NumericUpDown();
            this.trendFreqCutCheckBox = new System.Windows.Forms.CheckBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.okButton = new System.Windows.Forms.Button();
            this.toolTipManager1 = new Slb.Ocean.Petrel.UI.Controls.ToolTipManager(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vsRhoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpRhoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpVsUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rhoUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vsUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpUpDown)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angleUpDown)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPreviewUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqCutUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolTipManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rhoPresentationBox);
            this.groupBox2.Controls.Add(this.vsPresentationBox);
            this.groupBox2.Controls.Add(this.vpPresentationBox);
            this.groupBox2.Controls.Add(this.rhoDrop);
            this.groupBox2.Controls.Add(this.vsDrop);
            this.groupBox2.Controls.Add(this.vpDrop);
            this.groupBox2.Controls.Add(this.rhoTrendText);
            this.groupBox2.Controls.Add(this.vsTrendText);
            this.groupBox2.Controls.Add(this.vpTrendText);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 229);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(450, 44);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Trends";
            // 
            // rhoPresentationBox
            // 
            this.rhoPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhoPresentationBox.Location = new System.Drawing.Point(355, 17);
            this.rhoPresentationBox.Name = "rhoPresentationBox";
            this.rhoPresentationBox.Size = new System.Drawing.Size(82, 22);
            this.rhoPresentationBox.TabIndex = 62;
            this.rhoPresentationBox.TabStop = false;
            // 
            // vsPresentationBox
            // 
            this.vsPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsPresentationBox.Location = new System.Drawing.Point(208, 17);
            this.vsPresentationBox.Name = "vsPresentationBox";
            this.vsPresentationBox.Size = new System.Drawing.Size(82, 22);
            this.vsPresentationBox.TabIndex = 61;
            this.vsPresentationBox.TabStop = false;
            // 
            // vpPresentationBox
            // 
            this.vpPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpPresentationBox.Location = new System.Drawing.Point(64, 17);
            this.vpPresentationBox.Name = "vpPresentationBox";
            this.vpPresentationBox.Size = new System.Drawing.Size(82, 22);
            this.vpPresentationBox.TabIndex = 60;
            this.vpPresentationBox.TabStop = false;
            // 
            // rhoDrop
            // 
            this.rhoDrop.AllowDrop = true;
            this.rhoDrop.Location = new System.Drawing.Point(328, 16);
            this.rhoDrop.Name = "rhoDrop";
            this.rhoDrop.Size = new System.Drawing.Size(24, 22);
            this.rhoDrop.TabIndex = 2;
            this.rhoDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.rhoDrop_DragDrop);
            // 
            // vsDrop
            // 
            this.vsDrop.AllowDrop = true;
            this.vsDrop.Location = new System.Drawing.Point(178, 16);
            this.vsDrop.Name = "vsDrop";
            this.vsDrop.Size = new System.Drawing.Size(24, 22);
            this.vsDrop.TabIndex = 1;
            this.vsDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.vsDrop_DragDrop);
            // 
            // vpDrop
            // 
            this.vpDrop.AllowDrop = true;
            this.vpDrop.Location = new System.Drawing.Point(34, 16);
            this.vpDrop.Name = "vpDrop";
            this.vpDrop.Size = new System.Drawing.Size(24, 22);
            this.vpDrop.TabIndex = 0;
            this.vpDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.vpDrop_DragDrop);
            // 
            // rhoTrendText
            // 
            this.rhoTrendText.AutoSize = true;
            this.rhoTrendText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhoTrendText.Location = new System.Drawing.Point(297, 22);
            this.rhoTrendText.Name = "rhoTrendText";
            this.rhoTrendText.Size = new System.Drawing.Size(30, 13);
            this.rhoTrendText.TabIndex = 8;
            this.rhoTrendText.Text = "Rho:";
            // 
            // vsTrendText
            // 
            this.vsTrendText.AutoSize = true;
            this.vsTrendText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsTrendText.Location = new System.Drawing.Point(153, 22);
            this.vsTrendText.Name = "vsTrendText";
            this.vsTrendText.Size = new System.Drawing.Size(22, 13);
            this.vsTrendText.TabIndex = 6;
            this.vsTrendText.Text = "Vs:";
            // 
            // vpTrendText
            // 
            this.vpTrendText.AutoSize = true;
            this.vpTrendText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpTrendText.Location = new System.Drawing.Point(8, 22);
            this.vpTrendText.Name = "vpTrendText";
            this.vpTrendText.Size = new System.Drawing.Size(23, 13);
            this.vpTrendText.TabIndex = 3;
            this.vpTrendText.Text = "Vp:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.labelVPVSOut);
            this.groupBox5.Controls.Add(this.VPVSCubetextBox);
            this.groupBox5.Controls.Add(this.labelIPOut);
            this.groupBox5.Controls.Add(this.IPCubetextBox);
            this.groupBox5.Controls.Add(this.ComputeIP_VPVS_CheckBox);
            this.groupBox5.Controls.Add(this.labelResOut);
            this.groupBox5.Controls.Add(this.labelRhoOut);
            this.groupBox5.Controls.Add(this.labelVsOut);
            this.groupBox5.Controls.Add(this.labelVpOut);
            this.groupBox5.Controls.Add(this.residualCubeTextBox);
            this.groupBox5.Controls.Add(this.rhoCubeTextBox);
            this.groupBox5.Controls.Add(this.vsCubeTextBox);
            this.groupBox5.Controls.Add(this.vpCubeTextBox);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(3, 521);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(449, 224);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Output";
            // 
            // labelVPVSOut
            // 
            this.labelVPVSOut.AutoSize = true;
            this.labelVPVSOut.Enabled = false;
            this.labelVPVSOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVPVSOut.Location = new System.Drawing.Point(9, 186);
            this.labelVPVSOut.Name = "labelVPVSOut";
            this.labelVPVSOut.Size = new System.Drawing.Size(97, 13);
            this.labelVPVSOut.TabIndex = 19;
            this.labelVPVSOut.Text = "Vp/Vs cube output";
            // 
            // VPVSCubetextBox
            // 
            this.VPVSCubetextBox.Enabled = false;
            this.VPVSCubetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VPVSCubetextBox.Location = new System.Drawing.Point(118, 183);
            this.VPVSCubetextBox.Name = "VPVSCubetextBox";
            this.VPVSCubetextBox.Size = new System.Drawing.Size(322, 20);
            this.VPVSCubetextBox.TabIndex = 18;
            this.VPVSCubetextBox.Text = "vpvs_cube_output";
            // 
            // labelIPOut
            // 
            this.labelIPOut.AutoSize = true;
            this.labelIPOut.Enabled = false;
            this.labelIPOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIPOut.Location = new System.Drawing.Point(9, 160);
            this.labelIPOut.Name = "labelIPOut";
            this.labelIPOut.Size = new System.Drawing.Size(77, 13);
            this.labelIPOut.TabIndex = 17;
            this.labelIPOut.Text = "IP cube output";
            // 
            // IPCubetextBox
            // 
            this.IPCubetextBox.Enabled = false;
            this.IPCubetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IPCubetextBox.Location = new System.Drawing.Point(118, 157);
            this.IPCubetextBox.Name = "IPCubetextBox";
            this.IPCubetextBox.Size = new System.Drawing.Size(322, 20);
            this.IPCubetextBox.TabIndex = 16;
            this.IPCubetextBox.Text = "ip_cube_output";
            // 
            // ComputeIP_VPVS_CheckBox
            // 
            this.ComputeIP_VPVS_CheckBox.AutoSize = true;
            this.ComputeIP_VPVS_CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComputeIP_VPVS_CheckBox.Location = new System.Drawing.Point(11, 134);
            this.ComputeIP_VPVS_CheckBox.Name = "ComputeIP_VPVS_CheckBox";
            this.ComputeIP_VPVS_CheckBox.Size = new System.Drawing.Size(167, 17);
            this.ComputeIP_VPVS_CheckBox.TabIndex = 15;
            this.ComputeIP_VPVS_CheckBox.Text = "Compute IP and Vp/Vs cubes";
            this.ComputeIP_VPVS_CheckBox.UseVisualStyleBackColor = true;
            this.ComputeIP_VPVS_CheckBox.CheckedChanged += new System.EventHandler(this.ComputeIA_VPVS_CheckBox_CheckedChanged);
            // 
            // labelResOut
            // 
            this.labelResOut.AutoSize = true;
            this.labelResOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelResOut.Location = new System.Drawing.Point(8, 111);
            this.labelResOut.Name = "labelResOut";
            this.labelResOut.Size = new System.Drawing.Size(103, 13);
            this.labelResOut.TabIndex = 14;
            this.labelResOut.Text = "Residual cube prefix";
            // 
            // labelRhoOut
            // 
            this.labelRhoOut.AutoSize = true;
            this.labelRhoOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRhoOut.Location = new System.Drawing.Point(8, 82);
            this.labelRhoOut.Name = "labelRhoOut";
            this.labelRhoOut.Size = new System.Drawing.Size(87, 13);
            this.labelRhoOut.TabIndex = 13;
            this.labelRhoOut.Text = "Rho cube output";
            // 
            // labelVsOut
            // 
            this.labelVsOut.AutoSize = true;
            this.labelVsOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVsOut.Location = new System.Drawing.Point(8, 53);
            this.labelVsOut.Name = "labelVsOut";
            this.labelVsOut.Size = new System.Drawing.Size(79, 13);
            this.labelVsOut.TabIndex = 12;
            this.labelVsOut.Text = "Vs cube output";
            // 
            // labelVpOut
            // 
            this.labelVpOut.AutoSize = true;
            this.labelVpOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVpOut.Location = new System.Drawing.Point(8, 24);
            this.labelVpOut.Name = "labelVpOut";
            this.labelVpOut.Size = new System.Drawing.Size(80, 13);
            this.labelVpOut.TabIndex = 11;
            this.labelVpOut.Text = "Vp cube output";
            // 
            // residualCubeTextBox
            // 
            this.residualCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.residualCubeTextBox.Location = new System.Drawing.Point(117, 108);
            this.residualCubeTextBox.Name = "residualCubeTextBox";
            this.residualCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.residualCubeTextBox.TabIndex = 3;
            this.residualCubeTextBox.Text = "residual_cube_output";
            // 
            // rhoCubeTextBox
            // 
            this.rhoCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhoCubeTextBox.Location = new System.Drawing.Point(117, 79);
            this.rhoCubeTextBox.Name = "rhoCubeTextBox";
            this.rhoCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.rhoCubeTextBox.TabIndex = 2;
            this.rhoCubeTextBox.Text = "rho_cube_output";
            // 
            // vsCubeTextBox
            // 
            this.vsCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsCubeTextBox.Location = new System.Drawing.Point(117, 50);
            this.vsCubeTextBox.Name = "vsCubeTextBox";
            this.vsCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.vsCubeTextBox.TabIndex = 1;
            this.vsCubeTextBox.Text = "vs_cube_output";
            // 
            // vpCubeTextBox
            // 
            this.vpCubeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpCubeTextBox.Location = new System.Drawing.Point(117, 21);
            this.vpCubeTextBox.Name = "vpCubeTextBox";
            this.vpCubeTextBox.Size = new System.Drawing.Size(322, 20);
            this.vpCubeTextBox.TabIndex = 0;
            this.vpCubeTextBox.Text = "vp_cube_output";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.correlationRangeUpDown);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.vsRhoUpDown);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.vpRhoUpDown);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.vpVsUpDown);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.rhoUpDown);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.vsUpDown);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.vpUpDown);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 279);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 148);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Parameters";
            // 
            // correlationRangeUpDown
            // 
            this.correlationRangeUpDown.DecimalPlaces = 2;
            this.correlationRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correlationRangeUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.correlationRangeUpDown.Location = new System.Drawing.Point(251, 122);
            this.correlationRangeUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.correlationRangeUpDown.Name = "correlationRangeUpDown";
            this.correlationRangeUpDown.Size = new System.Drawing.Size(188, 20);
            this.correlationRangeUpDown.TabIndex = 6;
            this.correlationRangeUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(8, 124);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 13);
            this.label17.TabIndex = 21;
            this.label17.Text = "Correlation range (ms)";
            // 
            // vsRhoUpDown
            // 
            this.vsRhoUpDown.DecimalPlaces = 2;
            this.vsRhoUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsRhoUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.vsRhoUpDown.Location = new System.Drawing.Point(321, 96);
            this.vsRhoUpDown.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.vsRhoUpDown.Name = "vsRhoUpDown";
            this.vsRhoUpDown.Size = new System.Drawing.Size(118, 20);
            this.vsRhoUpDown.TabIndex = 5;
            this.vsRhoUpDown.Value = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(248, 98);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 13);
            this.label16.TabIndex = 19;
            this.label16.Text = "Vs-Rho";
            // 
            // vpRhoUpDown
            // 
            this.vpRhoUpDown.DecimalPlaces = 2;
            this.vpRhoUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpRhoUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.vpRhoUpDown.Location = new System.Drawing.Point(321, 70);
            this.vpRhoUpDown.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.vpRhoUpDown.Name = "vpRhoUpDown";
            this.vpRhoUpDown.Size = new System.Drawing.Size(118, 20);
            this.vpRhoUpDown.TabIndex = 4;
            this.vpRhoUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(248, 72);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Vp-Rho";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(238, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Correlations";
            // 
            // vpVsUpDown
            // 
            this.vpVsUpDown.DecimalPlaces = 2;
            this.vpVsUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpVsUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.vpVsUpDown.Location = new System.Drawing.Point(321, 44);
            this.vpVsUpDown.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.vpVsUpDown.Name = "vpVsUpDown";
            this.vpVsUpDown.Size = new System.Drawing.Size(118, 20);
            this.vpVsUpDown.TabIndex = 3;
            this.vpVsUpDown.Value = new decimal(new int[] {
            7,
            0,
            0,
            65536});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(248, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 14;
            this.label13.Text = "Vp-Vs";
            // 
            // rhoUpDown
            // 
            this.rhoUpDown.DecimalPlaces = 2;
            this.rhoUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhoUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.rhoUpDown.Location = new System.Drawing.Point(55, 97);
            this.rhoUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.rhoUpDown.Name = "rhoUpDown";
            this.rhoUpDown.Size = new System.Drawing.Size(176, 20);
            this.rhoUpDown.TabIndex = 2;
            this.rhoUpDown.Value = new decimal(new int[] {
            3,
            0,
            0,
            131072});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Rho:";
            // 
            // vsUpDown
            // 
            this.vsUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vsUpDown.Location = new System.Drawing.Point(55, 71);
            this.vsUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.vsUpDown.Name = "vsUpDown";
            this.vsUpDown.Size = new System.Drawing.Size(176, 20);
            this.vsUpDown.TabIndex = 1;
            this.vsUpDown.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(18, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Vs:";
            // 
            // vpUpDown
            // 
            this.vpUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vpUpDown.Location = new System.Drawing.Point(55, 45);
            this.vpUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.vpUpDown.Name = "vpUpDown";
            this.vpUpDown.Size = new System.Drawing.Size(176, 20);
            this.vpUpDown.TabIndex = 0;
            this.vpUpDown.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(18, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Vp:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Velocity Uncertainty";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.toolTipHotspot1);
            this.groupBox1.Controls.Add(this.labelSuggStd);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.labelSeisStd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.inputCubePresentationBox);
            this.groupBox1.Controls.Add(this.waveletPresentationBox);
            this.groupBox1.Controls.Add(this.removeButton);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.addButton);
            this.groupBox1.Controls.Add(this.waveletDrop);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.inputCubeDrop);
            this.groupBox1.Controls.Add(this.signalToNoiseUpDown);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.angleUpDown);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 223);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inputs";
            // 
            // toolTipHotspot1
            // 
            this.toolTipHotspot1.Location = new System.Drawing.Point(424, 87);
            this.toolTipHotspot1.Name = "toolTipHotspot1";
            this.toolTipHotspot1.Size = new System.Drawing.Size(20, 20);
            this.toolTipHotspot1.TabIndex = 21;
            toolTipItem1.FontStyle = System.Drawing.FontStyle.Bold;
            toolTipItem1.Text = "Noise Standard Deviation Helpers";
            toolTipItem2.ShowBullet = true;
            toolTipItem2.Text = "Selected Seismic Std: This option shows the seismic standard deviation for the us" +
    "er to have an idea of the signal magnitude of the current selected seismic data." +
    "";
            toolTipItem3.ShowBullet = true;
            toolTipItem3.Text = resources.GetString("toolTipItem3.Text");
            toolTipInfo1.Items.AddRange(new Slb.Ocean.Petrel.UI.Controls.ToolTipItemBase[] {
            toolTipItem1,
            toolTipItem2,
            toolTipItem3});
            this.toolTipManager1.SetToolTip(this.toolTipHotspot1, toolTipInfo1);
            // 
            // labelSuggStd
            // 
            this.labelSuggStd.AutoSize = true;
            this.labelSuggStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuggStd.Location = new System.Drawing.Point(319, 103);
            this.labelSuggStd.Name = "labelSuggStd";
            this.labelSuggStd.Size = new System.Drawing.Size(13, 13);
            this.labelSuggStd.TabIndex = 20;
            this.labelSuggStd.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(205, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Suggested noise Std:";
            // 
            // labelSeisStd
            // 
            this.labelSeisStd.AutoSize = true;
            this.labelSeisStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeisStd.Location = new System.Drawing.Point(321, 75);
            this.labelSeisStd.Name = "labelSeisStd";
            this.labelSeisStd.Size = new System.Drawing.Size(13, 13);
            this.labelSeisStd.TabIndex = 18;
            this.labelSeisStd.Text = "0";
            this.labelSeisStd.Click += new System.EventHandler(this.label6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(205, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Selected Seismic Std:";
            // 
            // inputCubePresentationBox
            // 
            this.inputCubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputCubePresentationBox.Location = new System.Drawing.Point(336, 20);
            this.inputCubePresentationBox.Name = "inputCubePresentationBox";
            this.inputCubePresentationBox.Size = new System.Drawing.Size(103, 22);
            this.inputCubePresentationBox.TabIndex = 3;
            this.inputCubePresentationBox.TabStop = false;
            // 
            // waveletPresentationBox
            // 
            this.waveletPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waveletPresentationBox.Location = new System.Drawing.Point(118, 20);
            this.waveletPresentationBox.Name = "waveletPresentationBox";
            this.waveletPresentationBox.Size = new System.Drawing.Size(103, 22);
            this.waveletPresentationBox.TabIndex = 2;
            this.waveletPresentationBox.TabStop = false;
            // 
            // removeButton
            // 
            this.removeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeButton.Location = new System.Drawing.Point(91, 103);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(91, 23);
            this.removeButton.TabIndex = 5;
            this.removeButton.Text = "Remove";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Wavelett,
            this.Cube,
            this.Angle,
            this.SNR});
            this.dataGridView1.Location = new System.Drawing.Point(11, 132);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(428, 85);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.TabStop = false;
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            // 
            // Wavelett
            // 
            this.Wavelett.HeaderText = "Wavelet";
            this.Wavelett.Name = "Wavelett";
            this.Wavelett.ReadOnly = true;
            this.Wavelett.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Cube
            // 
            this.Cube.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Cube.HeaderText = "Cube";
            this.Cube.Name = "Cube";
            this.Cube.ReadOnly = true;
            this.Cube.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Angle
            // 
            this.Angle.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Angle.HeaderText = "Angle";
            this.Angle.Name = "Angle";
            this.Angle.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SNR
            // 
            this.SNR.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SNR.HeaderText = "Noise std";
            this.SNR.Name = "SNR";
            this.SNR.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SNR.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(11, 103);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(74, 23);
            this.addButton.TabIndex = 4;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // waveletDrop
            // 
            this.waveletDrop.AllowDrop = true;
            this.waveletDrop.Location = new System.Drawing.Point(88, 19);
            this.waveletDrop.Name = "waveletDrop";
            this.waveletDrop.Size = new System.Drawing.Size(24, 22);
            this.waveletDrop.TabIndex = 0;
            this.waveletDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.waveletDrop_DragDrop);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(8, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 16;
            this.label19.Text = "Input Wavelet:";
            // 
            // inputCubeDrop
            // 
            this.inputCubeDrop.AllowDrop = true;
            this.inputCubeDrop.Location = new System.Drawing.Point(306, 20);
            this.inputCubeDrop.Name = "inputCubeDrop";
            this.inputCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.inputCubeDrop.TabIndex = 1;
            this.inputCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.inputCubeDrop_DragDrop);
            // 
            // signalToNoiseUpDown
            // 
            this.signalToNoiseUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signalToNoiseUpDown.Location = new System.Drawing.Point(358, 48);
            this.signalToNoiseUpDown.Maximum = new decimal(new int[] {
            -402653185,
            -1613725636,
            54210108,
            0});
            this.signalToNoiseUpDown.Name = "signalToNoiseUpDown";
            this.signalToNoiseUpDown.Size = new System.Drawing.Size(66, 20);
            this.signalToNoiseUpDown.TabIndex = 3;
            this.signalToNoiseUpDown.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(185, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Seismic Noise Standard Deviation";
            // 
            // angleUpDown
            // 
            this.angleUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angleUpDown.Location = new System.Drawing.Point(91, 68);
            this.angleUpDown.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.angleUpDown.Name = "angleUpDown";
            this.angleUpDown.Size = new System.Drawing.Size(66, 20);
            this.angleUpDown.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Angle (degrees)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Parameters";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(230, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Input Seismic:";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(473, 748);
            this.panel1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.verticalGateButton);
            this.groupBox4.Controls.Add(this.mergeInvCheckBox);
            this.groupBox4.Controls.Add(this.inlineInvPreviewUpDown);
            this.groupBox4.Controls.Add(this.inlineInvPreviewCheckBox);
            this.groupBox4.Controls.Add(this.trendFreqCutUpDown);
            this.groupBox4.Controls.Add(this.trendFreqCutCheckBox);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(3, 433);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(450, 82);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Options";
            // 
            // verticalGateButton
            // 
            this.verticalGateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verticalGateButton.Location = new System.Drawing.Point(241, 49);
            this.verticalGateButton.Name = "verticalGateButton";
            this.verticalGateButton.Size = new System.Drawing.Size(198, 23);
            this.verticalGateButton.TabIndex = 5;
            this.verticalGateButton.Text = "Vertical Gate";
            this.verticalGateButton.UseVisualStyleBackColor = true;
            this.verticalGateButton.Click += new System.EventHandler(this.verticalGateButton_Click);
            // 
            // mergeInvCheckBox
            // 
            this.mergeInvCheckBox.AutoSize = true;
            this.mergeInvCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mergeInvCheckBox.Location = new System.Drawing.Point(241, 23);
            this.mergeInvCheckBox.Name = "mergeInvCheckBox";
            this.mergeInvCheckBox.Size = new System.Drawing.Size(150, 17);
            this.mergeInvCheckBox.TabIndex = 4;
            this.mergeInvCheckBox.Text = "Merge inversion with trend";
            this.mergeInvCheckBox.UseVisualStyleBackColor = true;
            // 
            // inlineInvPreviewUpDown
            // 
            this.inlineInvPreviewUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPreviewUpDown.Location = new System.Drawing.Point(169, 48);
            this.inlineInvPreviewUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.inlineInvPreviewUpDown.Name = "inlineInvPreviewUpDown";
            this.inlineInvPreviewUpDown.Size = new System.Drawing.Size(62, 20);
            this.inlineInvPreviewUpDown.TabIndex = 3;
            // 
            // inlineInvPreviewCheckBox
            // 
            this.inlineInvPreviewCheckBox.AutoSize = true;
            this.inlineInvPreviewCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPreviewCheckBox.Location = new System.Drawing.Point(23, 49);
            this.inlineInvPreviewCheckBox.Name = "inlineInvPreviewCheckBox";
            this.inlineInvPreviewCheckBox.Size = new System.Drawing.Size(136, 17);
            this.inlineInvPreviewCheckBox.TabIndex = 2;
            this.inlineInvPreviewCheckBox.Text = "Inline inversion preview";
            this.inlineInvPreviewCheckBox.UseVisualStyleBackColor = true;
            // 
            // trendFreqCutUpDown
            // 
            this.trendFreqCutUpDown.DecimalPlaces = 1;
            this.trendFreqCutUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trendFreqCutUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.trendFreqCutUpDown.Location = new System.Drawing.Point(169, 22);
            this.trendFreqCutUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.trendFreqCutUpDown.Name = "trendFreqCutUpDown";
            this.trendFreqCutUpDown.Size = new System.Drawing.Size(62, 20);
            this.trendFreqCutUpDown.TabIndex = 1;
            this.trendFreqCutUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // trendFreqCutCheckBox
            // 
            this.trendFreqCutCheckBox.AutoSize = true;
            this.trendFreqCutCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trendFreqCutCheckBox.Location = new System.Drawing.Point(23, 23);
            this.trendFreqCutCheckBox.Name = "trendFreqCutCheckBox";
            this.trendFreqCutCheckBox.Size = new System.Drawing.Size(144, 17);
            this.trendFreqCutCheckBox.TabIndex = 0;
            this.trendFreqCutCheckBox.Text = "Trend frequency cut (Hz)";
            this.trendFreqCutCheckBox.UseVisualStyleBackColor = true;
            // 
            // saveButton
            // 
            this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.saveButton.Location = new System.Drawing.Point(128, 752);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.closeButton.Location = new System.Drawing.Point(394, 752);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 5;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.applyButton.Location = new System.Drawing.Point(233, 752);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 3;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(35, 757);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 13);
            this.label18.TabIndex = 55;
            this.label18.Text = "Load Parameters";
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(2, 752);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 1;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // okButton
            // 
            this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.okButton.Location = new System.Drawing.Point(309, 752);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 4;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // ElasticInversionWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label18);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.loadDrop);
            this.Name = "ElasticInversionWorkstepUI";
            this.Size = new System.Drawing.Size(480, 784);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vsRhoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpRhoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpVsUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rhoUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vsUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vpUpDown)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angleUpDown)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPreviewUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqCutUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolTipManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button verticalGateButton;
        private System.Windows.Forms.CheckBox mergeInvCheckBox;
        private System.Windows.Forms.NumericUpDown inlineInvPreviewUpDown;
        private System.Windows.Forms.CheckBox inlineInvPreviewCheckBox;
        private System.Windows.Forms.NumericUpDown trendFreqCutUpDown;
        private System.Windows.Forms.CheckBox trendFreqCutCheckBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private Slb.Ocean.Petrel.UI.DropTarget rhoDrop;
        private Slb.Ocean.Petrel.UI.DropTarget vsDrop;
        private Slb.Ocean.Petrel.UI.DropTarget vpDrop;
        private System.Windows.Forms.Label rhoTrendText;
        private System.Windows.Forms.Label vsTrendText;
        private System.Windows.Forms.Label vpTrendText;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox residualCubeTextBox;
        private System.Windows.Forms.TextBox rhoCubeTextBox;
        private System.Windows.Forms.TextBox vsCubeTextBox;
        private System.Windows.Forms.TextBox vpCubeTextBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown correlationRangeUpDown;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown vsRhoUpDown;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown vpRhoUpDown;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown vpVsUpDown;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown rhoUpDown;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown vsUpDown;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown vpUpDown;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown signalToNoiseUpDown;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown angleUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private Slb.Ocean.Petrel.UI.DropTarget inputCubeDrop;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.Label label18;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.Button addButton;
        private Slb.Ocean.Petrel.UI.DropTarget waveletDrop;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelResOut;
        private System.Windows.Forms.Label labelRhoOut;
        private System.Windows.Forms.Label labelVsOut;
        private System.Windows.Forms.Label labelVpOut;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Button okButton;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox inputCubePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox waveletPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox rhoPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox vsPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox vpPresentationBox;
        private System.Windows.Forms.Label labelSeisStd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelSuggStd;
        private System.Windows.Forms.Label label7;
        private Slb.Ocean.Petrel.UI.Controls.ToolTipHotspot toolTipHotspot1;
        private Slb.Ocean.Petrel.UI.Controls.ToolTipManager toolTipManager1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Wavelett;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cube;
        private System.Windows.Forms.DataGridViewTextBoxColumn Angle;
        private System.Windows.Forms.DataGridViewTextBoxColumn SNR;
        private System.Windows.Forms.Label labelVPVSOut;
        private System.Windows.Forms.TextBox VPVSCubetextBox;
        private System.Windows.Forms.Label labelIPOut;
        private System.Windows.Forms.TextBox IPCubetextBox;
        private System.Windows.Forms.CheckBox ComputeIP_VPVS_CheckBox;
    }
}
