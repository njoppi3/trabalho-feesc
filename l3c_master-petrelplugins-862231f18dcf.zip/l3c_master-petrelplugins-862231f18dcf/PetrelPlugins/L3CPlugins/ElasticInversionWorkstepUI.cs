﻿using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel;
using System.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace UFSC_Plugins {
    partial class ElasticInversionWorkstepUI : UserControl {
        private ElasticInversionWorkstep workstep;
        private ElasticInversionWorkstep.Arguments args;
        private WorkflowContext context;

        Droid inputCubeDroid, vpCubeDroid, vsCubeDroid, rhoCubeDroid, waveletDroid;
        List<InputStruct> inputList;

        VerticalGate vertGate;

        string type;

        /**
         * Constructor
         */
        public ElasticInversionWorkstepUI(ElasticInversionWorkstep workstep, ElasticInversionWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            inputList = new List<InputStruct>();

            vertGate = new VerticalGate();

            type = "ElasticInv";

            if (context!=null)
                try {
                    // when workstep is reopen in workflow, this fill the interface with the args
                    fillInterface(args.structure);
                } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Open Vertical Gate
         */
        private void verticalGateButton_Click(object sender, EventArgs e) {
            vertGate.Show(this);
        }

        /**
         * Get Wavelet from Petrel
         */
        private void waveletDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropWavelet(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                waveletDroid = droidObj;
                waveletPresentationBox.Text = refVar.Name;
            } else {
                Wavelet wvlt = Functions.getWavelet(droidObj);
                if (wvlt != null) {
                    waveletDroid = droidObj;
                    waveletPresentationBox.Text = wvlt.Name;
                    wvlt.Deleted += inputWavelet_Deleted;
                }
            }
        }

        private void inputWavelet_Deleted(object sender, EventArgs e)
        {
            Wavelet w = (sender as Wavelet);
            if (w.Droid.Equals(waveletDroid))
            {
                waveletDroid = null;
                waveletPresentationBox.Text = "";
            }
            int idx = 0;
            List<InputStruct> inptmp = inputList;
            foreach (var inp in inputList)
            {
                if (inp.waveletDroid.Equals(w.Droid))
                {
                    dataGridView1.Rows.RemoveAt(idx);
                    inptmp.RemoveAll(x => x.waveletDroid.Equals(inp.waveletDroid));
                    PetrelLogger.WarnBox(w.Name + " was deleted and removed from Elastic Inversion input list.");
                }
                idx++;
            }
            inputList = inptmp;
        }
        /**
         * Get Cube from Petrel
         */
        private void inputCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                inputCubeDroid = droidObj;
                inputCubePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    inputCubeDroid = droidObj;
                    inputCubePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += inputSeismicCube_Deleted;
                }
                Cursor.Current = Cursors.WaitCursor;
                decimal mean_angle = Functions.getStackAngle(cubeTemp.Name);
                angleUpDown.Value = (mean_angle >= 0 && mean_angle <= 180) ? mean_angle : angleUpDown.Value;
                double seisstd = Functions.computeStd(cubeTemp);
                Cursor.Current = Cursors.Default;
                labelSeisStd.Text = seisstd.ToString("0.#####");
                labelSuggStd.Text = (seisstd/2.645).ToString("0.#####");  // SNR = 7, thus diving std by sqrt(7)
            }
            
        }

        private void inputSeismicCube_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s != null)
            {
                if (s.Droid.Equals(inputCubeDroid))
                {
                    inputCubeDroid = null;
                    inputCubePresentationBox.Text = "";
                }
                int idx = 0;
                List<InputStruct> inptmp = inputList;
                foreach (var inp in inputList)
                {
                    if (inp.cubeDroid.Equals(s.Droid))
                    {
                        dataGridView1.Rows.RemoveAt(idx);
                        inptmp.RemoveAll(x => x.cubeDroid.Equals(inp.cubeDroid));
                        PetrelLogger.WarnBox(s.Name + " was deleted and removed from Elastic Inversion input list.");
                    }
                    idx++;
                }
                inputList = inptmp;
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void vpDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                vpCubeDroid = droidObj;
                vpPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    vpCubeDroid = droidObj;
                    vpPresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += vpTrend_Deleted;
                }
            }
        }

        private void vpTrend_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s.Droid.Equals(vpCubeDroid))
            {
                vpCubeDroid = null;
                vpPresentationBox.Text = "";
                PetrelLogger.WarnBox(s.Name + " was deleted and removed from Elastic Inversion trends list.");
            }
        }
        /**
         * Get Cube from Petrel
         */
        private void vsDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                vsCubeDroid = droidObj;
                vsPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    vsCubeDroid = droidObj;
                    vsPresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += vsTrend_Deleted;
                }
            }
        }

        private void vsTrend_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s.Droid.Equals(vsCubeDroid))
            {
                vsCubeDroid = null;
                vsPresentationBox.Text = "";
                PetrelLogger.WarnBox(s.Name + " was deleted and removed from Elastic Inversion trends list.");
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void rhoDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                rhoCubeDroid = droidObj;
                rhoPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    rhoCubeDroid = droidObj;
                    rhoPresentationBox.Text = cubeTemp.Name;
                }
            }
        }

        private void rhoTrend_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s.Droid.Equals(rhoCubeDroid))
            {
                rhoCubeDroid = null;
                rhoPresentationBox.Text = "";
                PetrelLogger.WarnBox(s.Name + " was deleted and removed from Elastic Inversion trends list.");
            }
        }

        /**
         * Get the Wavelet name
         */
        private string getWaveletName(Droid waveletDroid) {
            String waveletName;
            ReferenceVariable refVar = Functions.getReferenceVariable(waveletDroid);
            if (refVar != null) {
                waveletName = refVar.Name;
            } else {
                Wavelet wvlt = Functions.getWavelet(waveletDroid);
                if (wvlt != null) {
                    waveletName = wvlt.Name;
                    waveletPresentationBox.Text = wvlt.Name;
                } else {
                    throw new Exception("wavelet null");
                }
            }
            return waveletName;
        }

        /**
         * Get the Cube name
         */
        private string getCubeName(Droid cubeDroid) {
            string cubeName;
            ReferenceVariable refVar = Functions.getReferenceVariable(cubeDroid);
            if (refVar != null) {
                cubeName = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(cubeDroid);
                if (cubeTemp != null) {
                    cubeName = cubeTemp.Name;
                } else {
                    throw new Exception("cube null");
                }
            }
            return cubeName;
        }

        /**
         * Add data to the datagridView1
         */
        private void addButton_Click(object sender, EventArgs e) {
            InputStruct input;
            try {
                input = new InputStruct(this);
            } catch (Exception except) {
                PetrelLogger.InfoBox(except.Message);
                return;
            }

            string waveletName = "";
            string cubeName = "";

            try {
                waveletName = getWaveletName(input.waveletDroid);
                cubeName = getCubeName(input.cubeDroid);
            } catch (Exception excpt) {
                PetrelLogger.InfoBox(excpt.ToString());
                return;
            }

            dataGridView1.Rows.Add(waveletName, cubeName, input.angle, input.snr);
            inputList.Add(input);

            waveletPresentationBox.Text = "";
            waveletDroid = null;
            inputCubePresentationBox.Text = "";
            inputCubeDroid = null;
            labelSeisStd.Text = "";
            labelSuggStd.Text = "";

        }

        /**
         * Remove data from datagridView1
         */
        private void removeButton_Click(object sender, EventArgs e) {
            try {
                int selIdx = dataGridView1.CurrentRow.Index;
                if (selIdx > -1) {
                    dataGridView1.Rows.RemoveAt(selIdx);
                    inputList.RemoveAt(selIdx);
                    dataGridView1.Refresh();
                }
            } catch (Exception except) {
                PetrelLogger.InfoBox(except.Message);
                return;
            }
        }

        /**
         * Input Struct
         */
        public struct InputStruct {
            public Droid waveletDroid;
            public Droid cubeDroid;
            public decimal angle, snr;

            public InputStruct(ElasticInversionWorkstepUI workstepUI) {
                waveletDroid = workstepUI.waveletDroid;
                cubeDroid = workstepUI.inputCubeDroid;
                angle = workstepUI.angleUpDown.Value;
                snr = workstepUI.signalToNoiseUpDown.Value;
            }
        }

        /**
         * Elastic Struct 
         */
        public struct ElasticInversionStruct {
            //inputs
            public List<string[]> inputList;
            //trends
            public string vpCubeDroid, vsCubeDroid, rhoCubeDroid;
            //parameters  --UD = UpDown -- para endicar que é um numericUpDown
            public decimal vpUD, vsUD, rhoUD, vp_vsUD, vp_rhoUD, vs_rho, correlationRange;
            //options  --CB = CheckBox --
            public bool trendFrecCB;
            public decimal trendFrecUD;
            public bool mergeInvCB, inlineInvCB;
            public decimal inlineInvUD;
            //output
            public string vpCubeOutput, vsCubeOutput, rhoCubeOutput, residualCubeOutput;
            public bool computeIP_VPVS;
            public string iaCubeOutput, vpvsCubeOutput;
            //vertGate
            public string topDroid, bottomDroid;
            public double topOffset, bottomOffset;

            public ElasticInversionStruct(ElasticInversionWorkstepUI workstepUI) {
                try {
                    //inputs
                    inputList = new List<String[]>();
                    for (int i = 0; i < workstepUI.inputList.Count; i++) {
                        string[] str = new string[4];
                        //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                        str[0] = workstepUI.inputList[i].waveletDroid.ToString();
                        str[1] = workstepUI.inputList[i].cubeDroid.ToString();
                        str[2] = workstepUI.inputList[i].angle.ToString();
                        str[3] = workstepUI.inputList[i].snr.ToString();
                        inputList.Add(str);
                    }
                    //trends
                    if (workstepUI.vpCubeDroid != null)
                        vpCubeDroid = workstepUI.vpCubeDroid.ToString();
                    else
                        vpCubeDroid = null;
                    if (workstepUI.vsCubeDroid != null)
                        vsCubeDroid = workstepUI.vsCubeDroid.ToString();
                    else
                        vsCubeDroid = null;
                    if (workstepUI.rhoCubeDroid != null)
                        rhoCubeDroid = workstepUI.rhoCubeDroid.ToString();
                    else
                        rhoCubeDroid = null;
                    //parameters
                    vpUD = workstepUI.vpUpDown.Value;
                    vsUD = workstepUI.vsUpDown.Value;
                    rhoUD = workstepUI.rhoUpDown.Value;
                    vp_vsUD = workstepUI.vpVsUpDown.Value;
                    vp_rhoUD = workstepUI.vpRhoUpDown.Value;
                    vs_rho = workstepUI.vsRhoUpDown.Value;
                    correlationRange = workstepUI.correlationRangeUpDown.Value;
                    //options
                    trendFrecCB = workstepUI.trendFreqCutCheckBox.Checked;
                    trendFrecUD = workstepUI.trendFreqCutUpDown.Value;
                    mergeInvCB = workstepUI.mergeInvCheckBox.Checked;
                    inlineInvCB = workstepUI.inlineInvPreviewCheckBox.Checked;
                    inlineInvUD = workstepUI.inlineInvPreviewUpDown.Value;
                    //output
                    vpCubeOutput = workstepUI.vpCubeTextBox.Text;
                    vsCubeOutput = workstepUI.vsCubeTextBox.Text;
                    rhoCubeOutput = workstepUI.rhoCubeTextBox.Text;
                    residualCubeOutput = workstepUI.residualCubeTextBox.Text;
                    computeIP_VPVS = workstepUI.ComputeIP_VPVS_CheckBox.Checked;
                    iaCubeOutput = workstepUI.IPCubetextBox.Text;
                    vpvsCubeOutput = workstepUI.VPVSCubetextBox.Text;
                    //vertGate
                    topDroid = workstepUI.vertGate.getTopDroid();
                    bottomDroid = workstepUI.vertGate.getBottomDroid();
                    topOffset = workstepUI.vertGate.getTopOffset();
                    bottomOffset = workstepUI.vertGate.getBottomOffset();
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            ElasticInversionStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<ElasticInversionStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: Não é um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            // fill the interface atributs with result
            try {
                fillInterface(result);
            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        private void fillInterface(ElasticInversionStruct structure) {
            try {
                //inputs
                inputList = new List<InputStruct>();
                for (int i = 0; i < structure.inputList.Count; i++) {
                    //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                    InputStruct inpt = new InputStruct();
                    if (structure.inputList[i][0] != null) {
                        inpt.waveletDroid = new Droid(structure.inputList[i][0]);
                        Functions.getWavelet(inpt.waveletDroid).Deleted += inputWavelet_Deleted;
                    } else {
                        inpt.waveletDroid = null;
                    }
                    if (structure.inputList[i][1] != null) {
                        inpt.cubeDroid = new Droid(structure.inputList[i][1]);
                        Functions.getCube(inpt.cubeDroid).Deleted += inputSeismicCube_Deleted;
                    } else {
                        inpt.cubeDroid = null;
                    }
                    inpt.angle = decimal.Parse(structure.inputList[i][2]);
                    inpt.snr = decimal.Parse(structure.inputList[i][3]);
                    inputList.Add(inpt);
                }
                dataGridView1.Rows.Clear();
                foreach (var item in inputList) {

                    string waveletName = "";
                    string cubeName = "";

                    try {
                        waveletName = getWaveletName(item.waveletDroid);
                        cubeName = getCubeName(item.cubeDroid);
                    } catch (Exception excpt) {
                        PetrelLogger.InfoBox(excpt.ToString());
                        return;
                    }

                    dataGridView1.Rows.Add(waveletName, cubeName, item.angle, item.snr);
                }
                //trends
                if (structure.vpCubeDroid != null) {
                    vpCubeDroid = new Droid(structure.vpCubeDroid);
                    SeismicCube cube = Functions.getCube(vpCubeDroid);
                    if (cube != null) {
                        vpPresentationBox.Text = cube.Name;
                        cube.Deleted += vpTrend_Deleted;
                    } else {
                        vpPresentationBox.Text = Functions.getReferenceVariable(vpCubeDroid).Name;
                    }
                }
                if (structure.vsCubeDroid != null) {
                    vsCubeDroid = new Droid(structure.vsCubeDroid);
                    SeismicCube cube = Functions.getCube(vsCubeDroid);
                    if (cube != null) {
                        vsPresentationBox.Text = cube.Name;
                        cube.Deleted += vsTrend_Deleted;
                    } else {
                        vsPresentationBox.Text = Functions.getReferenceVariable(vsCubeDroid).Name;
                    }
                }
                if (structure.vpCubeDroid != null) {
                    rhoCubeDroid = new Droid(structure.rhoCubeDroid);
                    SeismicCube cube = Functions.getCube(rhoCubeDroid);
                    if (cube != null) {
                        rhoPresentationBox.Text = cube.Name;
                        cube.Deleted += rhoTrend_Deleted;
                    } else {
                        rhoPresentationBox.Text = Functions.getReferenceVariable(rhoCubeDroid).Name;
                    }
                }
                //parameters
                vpUpDown.Value = structure.vpUD;
                vsUpDown.Value = structure.vsUD;
                rhoUpDown.Value = structure.rhoUD;
                vpVsUpDown.Value = structure.vp_vsUD;
                vpRhoUpDown.Value = structure.vp_rhoUD;
                vsRhoUpDown.Value = structure.vs_rho;
                correlationRangeUpDown.Value = structure.correlationRange;
                //options
                trendFreqCutCheckBox.Checked = structure.trendFrecCB;
                trendFreqCutUpDown.Value = structure.trendFrecUD;
                mergeInvCheckBox.Checked = structure.mergeInvCB;
                inlineInvPreviewCheckBox.Checked = structure.inlineInvCB;
                inlineInvPreviewUpDown.Value = structure.inlineInvUD;
                //output
                vpCubeTextBox.Text = structure.vpCubeOutput;
                vsCubeTextBox.Text = structure.vsCubeOutput;
                rhoCubeTextBox.Text = structure.rhoCubeOutput;
                residualCubeTextBox.Text = structure.residualCubeOutput;
                ComputeIP_VPVS_CheckBox.Checked = structure.computeIP_VPVS;
                IPCubetextBox.Text = structure.iaCubeOutput;
                VPVSCubetextBox.Text = structure.vpvsCubeOutput;
                //vertGate
                vertGate.setTopDroid(structure.topDroid);
                vertGate.setBottomDroid(structure.bottomDroid);
                vertGate.setTopOffset(structure.topOffset);
                vertGate.setBottomOffset(structure.bottomOffset);
            } catch (Exception ex) {
                throw ex;
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // cria a estrutura
            ElasticInversionStruct myStruct = new ElasticInversionStruct(this);
            // call saveCustomObject function
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required input is correct
         */
        public bool checkInputs() {
            if (!inputList.Any()) {
                PetrelLogger.ErrorBox("Please select a cube");
                return false;
            }
            if (vpCubeDroid == null) {
                PetrelLogger.ErrorBox("Please select a VP Trend cube");
                return false;
            }
            if (vsCubeDroid == null) {
                PetrelLogger.ErrorBox("Please select a VS Trend cube");
                return false;
            }
            if (rhoCubeDroid == null) {
                PetrelLogger.ErrorBox("Please select a RHOB Trend cube");
                return false;
            }
            return true;
        }

        /**
         * Checks if any required output is correct
         */
        public bool checkOutputs() {
            if (string.IsNullOrWhiteSpace(vpCubeTextBox.Text)) {
                PetrelLogger.ErrorBox(labelVpOut.Text + " is empty");
                return false;
            }

            if (string.IsNullOrWhiteSpace(vsCubeTextBox.Text)) {
                PetrelLogger.ErrorBox(labelVsOut.Text + " is empty");
                return false;
            }

            if (string.IsNullOrWhiteSpace(rhoCubeTextBox.Text)) {
                PetrelLogger.ErrorBox(labelRhoOut.Text + " is empty");
                return false;
            }

            if (string.IsNullOrWhiteSpace(residualCubeTextBox.Text)) {
                PetrelLogger.ErrorBox(labelResOut.Text + " is empty");
                return false;
            }

            if (ComputeIP_VPVS_CheckBox.Checked)
            {
                if (string.IsNullOrWhiteSpace(IPCubetextBox.Text))
                {
                    PetrelLogger.ErrorBox(labelIPOut.Text + " is empty");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(VPVSCubetextBox.Text))
                {
                    PetrelLogger.ErrorBox(labelVPVSOut.Text + " is empty");
                    return false;
                }
            }
            return true;
        }


        /**
         * Checks if any cube is null
         */
        private bool checkCubes() {
            if (inputList.Count == 0) {
                PetrelLogger.ErrorBox("Please select a Seismic Cube");
                return false;
            }

            if (vpCubeDroid == null || vsCubeDroid == null || rhoCubeDroid == null) {
                PetrelLogger.ErrorBox("Please select trends for vp, vs and rho");
                return false;
            }
            return true;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.RowCount < 1)
                return;
            decimal angle = -1;
            decimal snr = -1;
            int index = dataGridView1.CurrentRow.Index;
            if (!decimal.TryParse(dataGridView1.CurrentRow.Cells[2].Value.ToString(), out angle))
            {
                dataGridView1.CurrentRow.Cells[2].Value = inputList[index].angle.ToString();
                return;
            }
            if (!decimal.TryParse(dataGridView1.CurrentRow.Cells[3].Value.ToString(), out snr))
            {
                dataGridView1.CurrentRow.Cells[3].Value = inputList[index].snr.ToString();
                return;
            }

            var i = inputList[index];
            i.angle = angle;
            i.snr = snr;
            inputList[index] = i;
        }

        private void ComputeIA_VPVS_CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (ComputeIP_VPVS_CheckBox.Checked)
            {
                labelIPOut.Enabled = true;
                labelVPVSOut.Enabled = true;
                IPCubetextBox.Enabled = true;
                VPVSCubetextBox.Enabled = true;
            }
            else
            {
                labelIPOut.Enabled = false;
                labelVPVSOut.Enabled = false;
                IPCubetextBox.Enabled = false;
                VPVSCubetextBox.Enabled = false;
            }
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {
            if (!checkInputs() || !checkOutputs() || !checkCubes())
                return false;
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)this.TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ElasticInversionStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ElasticInversionStruct(this);
                    this.Enabled = false;
                    fillInterface(args.structure);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                    this.Enabled = true;
                    fillInterface(args.structure);
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ElasticInversionStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ElasticInversionStruct(this);
                    this.Enabled = false;
                    workstep.GetExecutor(args, null).ExecuteSimple();
                    this.Enabled = true;
                }
                ((Form) TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }
    }
}
