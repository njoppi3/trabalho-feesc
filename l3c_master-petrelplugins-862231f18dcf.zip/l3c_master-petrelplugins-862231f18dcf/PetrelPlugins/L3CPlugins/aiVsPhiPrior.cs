﻿using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel;

namespace UFSC_Plugins {
    public partial class aiVsPhiPrior : Form {

        WellLogSelect backup;

        /**
         * Constructor
         */
        public aiVsPhiPrior() {
            InitializeComponent();
            wellLogSelect1.enableLogDrops(true, 2);
            wellLogSelect1.setXText("Porosity Log");
            wellLogSelect1.setYText("Impedance Log");
            wellLogSelect1.setTimeText("Facies log");
            wellLogSelect1.needsTWT = false;
            wellLogSelect1.disableZlog();
            FormClosing += AiVsPhiPrior_FormClosing;
        }

        public aiVsPhiPrior(string xtext, string ytext, string ztext, bool useFac)
        {
            InitializeComponent();
            wellLogSelect1.enableLogDrops(true, 3);
            wellLogSelect1.setXText(xtext);
            wellLogSelect1.setYText(ytext);
            wellLogSelect1.setZText(ztext);
            if (useFac)
            {
                wellLogSelect1.setTimeText("Facies log");
                wellLogSelect1.needsTWT = false;
            }
            else
                wellLogSelect1.disableTimeDrop();
            FormClosing += AiVsPhiPrior_FormClosing;
        }

        /**
         * Call the CancelButton_Click(), prevent user close
         */
        private void AiVsPhiPrior_FormClosing(object sender, FormClosingEventArgs e) {
            if (e.CloseReason == CloseReason.UserClosing)
                e.Cancel = true;
            CancelButton_Click(sender, e);
        }

        /**
         * Just hide the form
         */
        private void OkbuttonClick(object sender, EventArgs e) {
            Hide();
        }

        /**
         * Just hide the form
         */
        public new void Close() {
            Hide();
        }

        /**
         * Turn the form visible
         */
        public new void Show(IWin32Window owner) {
            if (!this.Visible) {
                backup = wellLogSelect1.Clone();
                base.Show(owner);
            }
        }

        /**
         * 
         */
        private void CancelButton_Click(object sender, EventArgs e) {
            try
            {
                wellLogSelect1.setAll(backup.Clone());
                Hide();
                Refresh();
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Erro: " + except.ToString());
                return;
            }
        }


    }
}
