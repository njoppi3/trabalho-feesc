using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel;
using System.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject.Well;

namespace UFSC_Plugins {
    partial class ImpedancePorosityInvWorkstepUI : UserControl {
        private ImpedancePorosityInvWorkstep workstep;
        private ImpedancePorosityInvWorkstep.Arguments args;
        private WorkflowContext context;


        Droid waveletDroid;
        Droid seismicCubeDroid;
        Droid impedanceCubeDroid;
        Droid porosityCubeDroid;

        VerticalGate vertGate;

        private crossplot cp;
        private aiVsPhiPrior aiphipor;
        double[][] data;
        double[] mu_x;
        double[] mu_y;

        string type;

        /**
         * Constructor
         */
        public ImpedancePorosityInvWorkstepUI(ImpedancePorosityInvWorkstep workstep, ImpedancePorosityInvWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();
            aiphipor = new aiVsPhiPrior();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            vertGate = new VerticalGate();

            type = "ImpedancePorosityInv";

            cp = new crossplot();
            data = null;
            mu_x = null;
            mu_y = null;

            try {
                // when workstep is reopen in workflow, this fill the interface with the args
                fillInterface(args.structure);
            } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Opens the crossplot with logX, logY and facies datas
         */
        private void openCPbutton_Click(object sender, EventArgs e) {
            var wellLogSelect1 = aiphipor.wellLogSelect1;

            if (wellLogSelect1.m_xLog == null || wellLogSelect1.m_yLog == null) {
                PetrelLogger.ErrorBox("Plese select at least one log for X and Y.");
                return;
            }

            string logXDroid = null;
            if (wellLogSelect1.m_xLog != null)
                logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
            string logYDroid = null;
            if (wellLogSelect1.m_yLog != null)
                logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
            string faciesDroid = null;
            if (wellLogSelect1.m_timeLog != null)
                faciesDroid = wellLogSelect1.m_timeLog.Droid.ToString();
            if (wellLogSelect1.m_faciesLog != null)
                faciesDroid = wellLogSelect1.m_faciesLog.Droid.ToString();

            List<string> wellDroid = wellLogSelect1.getWellDroids();
            List<WellLogSample> aiList;
            List<WellLogSample> phiList;
            List<WellLogSample> faciesList;

            Functions.getAllLists(wellDroid, logXDroid, logYDroid, faciesDroid, out phiList, out aiList, out faciesList);
            WellLogVersion globalxLog = Functions.getWellLogVersion(new Droid(logXDroid));
            WellLogVersion globalyLog = Functions.getWellLogVersion(new Droid(logYDroid));

            try {
                CPDataWorkstep.setCPData(phiList, aiList, faciesList, cp, true);
                cp.setXText(globalxLog.Name + " (" + globalxLog.Template.PetrelMeasurement.Units.First().DisplaySymbol + ")");
                cp.setYText(globalyLog.Name + " log(" + globalyLog.Template.PetrelMeasurement.Units.First().DisplaySymbol + ")");
                cp.show();
                data = null;
                mu_x = null;
                mu_y = null;
                cp.getPriors(ref data, ref mu_x, ref mu_y);
            } catch (Exception except) {
                PetrelLogger.InfoBox("Error:\n\n" + except.ToString());
                return;
            }
        }

        /**
         * Open Vertical Gate
         */
        private void verticalGateButton_Click(object sender, EventArgs e) {
            vertGate.Show(this);
        }

        /**
         * Get a Wavelet from Petrel
         */
        private void waveletDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropWavelet(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                waveletDroid = droidObj;
                waveletPresentationBox.Text = refVar.Name;
            } else {
                Wavelet wvlt = Functions.getWavelet(droidObj);
                if (wvlt != null) {
                    waveletDroid = droidObj;
                    waveletPresentationBox.Text = wvlt.Name;
                    wvlt.Deleted += inputWavelet_Deleted;
                }
            }
        }

        private void inputWavelet_Deleted(object sender, EventArgs e)
        {
            Wavelet w = sender as Wavelet;
            if (w != null && w.Droid.Equals(waveletDroid))
            {
                waveletDroid = null;
                waveletPresentationBox.Text = "";
                PetrelLogger.InfoBox(w.Name + " was deleted and removed from Impedance Porosity Inversion inputs.");
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void cubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                seismicCubeDroid = droidObj;
                cubePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    seismicCubeDroid = droidObj;
                    cubePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += inputCube_Deleted;
                }
            }
        }

        private void inputCube_Deleted(object sender, EventArgs e)
        {
            SeismicCube s = sender as SeismicCube;
            if (s != null && s.Droid.Equals(seismicCubeDroid))
            {
                seismicCubeDroid = null;
                cubePresentationBox.Text = "";
                PetrelLogger.InfoBox(s.Name + " was deleted and removed from Impedance Porosity Inversion inputs.");
                return;
            }

            if (s != null && s.Droid.Equals(impedanceCubeDroid))
            {
                impedanceCubeDroid = null;
                impedancePresentationBox.Text = "";
                PetrelLogger.InfoBox(s.Name + " was deleted and removed from Impedance Porosity Inversion inputs.");
                return;
            }

            if (s != null && s.Droid.Equals(porosityCubeDroid))
            {
                porosityCubeDroid = null;
                porosityPresentationBox.Text = "";
                PetrelLogger.InfoBox(s.Name + " was deleted and removed from Impedance Porosity Inversion inputs.");
                return;
            }
        }

        /**
         * get Cube from Petrel
         */
        private void impedanceCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                impedanceCubeDroid = droidObj;
                impedancePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    impedanceCubeDroid = droidObj;
                    impedancePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += inputCube_Deleted;
                }
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void porosityCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                porosityCubeDroid = droidObj;
                porosityPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    porosityCubeDroid = droidObj;
                    porosityPresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += inputCube_Deleted;
                }
            }
        }

        /**
         * Open AI VS PHI window
         */
        private void aiVsPhiButton_Click(object sender, EventArgs e) {
            aiphipor.Show(this);
        }

        /**
         * ImpedancePorosityInv Struct 
         */
        public struct ImpedancePorosityInvStruct {
            // input
            public string waveletDroid, seismicCubeDroid, impedanceCubeDroid, porosityCubeDroid;
            // parameters
            public decimal impedanceUncert, porosityUncert, signalToNoise, correlation;
            // options --- CB = checkBox
            public bool optionsCB, trendFreqCB;
            public decimal trendFreq;
            public bool inlineInvPrevCB;
            public decimal inlineInvPrev;
            public bool mergeInvTrendCB;
            // output  --- TB = textBox, LB = Label
            public string impedanceTB, porosityTB, residualTB, impedanceLB, porosityLB;
            //vertGate
            public string topDroid, bottomDroid;
            public double topOffset, bottomOffset;

            // wellLogSelect - crossplot
            public string logXDroid, logYDroid, logfacDroid;
            public List<string> wellDroids;
            public crossplot cp;
            public double[] muX, muY;
            public double[][] data;

            public ImpedancePorosityInvStruct(ImpedancePorosityInvWorkstepUI workstepUI) {
                try {
                    // input
                    waveletDroid = null;
                    if (workstepUI.waveletDroid != null)
                        waveletDroid = workstepUI.waveletDroid.ToString();
                    seismicCubeDroid = null;
                    if (workstepUI.seismicCubeDroid != null)
                        seismicCubeDroid = workstepUI.seismicCubeDroid.ToString();
                    impedanceCubeDroid = null;
                    if (workstepUI.impedanceCubeDroid != null)
                        impedanceCubeDroid = workstepUI.impedanceCubeDroid.ToString();
                    porosityCubeDroid = null;
                    if (workstepUI.porosityCubeDroid != null)
                        porosityCubeDroid = workstepUI.porosityCubeDroid.ToString();
                    // parameters
                    impedanceUncert = workstepUI.impedanceUncertUpDown.Value;
                    porosityUncert = workstepUI.porosityUncertUpDown.Value;
                    signalToNoise = workstepUI.signalToNoiseUpDown.Value;
                    correlation = workstepUI.correlationRangeUpDown.Value;
                    // options --- CB = checkBox
                    optionsCB = workstepUI.optionsCheckBox.Checked;
                    trendFreqCB = workstepUI.trendFreqCutCheckBox.Checked;
                    trendFreq = workstepUI.trendFreqcutUpDown.Value;
                    inlineInvPrevCB = workstepUI.inlineInvPrevCheckBox.Checked;
                    inlineInvPrev = workstepUI.inlineInvPrevUpDown.Value;
                    mergeInvTrendCB = workstepUI.mergeInvTrendCheckBox.Checked;
                    // output  --- TB = textBox, LB = Label
                    impedanceTB = workstepUI.impedanceTextBox.Text;
                    porosityTB = workstepUI.porosityTextBox.Text;
                    residualTB = workstepUI.residualTextBox.Text;
                    impedanceLB = workstepUI.impedanceValueLabel.Text;
                    porosityLB = workstepUI.porosityValueLabel.Text;

                    //vertGate
                    topDroid = workstepUI.vertGate.getTopDroid();
                    bottomDroid = workstepUI.vertGate.getBottomDroid();
                    topOffset = workstepUI.vertGate.getTopOffset();
                    bottomOffset = workstepUI.vertGate.getBottomOffset();

                    // wellLogSelect - crossplot
                    logXDroid = null;
                    logYDroid = null;
                    logfacDroid = null;
                    WellLogSelect wellLogSelect1 = workstepUI.aiphipor.wellLogSelect1;
                    if (wellLogSelect1.m_xLog != null)
                        logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
                    if (wellLogSelect1.m_yLog != null)
                        logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
                    if (wellLogSelect1.m_timeLog != null)
                        logfacDroid = wellLogSelect1.m_timeLog.Droid.ToString();
                    wellDroids = wellLogSelect1.getWellDroids();
                    cp = workstepUI.cp;
                    data = null;
                    muX = null;
                    muY = null;
                    cp.getPriors(ref data, ref muX, ref muY);
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            ImpedancePorosityInvStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != "ImpedancePorosityInv") {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<ImpedancePorosityInvStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: N�o � um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            // fill the interface atributs with result
            fillInterface(result);
        }


        /**
         * Fills the interface with the parameter "structure"
         */
        private void fillInterface(ImpedancePorosityInvStruct structure) {
            try {
                //inputs
                if (structure.waveletDroid != null) {
                    waveletDroid = new Droid(structure.waveletDroid);
                    Wavelet wavelet = Functions.getWavelet(waveletDroid);
                    if (wavelet != null) {
                        waveletPresentationBox.Text = wavelet.Name;
                        wavelet.Deleted += inputWavelet_Deleted;
                    } else {
                        waveletPresentationBox.Text = Functions.getReferenceVariable(waveletDroid).Name;
                    }
                }
                if (structure.seismicCubeDroid != null) {
                    seismicCubeDroid = new Droid(structure.seismicCubeDroid);
                    SeismicCube cube = Functions.getCube(seismicCubeDroid);
                    if (cube != null) {
                        cubePresentationBox.Text = cube.Name;
                        cube.Deleted += inputCube_Deleted;
                    } else {
                        cubePresentationBox.Text = Functions.getReferenceVariable(seismicCubeDroid).Name;
                    }
                }
                if (structure.impedanceCubeDroid != null) {
                    impedanceCubeDroid = new Droid(structure.impedanceCubeDroid);
                    SeismicCube cube = Functions.getCube(impedanceCubeDroid);
                    if (cube != null) {
                        impedancePresentationBox.Text = cube.Name;
                        cube.Deleted += inputCube_Deleted;
                    } else {
                        impedancePresentationBox.Text = Functions.getReferenceVariable(impedanceCubeDroid).Name;
                    }
                }
                if (structure.porosityCubeDroid != null) {
                    porosityCubeDroid = new Droid(structure.porosityCubeDroid);
                    SeismicCube cube = Functions.getCube(porosityCubeDroid);
                    if (cube != null) {
                        porosityPresentationBox.Text = cube.Name;
                        cube.Deleted += inputCube_Deleted;
                    } else {
                        porosityPresentationBox.Text = Functions.getReferenceVariable(porosityCubeDroid).Name;
                    }
                }
                // parameters
                impedanceUncertUpDown.Value = structure.impedanceUncert;
                porosityUncertUpDown.Value = structure.porosityUncert;
                signalToNoiseUpDown.Value = structure.signalToNoise;
                correlationRangeUpDown.Value = structure.correlation;
                // options --- CB = checkBox
                optionsCheckBox.Checked = structure.optionsCB;
                trendFreqCutCheckBox.Checked = structure.trendFreqCB;
                trendFreqcutUpDown.Value = structure.trendFreq;
                inlineInvPrevCheckBox.Checked = structure.inlineInvPrevCB;
                inlineInvPrevUpDown.Value = structure.inlineInvPrev;
                mergeInvTrendCheckBox.Checked = structure.mergeInvTrendCB;
                // output  --- TB = textBox, LB = Label
                impedanceTextBox.Text = structure.impedanceTB;
                porosityTextBox.Text = structure.porosityTB;
                residualTextBox.Text = structure.residualTB;
                impedanceValueLabel.Text = structure.impedanceLB;
                porosityValueLabel.Text = structure.porosityLB;
                //vertGate
                vertGate.setTopDroid(structure.topDroid);
                vertGate.setBottomDroid(structure.bottomDroid);
                vertGate.setTopOffset(structure.topOffset);
                vertGate.setBottomOffset(structure.bottomOffset);

                // wellLogSelect - crossplot
                data = structure.data;
                mu_x = structure.muX;
                mu_y = structure.muY;

                string logXDroid = structure.logXDroid;
                string logYDroid = structure.logYDroid;
                string faciesDroid = structure.logfacDroid;
                List<string> wellDroid = structure.wellDroids;
                List<WellLogSample> aiList;
                List<WellLogSample> phiList;
                List<WellLogSample> faciesList;

                Functions.getAllLists(wellDroid, logXDroid, logYDroid, faciesDroid, out aiList, out phiList, out faciesList);

                aiphipor.wellLogSelect1.clearWellsLogs();
                if (faciesDroid != null)
                    aiphipor.wellLogSelect1.setLogTime(Functions.getWellLogVersion(new Droid(faciesDroid)));
                if (logXDroid != null)
                    aiphipor.wellLogSelect1.setLogX(Functions.getWellLogVersion(new Droid(logXDroid)));
                if (logYDroid != null)
                    aiphipor.wellLogSelect1.setLogY(Functions.getWellLogVersion(new Droid(logYDroid)));
                if (wellDroid != null && wellDroid.Count > 0)
                    aiphipor.wellLogSelect1.addWells(wellDroid);


                if ((data != null) && (mu_x != null) && (mu_y != null)) {
                    CPDataWorkstep.setCPData(aiList, phiList, faciesList, cp, true);
                    if (mu_x.Count() > 0)
                        cp.setPriors(ref data, ref mu_x, ref mu_y);
                }

            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // create the structure of this class
            ImpedancePorosityInvStruct myStruct = new ImpedancePorosityInvStruct(this);
            // call saveCustomObject function with the JSON serialized struct
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {
            // checks if any required parameters are null
            // inputs
            if (waveletDroid == null) {
                PetrelLogger.ErrorBox("Please, insert a wavelet.");
                return false;
            }
            if (seismicCubeDroid == null) {
                PetrelLogger.ErrorBox("Please, insert the input seismic cube.");
                return false;
            }
            if (impedanceCubeDroid == null) {
                PetrelLogger.ErrorBox("Please, insert the impedance cube.");
                return false;
            }
            if (porosityCubeDroid == null) {
                PetrelLogger.ErrorBox("Please, insert the input porosity cube.");
                return false;
            }
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ImpedancePorosityInvStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ImpedancePorosityInvStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ImpedancePorosityInvStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ImpedancePorosityInvStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
                ((Form)TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }
    }
}
