﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class AcousticTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel _cubeseis, _cubetrend;
        public AcousticInversionCLI.Parameters _p;
        public CubeFromPetrel _cuberesidout,_cubeimpedout;
        public int progressPct = 0;
        public String _statusMsg = "";
        public double[] _wavelet;
        internal double _posteriorStd;

        public AcousticTaskSetup(ref CubeFromPetrel seis, ref CubeFromPetrel trend,
            ref AcousticInversionCLI.Parameters pars, ref CubeFromPetrel imped_out, ref CubeFromPetrel resid_out,
            ref double[] wavelet)
        {
            _cubeseis = seis;
            _cubetrend = trend;
            _p = pars;
            _cuberesidout = resid_out;
            _cubeimpedout = imped_out;
            _wavelet = wavelet;
        }

        public int progress()
        {
            return progressPct;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}