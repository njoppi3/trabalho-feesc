﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class BayesTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel _cubeX,_cubeY;
        public double[][] _Covars;
        public List<double[]> _Means;
        public double[] _priorProbs;
        public CubeFromPetrel _cubeMaxProb;
        public CubeFromPetrel[] _probCubes;
        public int progressPct = 0;
        public String _statusMsg = "";
        
        public BayesTaskSetup(ref CubeFromPetrel cubeX, ref CubeFromPetrel cubeY, ref double[][] Covars,
            ref List<double[]> Means , ref CubeFromPetrel cubeMaxProb, ref double[] priorProbs,
            ref CubeFromPetrel[] probCubes)
        {
            _cubeX = cubeX;
            _cubeY = cubeY;
            _Covars = Covars;
            _Means = Means;
            _priorProbs = priorProbs;
            _cubeMaxProb = cubeMaxProb;
            _probCubes = probCubes;
        }

        public int progress()
        {
            return progressPct;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}
