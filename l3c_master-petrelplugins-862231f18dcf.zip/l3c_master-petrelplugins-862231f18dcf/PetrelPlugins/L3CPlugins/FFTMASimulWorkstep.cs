using System;

using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.FFTMASimulWorkstepUI;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject.Well;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the FFTMASimulWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class FFTMASimulWorkstep : Workstep<FFTMASimulWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override FFTMASimulWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "33dc1011-2354-47e6-9192-1bec2be446b9";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�
                Functions Functions = new Functions();
                decimal inlineRange = args.structure.inlineRange;
                decimal crosslineRange = args.structure.crosslineRange;
                decimal zRange = args.structure.zRange;
                decimal stdDev = args.structure.stdDev;
                double rake = args.structure.rake;
                double dip = args.structure.dip;
                double azimuth = args.structure.azimuth;
                SeismicCube meanCube;
                try {
                    meanCube = Functions.getCubeByReferenceVar(new Droid(args.structure.meanCubeDroid));
                } catch (Exception e) {
                    PetrelLogger.ErrorBox(e.ToString());
                    return;
                }
                decimal realizations = args.structure.realizations;
                decimal realizationsSave = args.structure.realizationsSave;
                decimal maxThreshold = args.structure.maxThreshold;

                List<Borehole> wellList = new List<Borehole>();
                if (args.structure.wellDroidList != null)
                    foreach (string wellDroid in args.structure.wellDroidList) {
                        wellList.Add(Functions.getWellByReferenceVar(new Droid(wellDroid)));
                    }
                WellLogVersion welllvt = null;
                if (args.structure.timelog != null && args.structure.timelog != "")
                    welllvt = Functions.getWellLogVersion(new Droid(args.structure.timelog));
                WellLogVersion welllvp = null;
                if (args.structure.propertyLog != null && args.structure.propertyLog != "")
                    welllvp = Functions.getWellLogVersion(new Droid(args.structure.propertyLog));
                bool prevKringCB = args.structure.prevKringCB;
                SeismicCube meanKrigCube = null;
                SeismicCube varianceKrigCube = null;
                CubeFromPetrel meanKrigCubeCPInp = null;
                CubeFromPetrel varKrigCubeCPInp = null;
                if (prevKringCB) {
                    try {
                        meanKrigCube = Functions.getCubeByReferenceVar(new Droid(args.structure.meanKringCubeDroid));
                        meanKrigCubeCPInp = new CubeFromPetrel(meanKrigCube);
                    } catch (Exception e) {
                        PetrelLogger.ErrorBox(e.ToString());
                        return;
                    }
                    try {
                        varianceKrigCube = Functions.getCubeByReferenceVar(new Droid(args.structure.varianceKringCubeDroid));
                        varKrigCubeCPInp = new CubeFromPetrel(varianceKrigCube);
                    } catch (Exception e) {
                        PetrelLogger.ErrorBox(e.ToString());
                        return;
                    }
                }

                // PRINTS PARA TESTAR SE TA REALMENTE PASSANDO OS ARGS
                PetrelLogger.InfoOutputWindow("inlineRange: " + inlineRange.ToString());
                PetrelLogger.InfoOutputWindow("crosslineRange: " + crosslineRange.ToString());
                PetrelLogger.InfoOutputWindow("zRange: " + zRange.ToString());
                PetrelLogger.InfoOutputWindow("stdDev: " + stdDev.ToString());
                PetrelLogger.InfoOutputWindow("rake: " + rake.ToString());
                PetrelLogger.InfoOutputWindow("dip: " + dip.ToString());
                PetrelLogger.InfoOutputWindow("azimuth: " + azimuth.ToString());
                PetrelLogger.InfoOutputWindow("meanCube: " + meanCube.Name);
                PetrelLogger.InfoOutputWindow("realizations: " + realizations.ToString());
                PetrelLogger.InfoOutputWindow("realizationsSave: " + realizationsSave.ToString());
                PetrelLogger.InfoOutputWindow("maxThreshold: " + maxThreshold.ToString());

                for (int i = 0; i < wellList.Count; i++) {
                    PetrelLogger.InfoOutputWindow("Well " + i.ToString() + ": " + wellList[i].Name);
                }
                PetrelLogger.InfoOutputWindow("prevKringCB: " + prevKringCB.ToString());
                if (prevKringCB) {
                    PetrelLogger.InfoOutputWindow("meanKringCubeDroid: " + meanKrigCube.Name);
                    PetrelLogger.InfoOutputWindow("varianceKringCubeDroid: " + varianceKrigCube.Name);
                }

                // write the results
                PetrelLogger.InfoOutputWindow("Started...");
                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot root = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = root.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "FFTMA Simulation Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    args.SimulationResultsCollection = scol;
                    tr.Commit();
                }

                // write output
                List<SeismicCube> simulResults = new List<SeismicCube>();
                List<CubeFromPetrel> cubewsim_results = new List<CubeFromPetrel>();
                for(int i=0; i< realizationsSave; i++)
                {
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        try
                        {
                            tr.Lock(scol);
                            simulResults.Add(scol.CreateSeismicCube(meanCube, meanCube.Template));
                            simulResults[i].Name = meanCube.Name + " " + i.ToString();
                            cubewsim_results.Add(new CubeFromPetrel(simulResults[i], 10));
                            cubewsim_results[i].prepareWriteToPetrel();
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }
                    }

                }

                var cubewmean = new CubeFromPetrel(meanCube);

                CubeFromPetrel condPoints = null;

                if (wellList.Count > 0)
                {
                    condPoints = new CubeFromPetrel(meanCube);
                    condPoints.setNAN();
                }
                foreach(Borehole well in wellList)
                    Functions.setTraceAtWell(condPoints, well, welllvp, welllvt);

                SeismicCube meanKrigOut = null;
                SeismicCube varKrigOut = null;
                CubeFromPetrel meanKrigOutCP = null;
                CubeFromPetrel varKrigOutCP = null;

                if  (condPoints != null)
                {
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        try
                        {
                            tr.Lock(scol);
                            meanKrigOut = scol.CreateSeismicCube(meanCube, meanCube.Template);
                            meanKrigOut.Name = "Kriging Mean (for reusing at the plugin)";
                            meanKrigOutCP = new CubeFromPetrel(meanKrigOut, 10);
                            meanKrigOutCP.prepareWriteToPetrel();
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }
                    }

                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        try
                        {
                            tr.Lock(scol);
                            varKrigOut = scol.CreateSeismicCube(meanCube, meanCube.Template);
                            varKrigOut.Name = "Kriging Variance (for reusing at the plugin)";
                            varKrigOutCP = new CubeFromPetrel(varKrigOut, 10);
                            varKrigOutCP.prepareWriteToPetrel();
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }

                    }
                }

                FFTMATaskSetup task = new FFTMATaskSetup(ref cubewmean, ref cubewsim_results, ref args.structure, meanKrigCubeCPInp,
                    varKrigCubeCPInp,meanKrigOutCP,varKrigOutCP, condPoints);
                
                List<FFTMATaskSetup> tasks = new List<FFTMATaskSetup>(1);
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, Convert.ToInt32(realizations)))
                {
                    try
                    {
                        pbar.SetProgressText("Performing Geostatistical Simulations");
                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doFFTMA, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    }
                    catch (Exception excep)
                    {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");
                PetrelLogger.InfoOutputWindow("Process complete");

            }


            private void doFFTMA(object objJob)
            {
                var task = (FFTMATaskSetup)objJob;
                task._statusMsg = "Reading data from input volumes";

                task._mean.readFromPetrel();

                if (task._p.prevKringCB)
                {
                    task._krigMeanInp.readFromPetrel();
                    task._krigVarInp.readFromPetrel();
                }

                var p = task._p;

                NoiseFilteringCLI nf = new NoiseFilteringCLI(task._mean, task._condPoints, Convert.ToDouble(p.stdDev*p.stdDev), (int) p.inlineRange, 
                    (int) p.crosslineRange, (int) p.zRange, (double) p.dip, (double) p.rake, (double) p.azimuth, (int) p.realizations,
                    (int) p.realizationsSave, (double) p.maxThreshold);

                if (task._p.prevKringCB)
                    nf.set_solver(task._krigMeanInp, task._krigVarInp);
                else
                    nf.set_solver();
                
                task._statusMsg = "Simulating";
                nf.solve();

                task._statusMsg = "Writing simulation results";
                for (int i = 0; i < p.realizationsSave; i++)
                {
                    task._results[i].setCube(nf.get_result((uint)i));
                    task._results[i].writeToPetrel(ref task.progressPct);
                }
                if (task._condPoints != null)
                {
                    task._krigMeanOut.setCube(nf.get_kriging_mean());
                    task._krigMeanOut.writeToPetrel(ref task.progressPct);

                    task._krigVarOut.setCube(nf.get_kriging_variance());
                    task._krigVarOut.writeToPetrel(ref task.progressPct);
                }
            }

        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for FFTMASimulWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {
            public FFTMASimulStruct structure;
            private SeismicCollection simulationResultsCollection;

            [Description("Simulation Results Collection", "Simulation Results Collection")]
            public SeismicCollection SimulationResultsCollection {
                get { return simulationResultsCollection; }
                internal set { simulationResultsCollection = value; }
            }

            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the FFTMASimulWorkstep
        /// </summary>
        public IDescription Description {
            get { return FFTMASimulWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the FFTMASimulWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class FFTMASimulWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static FFTMASimulWorkstepDescription instance = new FFTMASimulWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static FFTMASimulWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of FFTMASimulWorkstep
            /// </summary>
            public string Name {
                get { return "FFTMA Geostatistical Simulation"; }
            }
            /// <summary>
            /// Gets the short description of FFTMASimulWorkstep
            /// </summary>
            public string ShortDescription {
                get { return ""; }
            }
            /// <summary>
            /// Gets the detailed description of FFTMASimulWorkstep
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new FFTMASimulWorkstepUI((FFTMASimulWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}