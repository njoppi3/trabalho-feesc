﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;


using Accord.Imaging.Formats;
using Accord.Math;
using ZedGraph;
using Accord.Controls;

namespace UFSC_Plugins
{
    public partial class Plot : Form
    {
        private Bitmap mapBitmap;

        public Plot()
        {
            InitializeComponent();
            try
            {
                mapBitmap = new Bitmap(500, 500, PixelFormat.Format48bppRgb);
            }
            catch (Exception)
            {
                throw;
            }
            this.Text = "Cluster Map";
        }

        public void setMapData(double [] d, int rows, int cols, bool watershed)
        {
            //if (!this.IsHandleCreated)
            {
                this.CreateHandle();
            }

            double[][] axes = Matrix.Mesh(0.0, (double)rows, rows, 0.0, (double)cols, cols);

            axes = Matrix.Mesh(new Accord.DoubleRange(0.0, rows), rows, new Accord.DoubleRange(0.0, cols), cols);

            var graph = axes.ToMatrix().InsertColumn(d).InsertColumn(d);

            scatterplotViewMap.Scatterplot.Title = "Immersion";
            if (watershed)
                scatterplotViewMap.Scatterplot.Title = "Watershed";
            this.Invoke((Action)(() =>
            {
                scatterplotViewMap.DataSource = graph;
            }));

            int k = 0;
            foreach (var item in scatterplotViewMap.Graph.GraphPane.CurveList)
            {
                item.Label.Text = Convert.ToString(k++);
            }
            scatterplotViewMap. Update();
        }
    }
}
