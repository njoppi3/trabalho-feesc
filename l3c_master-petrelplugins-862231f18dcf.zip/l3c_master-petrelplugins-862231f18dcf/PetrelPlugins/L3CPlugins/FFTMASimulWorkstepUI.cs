using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject.Well;
using Slb.Ocean.Petrel;
using Slb.Ocean.Core;
using Newtonsoft.Json;

namespace UFSC_Plugins {
    partial class FFTMASimulWorkstepUI : UserControl {
        private FFTMASimulWorkstep workstep;
        private FFTMASimulWorkstep.Arguments args;
        private WorkflowContext context;


        Droid meanCubeDroid;
        Droid meanKringCubeDroid;
        Droid varianceKringCubeDroid;

        string type;

        /**
         * Constructor
         */
        public FFTMASimulWorkstepUI(FFTMASimulWorkstep workstep, FFTMASimulWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            wellLogSelect1.setXText("Global log property: ");
            wellLogSelect1.enableLogDrops(true, 1);
            wellLogSelect1.disableZlog();

            type = "FFTMA";

            try {
                // when workstep is reopen in workflow, this fill the interface with the args
                fillInterface(args.structure);
            } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Get Cube from Petrel
         */
        private void meanDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                meanCubeDroid = droidObj;
                meanPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    meanCubeDroid = droidObj;
                    meanPresentationBox.Text = cubeTemp.Name;
                }
            }
        }
        
        /**
         * Get Cube from Petrel
         */
        private void meanKringDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                meanKringCubeDroid = droidObj;
                meanKringPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    meanKringCubeDroid = droidObj;
                    meanKringPresentationBox.Text = cubeTemp.Name;
                }
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void varianceKringDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                varianceKringCubeDroid = droidObj;
                varianceKringPresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    varianceKringCubeDroid = droidObj;
                    varianceKringPresentationBox.Text = cubeTemp.Name;
                }
            }
        }

        /**
         * FFTMA Struct 
         */
        public struct FFTMASimulStruct {
            public decimal inlineRange, crosslineRange, zRange, stdDev;
            public double rake, dip, azimuth;
            public string meanCubeDroid;
            public decimal realizations, realizationsSave, maxThreshold;
            public string[] wellDroidList;
            public bool prevKringCB;
            public string meanKringCubeDroid, varianceKringCubeDroid;
            public string timelog, propertyLog;

            public FFTMASimulStruct(FFTMASimulWorkstepUI workstepUI) {
                try {
                    inlineRange = workstepUI.inlineRangeUpDown.Value;
                    crosslineRange = workstepUI.crosslineRangeUpDown.Value;
                    zRange = workstepUI.zRangeUpDown.Value;
                    stdDev = workstepUI.stdDeviationUpDown.Value;
                    rake =((double) workstepUI.rakeUpDown.Value )*Math.PI/180;
                    dip = ((double) workstepUI.dipUpDown.Value)*Math.PI / 180;
                    azimuth = ((double) workstepUI.azimuthUpDown.Value)*Math.PI / 180;
                    if (workstepUI.meanCubeDroid != null)
                        meanCubeDroid = workstepUI.meanCubeDroid.ToString();
                    else
                        meanCubeDroid = null;
                    realizations = workstepUI.realizationsUpDown.Value;
                    realizationsSave = workstepUI.realizationsSaveUpDown.Value;
                    maxThreshold = workstepUI.maxThresholdUpDown.Value;
                    wellDroidList = null;
                    if (workstepUI.wellLogSelect1.wells.Count > 0) {
                        wellDroidList = new string[workstepUI.wellLogSelect1.wells.Count];
                        int i = 0;
                        foreach (Borehole well in workstepUI.wellLogSelect1.wells) {
                            wellDroidList[i++] = well.Droid.ToString();
                        }
                    }
                    prevKringCB = workstepUI.prevKringCheckBox.Checked;

                    timelog = "";
                    propertyLog = "";
                    if (workstepUI.wellLogSelect1.m_timeLog != null)
                        timelog = workstepUI.wellLogSelect1.m_timeLog.Droid.ToString();
                    if (workstepUI.wellLogSelect1.m_xLog != null)
                        propertyLog = workstepUI.wellLogSelect1.m_xLog.Droid.ToString();

                    if (workstepUI.meanKringCubeDroid != null)
                        meanKringCubeDroid = workstepUI.meanKringCubeDroid.ToString();
                    else
                        meanKringCubeDroid = null;
                    if (workstepUI.varianceKringCubeDroid != null)
                        varianceKringCubeDroid = workstepUI.varianceKringCubeDroid.ToString();
                    else
                        varianceKringCubeDroid = null;
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            FFTMASimulStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<FFTMASimulStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: N�o � um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            // fill the interface atributs with result
            fillInterface(result);
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        private void fillInterface(FFTMASimulStruct structure) {
            try {
                inlineRangeUpDown.Value = structure.inlineRange;
                crosslineRangeUpDown.Value = structure.crosslineRange;
                zRangeUpDown.Value = structure.zRange;
                stdDeviationUpDown.Value = structure.stdDev;
                rakeUpDown.Value = (decimal) structure.rake;
                dipUpDown.Value = (decimal) structure.dip;
                azimuthUpDown.Value = (decimal) structure.azimuth;
                if (structure.meanCubeDroid != null) {
                    meanCubeDroid = new Droid(structure.meanCubeDroid);
                    SeismicCube cube = Functions.getCube(meanCubeDroid);
                    if (cube != null) {
                        meanPresentationBox.Text = cube.Name;
                    } else {
                        meanPresentationBox.Text = Functions.getReferenceVariable(meanCubeDroid).Name;
                    }
                }
                realizationsUpDown.Value = structure.realizations;
                realizationsSaveUpDown.Value = structure.realizationsSave;
                maxThresholdUpDown.Value = structure.maxThreshold;

                wellLogSelect1.clearWellsLogs();
                //conditioningWellListBox.Items.Clear();
                if (structure.wellDroidList != null) {
                    int i = 0;
                    foreach (string droidStr in structure.wellDroidList) {
                        Droid wellDroid = new Droid(droidStr);
                        Borehole well = Functions.getWell(wellDroid);
                        if (well != null) {
                            wellLogSelect1.addWell(well);
                        }
                    }
                }
                WellLogVersion wlt = null;
                WellLogVersion wlp = null;
                if (structure.timelog != null && structure.timelog != "")
                    wlt = Functions.getWellLogVersion(new Droid(structure.timelog));
                if (structure.propertyLog != null && structure.propertyLog != "")
                    wlp = Functions.getWellLogVersion(new Droid(structure.propertyLog));

                wellLogSelect1.setLogTime(wlt);
                wellLogSelect1.setLogX(wlp);

                prevKringCheckBox.Checked = structure.prevKringCB;
                if (structure.meanKringCubeDroid != null) {
                    meanKringCubeDroid = new Droid(structure.meanKringCubeDroid);
                    SeismicCube cube = Functions.getCube(meanKringCubeDroid);
                    if (cube != null) {
                        meanKringPresentationBox.Text = cube.Name;
                    } else {
                        meanKringPresentationBox.Text = Functions.getReferenceVariable(meanKringCubeDroid).Name;
                    }
                }
                if (structure.varianceKringCubeDroid != null) {
                    varianceKringCubeDroid = new Droid(structure.varianceKringCubeDroid);
                    SeismicCube cube = Functions.getCube(varianceKringCubeDroid);
                    if (cube != null) {
                        varianceKringPresentationBox.Text = cube.Name;
                    } else {
                        varianceKringPresentationBox.Text = Functions.getReferenceVariable(varianceKringCubeDroid).Name;
                    }
                }
            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // create the structure of this class
            FFTMASimulStruct myStruct = new FFTMASimulStruct(this);
            // call saveCustomObject function with the JSON serialized struct
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is null
         */
        private bool allOK() {
            // inputs
            if (meanCubeDroid == null) {
                PetrelLogger.ErrorBox("Please, insert a wavelet.");
                return false;
            }
            if (prevKringCheckBox.Checked) {
                if (meanKringCubeDroid == null) {
                    PetrelLogger.ErrorBox("Please, insert the input seismic cube.");
                    return false;
                }
                if (varianceKringCubeDroid == null) {
                    PetrelLogger.ErrorBox("Please, insert the impedance cube.");
                    return false;
                }
            }
            return true;
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)this.TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new FFTMASimulStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new FFTMASimulStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new FFTMASimulStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new FFTMASimulStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
                ((Form) TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }
    }
}
