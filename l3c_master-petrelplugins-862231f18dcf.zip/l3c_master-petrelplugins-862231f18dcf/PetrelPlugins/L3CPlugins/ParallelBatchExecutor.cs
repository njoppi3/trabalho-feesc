﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slb.Ocean.Petrel;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;

namespace UFSC_Plugins
{
    class ParallelBatchExecutor
    {
        ManualResetEvent _mre = new ManualResetEvent(false);
        //private Thread _bgWorker;

        private IEnumerable<ITaskWithProgress> _batch;
        private Action<object> _F;
        private IProgress _progress;

        public ParallelBatchExecutor(IEnumerable<ITaskWithProgress> batch, Action<object> F, IProgress progress)
        {
            _batch = batch;
            _F = F;
            _progress = progress;
            //_bgWorker = new Thread(ParallelProcess);
        }

        public void Execute()
        {
            //_bgWorker.Start();
            ParallelProcess();
            while (!_mre.WaitOne(0))
            {
                Thread.Sleep(50);
                Application.DoEvents();

                int progress = 0;
                foreach (var t in _batch)
                {
                    progress += t.progress() / _batch.Count();
                }
                _progress.SetProgressText(_batch.First().statusMsg());
                _progress.ProgressStatus = progress;
            }

        }

        private void ParallelProcess()
        {
            int counter = 0;
            Task.Factory.StartNew( () =>
            {
                Parallel.ForEach(_batch, task =>
                {
                    _F(task);
                });
                _mre.Set();
            });

        }
    }

   interface ITaskWithProgress
    {
        // resto da classe aqui
        int progress();
        String statusMsg();
    }
}
