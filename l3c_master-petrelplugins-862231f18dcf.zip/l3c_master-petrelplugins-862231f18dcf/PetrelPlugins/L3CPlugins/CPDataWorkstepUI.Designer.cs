﻿using Slb.Ocean.Petrel;
using System;
using System.Windows.Forms;
namespace UFSC_Plugins {
    partial class CPDataWorkstepUI {

        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.buttonOpenCrossP = new System.Windows.Forms.Button();
            this.dropCube1 = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dropTarget1 = new Slb.Ocean.Petrel.UI.DropTarget();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.prior = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priorProb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.muX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.muY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.outputCubeName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.applyButton = new System.Windows.Forms.Button();
            this.cube1PresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.cube2PresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.wellLogSelect1 = new UFSC_Plugins.WellLogSelect();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonOpenCrossP
            // 
            this.buttonOpenCrossP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOpenCrossP.Location = new System.Drawing.Point(6, 249);
            this.buttonOpenCrossP.Name = "buttonOpenCrossP";
            this.buttonOpenCrossP.Size = new System.Drawing.Size(128, 23);
            this.buttonOpenCrossP.TabIndex = 1;
            this.buttonOpenCrossP.Text = "Open Cross Plot";
            this.buttonOpenCrossP.UseVisualStyleBackColor = true;
            this.buttonOpenCrossP.Click += new System.EventHandler(this.buttonOpenCrossP_Click);
            // 
            // dropCube1
            // 
            this.dropCube1.AllowDrop = true;
            this.dropCube1.Location = new System.Drawing.Point(64, 533);
            this.dropCube1.Name = "dropCube1";
            this.dropCube1.Size = new System.Drawing.Size(23, 22);
            this.dropCube1.TabIndex = 2;
            this.dropCube1.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropCube1_DragDrop);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 536);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 44;
            this.label5.Text = "Cube X:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 582);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 16);
            this.label6.TabIndex = 46;
            this.label6.Text = "Cube Y:";
            // 
            // dropTarget1
            // 
            this.dropTarget1.AllowDrop = true;
            this.dropTarget1.Location = new System.Drawing.Point(64, 579);
            this.dropTarget1.Name = "dropTarget1";
            this.dropTarget1.Size = new System.Drawing.Size(23, 22);
            this.dropTarget1.TabIndex = 3;
            this.dropTarget1.DragDrop += new System.Windows.Forms.DragEventHandler(this.dropCube2_DragDrop);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prior,
            this.priorProb,
            this.muX,
            this.muY});
            this.dataGridView2.Location = new System.Drawing.Point(6, 278);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight;
            this.dataGridView2.Size = new System.Drawing.Size(466, 231);
            this.dataGridView2.TabIndex = 47;
            // 
            // prior
            // 
            this.prior.HeaderText = "Prior";
            this.prior.Name = "prior";
            this.prior.ReadOnly = true;
            this.prior.Width = 60;
            // 
            // priorProb
            // 
            this.priorProb.HeaderText = "Prior Probability";
            this.priorProb.Name = "priorProb";
            this.priorProb.Width = 120;
            // 
            // muX
            // 
            this.muX.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.muX.HeaderText = "mu_x";
            this.muX.Name = "muX";
            this.muX.ReadOnly = true;
            // 
            // muY
            // 
            this.muY.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.muY.HeaderText = "mu_y";
            this.muY.Name = "muY";
            this.muY.ReadOnly = true;
            // 
            // outputCubeName
            // 
            this.outputCubeName.Location = new System.Drawing.Point(133, 615);
            this.outputCubeName.Name = "outputCubeName";
            this.outputCubeName.Size = new System.Drawing.Size(287, 20);
            this.outputCubeName.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 616);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 16);
            this.label7.TabIndex = 50;
            this.label7.Text = "Output Cube Name:";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(129, 640);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 6;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(395, 640);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 9;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 640);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 8;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 645);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 56;
            this.label10.Text = "Load Parameters";
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 641);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 5;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // applyButton
            // 
            this.applyButton.Location = new System.Drawing.Point(234, 640);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 7;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // cube1PresentationBox
            // 
            this.cube1PresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cube1PresentationBox.Location = new System.Drawing.Point(93, 533);
            this.cube1PresentationBox.Name = "cube1PresentationBox";
            this.cube1PresentationBox.Size = new System.Drawing.Size(327, 22);
            this.cube1PresentationBox.TabIndex = 123;
            this.cube1PresentationBox.TabStop = false;
            // 
            // cube2PresentationBox
            // 
            this.cube2PresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cube2PresentationBox.Location = new System.Drawing.Point(93, 579);
            this.cube2PresentationBox.Name = "cube2PresentationBox";
            this.cube2PresentationBox.Size = new System.Drawing.Size(327, 22);
            this.cube2PresentationBox.TabIndex = 124;
            this.cube2PresentationBox.TabStop = false;
            // 
            // wellLogSelect1
            // 
            this.wellLogSelect1.Location = new System.Drawing.Point(54, 18);
            this.wellLogSelect1.Name = "wellLogSelect1";
            this.wellLogSelect1.Size = new System.Drawing.Size(389, 225);
            this.wellLogSelect1.TabIndex = 0;
            // 
            // CPDataWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cube2PresentationBox);
            this.Controls.Add(this.cube1PresentationBox);
            this.Controls.Add(this.wellLogSelect1);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.loadDrop);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.outputCubeName);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dropTarget1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dropCube1);
            this.Controls.Add(this.buttonOpenCrossP);
            this.Controls.Add(this.label7);
            this.Name = "CPDataWorkstepUI";
            this.Size = new System.Drawing.Size(475, 775);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonOpenCrossP;
        private Slb.Ocean.Petrel.UI.DropTarget dropCube1;
        private Label label5;
        private Label label6;
        private Slb.Ocean.Petrel.UI.DropTarget dropTarget1;
        private DataGridView dataGridView2;
        private TextBox outputCubeName;
        private Label label7;
        private Button saveButton;
        private Button closeButton;
        private Button okButton;
        private Label label10;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private Button applyButton;
        private WellLogSelect wellLogSelect1;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox cube1PresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox cube2PresentationBox;
        private DataGridViewTextBoxColumn prior;
        private DataGridViewTextBoxColumn priorProb;
        private DataGridViewTextBoxColumn muX;
        private DataGridViewTextBoxColumn muY;
    }
}
