using System;
using System.Collections.Generic;
using System.Linq;
using Slb.Ocean.Basics;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.ElasticFaciesInversionWorkstepUI;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the ElasticFaciesInversion.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class ElasticFaciesInversionWorkstep : Workstep<ElasticFaciesInversionWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override ElasticFaciesInversionWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "79d1f64c-14a4-4ce4-9be6-ec8dba3f1cc3";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                this.args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�

                //inputs
                List<InputStruct> inputList = new List<InputStruct>();
                foreach (string[] item in args.structure.inputList) {
                    //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                    InputStruct inpt = new InputStruct();
                    try {
                        inpt.wavelet = Functions.getWaveletByReferenceVar(new Droid(item[0]));
                        inpt.cube = Functions.getCubeByReferenceVar(new Droid(item[1]));
                        inpt.angle = Decimal.Parse(item[2]);
                        inpt.snr = Decimal.Parse(item[3]);
                        inputList.Add(inpt);
                    } catch (Exception ex) {
                        PetrelLogger.InfoOutputWindow(ex.ToString());
                        PetrelLogger.InfoBox(ex.ToString());
                        return;
                    }
                }

                //parameters  --UD = UpDown -- para endicar que � um numericUpDown
                decimal correlationRange = args.structure.correlationRange;

                //options  --CB = CheckBox --
                bool optionsCB = args.structure.optionsCB;
                bool inlineInvCB = args.structure.inlineInvCB;
                decimal inlineInvUD = args.structure.inlineInvUD;

                //output
                //public string vpCubeOutput, vsCubeOutput, rhoCubeOutput, residualCubeOutput;
                string vpCubeOutput = args.structure.vpCubeOutput;
                string vsCubeOutput = args.structure.vsCubeOutput;
                string rhoCubeOutput = args.structure.rhoCubeOutput;
                string residualCubeOutput = args.structure.residualCubeOutput;
                string mostLikelyFaciesCubeOutput = args.structure.mostLikelyFaciesCubeOutput;
                string faciesProbabilityCubeOutput = args.structure.faciesProbabilityCubeOutput;

                //vertGate
                RegularHeightFieldSurface top = null;
                if (args.structure.topDroid != "") {
                    top = Functions.getRegularHeightFieldSurface(new Droid(args.structure.topDroid));
                    PetrelLogger.InfoOutputWindow("top: " + top.Name);
                }
                RegularHeightFieldSurface bottom = null;
                if (args.structure.bottomDroid != "") {
                    bottom = Functions.getRegularHeightFieldSurface(new Droid(args.structure.bottomDroid));
                    PetrelLogger.InfoOutputWindow("bottom: " + bottom.Name);
                }
                double topOffset = args.structure.topOffset;
                PetrelLogger.InfoOutputWindow("topOffset: " + topOffset.ToString());
                double bottomOffset = args.structure.bottomOffset;
                PetrelLogger.InfoOutputWindow("bottomOffset: " + bottomOffset.ToString());

                // ----------------------- check for horizon and create mean hor ----

                bool useHorizons = false;
                double[,] meanHor = null;
                double horSamples = 0;
                double tstart = inputList[0].cube.Origin.Z * 1000;
                double tstep = inputList[0].cube.PositionAtIndex(new IndexDouble3(0, 0, 1)).Z * -1000 + tstart;
                if (top != null)
                {
                    if (bottom == null)
                        bottom = top;

                    var seismicCube = inputList[0].cube;

                    double tend = seismicCube.PositionAtIndex(new IndexDouble3(0, 0, seismicCube.NumSamplesIJK.K - 1)).Z * 1000;
                    meanHor = Functions.StartMeanHorizonFromTwo(top.SpatialLattice.OriginalLattice, top.Samples, bottom.Samples, topOffset, bottomOffset,
                        seismicCube.SpatialLattice.OriginalLattice, tstart, tstep, tend, out horSamples);
                    useHorizons = true;
                }

                // ----------------------- checks -----------------------------------

                int j = 0;
                foreach (var i in inputList)
                {
                    j++;
                    if (i.cube == null || i.wavelet == null)
                    {
                        PetrelLogger.ErrorBox("Problem at input row number: " + Convert.ToString(j));
                        return;
                    }
                }

                j = 0;
                foreach (var i in inputList)
                {
                    j++;
                    int i3 = i.cube.NumSamplesIJK.K;
                    if (i.wavelet.SampleCount > i3)
                    {
                        PetrelLogger.ErrorBox("Wavalet is shorter than the volume. Input number " + Convert.ToString(j));
                        return;
                    }
                }

                // ------------------------ run -------------------------------------

                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot sroot = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = sroot.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Elastic Facies Inversion Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                CubeFromPetrel[] cuberesults_wrap = new CubeFromPetrel[3];
                CubeFromPetrel cube_most_likely_facies_wrap = null;
                // write output
                SeismicCube vp_result, vs_result, rho_result, mostLikelyFacies_result = null;
                using (ITransaction tr = DataManager.NewTransaction())
                {
                    tr.Lock(scol);
                    try
                    {
                        vp_result = scol.CreateSeismicCube(inputList[0].cube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.VelocityP, inputList[0].cube.ClippingRange);
                        vs_result = scol.CreateSeismicCube(inputList[0].cube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.VelocityS, inputList[0].cube.ClippingRange);
                        rho_result = scol.CreateSeismicCube(inputList[0].cube, typeof(Single), PetrelProject.WellKnownTemplates.LogTypesGroup.Density, inputList[0].cube.ClippingRange);
                        mostLikelyFacies_result = scol.CreateSeismicCube(inputList[0].cube, typeof(Single), PetrelProject.WellKnownTemplates.MiscellaneousGroup.FromFacies, inputList[0].cube.ClippingRange);
                        vp_result.Name = vpCubeOutput;
                        vs_result.Name = vsCubeOutput;
                        rho_result.Name = rhoCubeOutput;
                        mostLikelyFacies_result.Name = mostLikelyFaciesCubeOutput;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                    if (useHorizons)
                    {
                        if (inlineInvCB)
                        {
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cube_most_likely_facies_wrap = new CubeFromPetrel(mostLikelyFacies_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                        }
                        else
                        {
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, meanHor, horSamples, 10);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, meanHor, horSamples, 10);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, meanHor, horSamples, 10);
                            cube_most_likely_facies_wrap = new CubeFromPetrel(mostLikelyFacies_result, meanHor, horSamples, 10);
                        }
                    }
                    else
                    {
                        if (inlineInvCB)
                        {
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, Convert.ToInt32(inlineInvUD), false);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, Convert.ToInt32(inlineInvUD), false);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, Convert.ToInt32(inlineInvUD), false);
                            cube_most_likely_facies_wrap = new CubeFromPetrel(mostLikelyFacies_result, Convert.ToInt32(inlineInvUD), false);
                        }
                        else
                        {
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, 10);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, 10);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, 10);
                            cube_most_likely_facies_wrap = new CubeFromPetrel(mostLikelyFacies_result, 10);
                        }
                    }
                    cuberesults_wrap[0].prepareWriteToPetrel();
                    cuberesults_wrap[1].prepareWriteToPetrel();
                    cuberesults_wrap[2].prepareWriteToPetrel();
                    cube_most_likely_facies_wrap.prepareWriteToPetrel();
                }

                FaciesElasticInversionCLI.ParametersCLI p = new FaciesElasticInversionCLI.ParametersCLI();
                CubeFromPetrel[] cubeseis_wrap = new CubeFromPetrel[inputList.Count];
                CubeFromPetrel[] cuberesids_wrap = new CubeFromPetrel[inputList.Count];
                double[][] wavelets = new double[inputList.Count][];
                double[] angles = new double[inputList.Count];
                // write outputes
                j = 0;
                p.sgm_d2 = new double[inputList.Count];
                foreach (var i in inputList)
                {
                    SeismicCube residuals;
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        tr.Lock(scol);
                        try
                        {
                            residuals = scol.CreateSeismicCube(i.cube, typeof(Single), PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault, i.cube.ClippingRange);
                            residuals.Name = residualCubeOutput + " " + i.angle;
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }
                    }
                    if (useHorizons)
                    {
                        if (inlineInvCB)
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false);
                        }
                        else
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, meanHor, horSamples);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, meanHor, horSamples, 10);
                        }
                    }
                    else
                    {
                        if (inlineInvCB)
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, Convert.ToInt32(inlineInvUD), false);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInvUD), false);
                        }
                        else
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, 10);
                        }

                    }
                    cuberesids_wrap[j].prepareWriteToPetrel();
                    wavelets[j] = i.wavelet.Amplitudes.ToArray();
                    angles[j] = Convert.ToDouble(i.angle) * Math.PI / 180.0;
                    p.sgm_d2[j] = Convert.ToDouble(i.snr * i.snr);

                    j++;
                }

                //cp
                //Facies prior p(k)
                double[][] C = null;
                double[] mux = null;
                double[] muy = null;
                double[] muz = null;
                args.structure.cp.getPriors(ref C, ref mux, ref muy, ref muz);

                p.n_iterations_perTrace = 200;
                List<string> priors_name = args.structure.priorsName;
                double[,] transitionMatrix = args.structure.transitionMatrix;
                Dictionary<string, double> faciesProportion = args.structure.faciesProportion;

                p.corr_samples = Convert.ToDouble(correlationRange) / tstep;
                p.interval_frequency_sec = inputList[0].wavelet.SamplingInterval;
                p.C_prior = C;
                p.mu_prior = new double[priors_name.Count][];
                for (int i = 0; i < priors_name.Count; ++i)
                    p.mu_prior[i] = new double[]{mux[i], muy[i], muz[i]};
                

                List<double> tm = new List<double>();
                for (int c = 0; c < transitionMatrix.GetLength(1); ++c)
                    for (int r = 0; r < transitionMatrix.GetLength(0); ++r)
                        tm.Add(transitionMatrix[r, c]);
                p.transitionMatrix = tm.ToArray();

                if (args.structure.faciesProportion != null)
                {
                    p.proportions = faciesProportion.Values.ToArray();
                }
                else if (args.structure.cubeFaciesProportion != null)
                {
                    List<CubeFromPetrel> cubes_prop = new List<CubeFromPetrel>();
                    foreach (var cname in args.structure.cubeFaciesProportion.Keys.ToList())
                    {
                        SeismicCube seis = Functions.getCube(new Droid(cname));
                        if (useHorizons)
                            if (inlineInvCB)
                                cubes_prop.Add(new CubeFromPetrel(seis, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false));
                            else
                                cubes_prop.Add(new CubeFromPetrel(seis, meanHor, horSamples, 10));
                        else
                        if (inlineInvCB)
                            cubes_prop.Add(new CubeFromPetrel(seis, Convert.ToInt32(inlineInvUD), false));
                        else
                            cubes_prop.Add(new CubeFromPetrel(seis, 10));
                    }
                    p.cubeProportions = cubes_prop.ToArray();
                }
                else if (args.structure.gridDictPropDroid != null && args.structure.zonesDroid != null)
                {
                    Dictionary<string, string> cubeFacies = Functions.getCubeFaciesFromGrid(args.structure.gridDictPropDroid,
                                                                                            args.structure.zonesDroid,
                                                                                            args.structure.inputList[0][1]);
                    List<CubeFromPetrel> cubes_prop = new List<CubeFromPetrel>();
                    foreach (var cname in cubeFacies.Keys.ToList())
                    {
                        SeismicCube seis = Functions.getCube(new Droid(cname));
                        if (useHorizons)
                            if (inlineInvCB)
                                cubes_prop.Add(new CubeFromPetrel(seis, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false));
                            else
                                cubes_prop.Add(new CubeFromPetrel(seis, meanHor, horSamples, 10));
                        else
                        if (inlineInvCB)
                            cubes_prop.Add(new CubeFromPetrel(seis, Convert.ToInt32(inlineInvUD), false));
                        else
                            cubes_prop.Add(new CubeFromPetrel(seis, 10));
                    }
                    p.cubeProportions = cubes_prop.ToArray();
                }

                // write outputs for Facies prior p(k)
                CubeFromPetrel[] prob_cubes_wrap = new CubeFromPetrel[priors_name.Count];
                j = 0;
                foreach (var pname in priors_name)
                {
                    SeismicCube probCube;
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        tr.Lock(scol);
                        try
                        {
                            probCube = scol.CreateSeismicCube(inputList[0].cube, typeof(Single), PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault, inputList[0].cube.ClippingRange);
                            probCube.Name = faciesProbabilityCubeOutput + " " + pname.ToString();
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output facies probability cubes");
                            return;
                        }
                    }
                    if (useHorizons)
                        if (inlineInvCB)
                            prob_cubes_wrap[j] = new CubeFromPetrel(probCube, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false);
                        else
                            prob_cubes_wrap[j] = new CubeFromPetrel(probCube, meanHor, horSamples, 10);
                    else
                        if (inlineInvCB)
                            prob_cubes_wrap[j] = new CubeFromPetrel(probCube, Convert.ToInt32(inlineInvUD), false);
                        else
                            prob_cubes_wrap[j] = new CubeFromPetrel(probCube, 10);

                    prob_cubes_wrap[j].prepareWriteToPetrel();
                    j++;
                }
                p.wavelets = wavelets;
                p.angles = angles;
                p.n_seismic = (int) cubeseis_wrap[0].getNumZlines() - 1;
                ElasticFaciesInversionTaskSetup task = new ElasticFaciesInversionTaskSetup(ref cubeseis_wrap, ref p, ref cuberesults_wrap,
                                                                                     ref cuberesids_wrap, ref cube_most_likely_facies_wrap,
                                                                                     ref prob_cubes_wrap, ref wavelets, angles);

                List<ElasticFaciesInversionTaskSetup> tasks = new List<ElasticFaciesInversionTaskSetup>();
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, Convert.ToInt32(cubeseis_wrap[0].getNumInlines() * cubeseis_wrap[0].getNumCrosslines())))
                {
                    try
                    {
                        pbar.SetProgressText("Performing Elastic Facies Inversion");

                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doElasticFaciesInversion, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    }
                    catch (Exception excep)
                    {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete " + DateTime.Now.ToString("yyyy-MM-ddThh:mm:ssTZD"));
            }

            private void doElasticFaciesInversion(object objJob)
            {
                var task = (ElasticFaciesInversionTaskSetup)objJob;
                task._statusMsg = "Reading data from input volumes";
                foreach (var c in task._cubeseis)
                    c.readFromPetrel();

                int nseis = (int)task._cubeseis[0].getNumZlines();

                FaciesElasticInversionCLI belfi = new FaciesElasticInversionCLI(task._p);

                belfi.setSeismicCubes(task._cubeseis);

                task._statusMsg = "Processing data";
                task.belfi = belfi;
                belfi.solve();
                task._cube_vpvsrho_out[0].setCube(belfi.getVpCube());
                task._cube_vpvsrho_out[1].setCube(belfi.getVsCube());
                task._cube_vpvsrho_out[2].setCube(belfi.getPCube());
                task._cube_most_likely_facies_out.setCube(belfi.getMapFacCube());
                var outs = belfi.getSyntheticsCubes();
                int i = 0;
                foreach (var c in task._cuberesidout)
                    c.setCube(outs[i++]);
                outs = belfi.getFacProbCubes();
                i = 0;
                foreach (var c in task._cube_facies_prop_out)
                    c.setCube(outs[i++]);

                task._statusMsg = "Writing Vp results";
                task._cube_vpvsrho_out[0].writeToPetrel(ref task.progressPct, task._cubeseis[0]); // Petrel canonical unit m/s Ok
                task._statusMsg = "Writing Vs results";
                task._cube_vpvsrho_out[1].writeToPetrel(ref task.progressPct, task._cubeseis[0]); // Petrel canonical unit m/s Ok
                task._statusMsg = "Writing rho results";
                task._cube_vpvsrho_out[2].writeToPetrel(ref task.progressPct, task._cubeseis[0], 1000); // Petrel canonical unit kg/cm3 multiply by 1000
                task._statusMsg = "Writing most likely facies results";
                task._cube_most_likely_facies_out.writeToPetrel(ref task.progressPct, task._cubeseis[0], 1000);


                task._statusMsg = "Writing Seismic results";
                foreach (var c in task._cuberesidout)
                    c.writeToPetrel(ref task.progressPct, task._cubeseis[0]);
                task._statusMsg = "Writing Facies probability results";
                foreach (var c in task._cube_facies_prop_out)
                    c.writeToPetrel(ref task.progressPct, task._cubeseis[0]);
            }

            private struct InputStruct {
                public Wavelet wavelet;
                public SeismicCube cube;
                public decimal angle, snr;

                private InputStruct(Wavelet wavelet, SeismicCube cube, decimal angleUpDown, decimal signalToNoiseUpDown) {
                    this.wavelet = wavelet;
                    this.cube = cube;
                    angle = angleUpDown;
                    snr = signalToNoiseUpDown;
                }
            }
        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for ElasticFaciesInversion.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {

            public ElasticFaciesInversionStruct structure;
            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the ElasticFaciesInversion
        /// </summary>
        public IDescription Description {
            get { return ElasticFaciesInversionDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the ElasticFaciesInversion.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class ElasticFaciesInversionDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static ElasticFaciesInversionDescription instance = new ElasticFaciesInversionDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static ElasticFaciesInversionDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of ElasticFaciesInversion
            /// </summary>
            public string Name {
                get { return "ElasticFaciesInversion"; }
            }
            /// <summary>
            /// Gets the short description of ElasticFaciesInversion
            /// </summary>
            public string ShortDescription {
                get { return ""; }
            }
            /// <summary>
            /// Gets the detailed description of ElasticFaciesInversion
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new ElasticFaciesInversionWorkstepUI((ElasticFaciesInversionWorkstep)workstep, (Arguments)argumentPackage, context);
            }
        }
    }
}