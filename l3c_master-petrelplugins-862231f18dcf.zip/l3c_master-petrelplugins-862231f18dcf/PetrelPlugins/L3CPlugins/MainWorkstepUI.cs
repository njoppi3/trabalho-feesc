using System.Windows.Forms;

using Slb.Ocean.Petrel.Workflow;

namespace UFSC_Plugins
{
    /// <summary>
    /// This class is the user interface which forms the focus for the capabilities offered by the process.  
    /// This often includes UI to set up arguments and interactively run a batch part expressed as a workstep.
    /// </summary>
    partial class MainWorkstepUI : UserControl {
        private MainWorkstep workstep;
        /// <summary>
        /// The argument package instance being edited by the UI.
        /// </summary>
        private MainWorkstep.Arguments args;
        /// <summary>
        /// Contains the actual underlaying context.
        /// </summary>
        private WorkflowContext context;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWorkstepUI"/> class.
        /// </summary>
        /// <param name="workstep">the workstep instance</param>
        /// <param name="args">the arguments</param>
        /// <param name="context">the underlying context in which this UI is being used</param>
        public MainWorkstepUI(MainWorkstep workstep, MainWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            /**
             * adding AcousticInvWorkstep to tabs
             */
            AcousticInvWorkstep a1 = new AcousticInvWorkstep();
            AcousticInvWorkstep.Arguments args1 = new AcousticInvWorkstep.Arguments();
            AcousticInvWorkstepUI b1 = new AcousticInvWorkstepUI(a1, args1, null);
            TabPage page1 = new TabPage();
            page1.Text = "Acoustic Inv";
            page1.Controls.Add(b1);

            /**
             * adding FFTMASimulWorkstep to tabs
             */
            FFTMASimulWorkstep a2 = new FFTMASimulWorkstep();
            FFTMASimulWorkstep.Arguments args2 = new FFTMASimulWorkstep.Arguments();
            FFTMASimulWorkstepUI b2 = new FFTMASimulWorkstepUI(a2, args2, null);
            TabPage page2 = new TabPage();
            page2.Text = "FFT-MA";
            page2.Controls.Add(b2);

            /**
             * adding KohonenFaciesWorkstep to tabs
             */
            KohonenFaciesWorkstep a3 = new KohonenFaciesWorkstep();
            KohonenFaciesWorkstep.Arguments args3 = new KohonenFaciesWorkstep.Arguments();
            KohonenFaciesWorkstepUI b3 = new KohonenFaciesWorkstepUI(a3, args3, null);
            TabPage page3 = new TabPage();
            page3.Text = "Kohonen";
            page3.Controls.Add(b3);

            /**
             * adding ImpedancePorosityInvWorkstep to tabs
             */
            ImpedancePorosityInvWorkstep a4 = new ImpedancePorosityInvWorkstep();
            ImpedancePorosityInvWorkstep.Arguments args4 = new ImpedancePorosityInvWorkstep.Arguments();
            ImpedancePorosityInvWorkstepUI b4 = new ImpedancePorosityInvWorkstepUI(a4, args4, context);
            TabPage page4 = new TabPage();
            page4.Text = "Impedance Porosity";
            page4.Controls.Add(b4);

            /**
             * adding CPDataWorkstep to tabs
             */
            CPDataWorkstep a5 = new CPDataWorkstep();
            CPDataWorkstep.Arguments args5 = new CPDataWorkstep.Arguments();
            CPDataWorkstepUI b5 = new CPDataWorkstepUI(a5, args5, null);
            TabPage page5 = new TabPage();
            page5.Text = "Bayesian Inference";
            page5.Controls.Add(b5);

            /**
             * adding ElasticInversionWorkstep to tabs
             */
            ElasticInversionWorkstep a6 = new ElasticInversionWorkstep();
            ElasticInversionWorkstep.Arguments args6 = new ElasticInversionWorkstep.Arguments();
            ElasticInversionWorkstepUI b6 = new ElasticInversionWorkstepUI(a6, args6, null);
            TabPage page6 = new TabPage();
            page6.Text = "Elastic Inv";
            page6.Controls.Add(b6);

            /**
             * adding ElasticFaciesInversionWorkstep to tabs
             */
            ElasticFaciesInversionWorkstep a7 = new ElasticFaciesInversionWorkstep();
            ElasticFaciesInversionWorkstep.Arguments args7 = new ElasticFaciesInversionWorkstep.Arguments();
            ElasticFaciesInversionWorkstepUI b7 = new ElasticFaciesInversionWorkstepUI(a7, args7, null);
            TabPage page7 = new TabPage();
            page7.Text = "Elastic Facies Inv";
            page7.Controls.Add(b7);

            /**
             * adding pages to tabControl
             */
            tabControl.TabPages.Add(page1);
            tabControl.TabPages.Add(page2);
            tabControl.TabPages.Add(page3);
            tabControl.TabPages.Add(page4);
            tabControl.TabPages.Add(page5);
            tabControl.TabPages.Add(page6);
            tabControl.TabPages.Add(page7);
        }
    }
}
