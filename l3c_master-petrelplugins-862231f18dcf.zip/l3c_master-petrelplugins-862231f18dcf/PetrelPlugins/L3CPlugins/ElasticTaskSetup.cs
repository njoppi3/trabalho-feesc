﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slb.Ocean.Petrel.DomainObject.Seismic;

namespace UFSC_Plugins
{
    class ElasticTaskSetup : ITaskWithProgress
    {
        public CubeFromPetrel[] _cubeseis, _cubetrend;
        public ElasticInversionCLI.ParametersCLI _p;
        public CubeFromPetrel[] _cuberesidout, _cube_vpvsrho_out, _cube_ip_vpvs_out;
        public int progressPct = 0;
        public String _statusMsg = "";
        public Tuple<double[],double>[] _wavelets;
        public double srate = 0.004;
        public double[] _angles;
        public ElasticInversionCLI ei = null;

        public ElasticTaskSetup(ref CubeFromPetrel[] seis, ref CubeFromPetrel[] trends,
            ref ElasticInversionCLI.ParametersCLI pars, ref CubeFromPetrel[] vpvsrho, ref CubeFromPetrel[] ip_vpvs, ref CubeFromPetrel[] resid_out,
            ref double[][] wavelets, double[] angles)
        {
            _cubeseis = seis;
            _cubetrend = trends;
            _p = pars;
            _cuberesidout = resid_out;
            _cube_vpvsrho_out = vpvsrho;
            _cube_ip_vpvs_out = ip_vpvs;
            _angles = angles;
            _wavelets = new Tuple<double[], double>[wavelets.Length];
            int i = 0;
            foreach (var w in wavelets)
                _wavelets[i++] = new Tuple<double[], double>(w, pars.interval_frequency_sec*1000);
        }

        public int progress()
        {
            if (ei != null)
            {
                int prog = ei.getProgress();
                return prog;
            }
            return 0;
        }

        public string statusMsg()
        {
            return _statusMsg;
        }
    }
}
