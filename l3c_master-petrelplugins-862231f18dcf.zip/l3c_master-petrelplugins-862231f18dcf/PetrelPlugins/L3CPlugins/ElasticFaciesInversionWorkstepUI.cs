﻿using System;
using System.Windows.Forms;
using Slb.Ocean.Petrel.Workflow;
using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject.Well;
using System.Linq;
using Newtonsoft.Json;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using Slb.Ocean.Petrel.UI;
using System.Drawing;

namespace UFSC_Plugins {
    partial class ElasticFaciesInversionWorkstepUI : UserControl {
        private ElasticFaciesInversionWorkstep workstep;
        private ElasticFaciesInversionWorkstep.Arguments args;
        private WorkflowContext context;

        Droid inputCubeDroid, waveletDroid;
        List<InputStruct> inputList;

        VerticalGate vertGate;

        bool applyLog;
        private crossplot3d cp;
        private aiVsPhiPrior aiphipor;
        double[][] data;
        double[] mu_x;
        double[] mu_y;
        double[] mu_z;

        string type;

        /**
         * Constructor
         */
        public ElasticFaciesInversionWorkstepUI(ElasticFaciesInversionWorkstep workstep, ElasticFaciesInversionWorkstep.Arguments args, WorkflowContext context) {
            InitializeComponent();
            aiphipor = new aiVsPhiPrior("X log", "Y log", "Z log", true);

            this.workstep = workstep;
            this.args = args;
            this.context = context;

            inputList = new List<InputStruct>();

            vertGate = new VerticalGate();

            type = "ElasticFaciesInversion";

            applyLog = true;
            cp = new crossplot3d();
            data = null;
            mu_x = null;
            mu_y = null;
            mu_z = null;

            try {
                // when workstep is reopen in workflow, this fill the interface with the args
                fillInterface(args.structure);
            } catch (Exception) { }
        }

        /**
         * Verify if it's in workflow or not
         */
        public bool isInWorkflow() {
            return TopLevelControl.Text.IndexOf("[Workflow]") == -1 ? false : true;
        }

        /**
         * Opens the crossplot with logX, logY and facies datas
         */
        private void openCPbutton_Click(object sender, EventArgs e) {
            var wellLogSelect1 = aiphipor.wellLogSelect1;

            if (wellLogSelect1.m_xLog == null || wellLogSelect1.m_yLog == null || wellLogSelect1.m_zLog == null) {
                PetrelLogger.ErrorBox("Plese select logs for X, Y and Z.");
                return;
            }

            string logXDroid = null;
            logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
            string logYDroid = null;
            logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
            string logZDroid = null;
            logZDroid = wellLogSelect1.m_zLog.Droid.ToString();
            string faciesDroid = "";
            if (wellLogSelect1.m_timeLog != null)
                faciesDroid = wellLogSelect1.m_timeLog.Droid.ToString();
            if (wellLogSelect1.m_faciesLog != null)
                faciesDroid = wellLogSelect1.m_faciesLog.Droid.ToString();

            List<string> wellDroid = wellLogSelect1.getWellDroids();
            List<WellLogSample> xloglist;
            List<WellLogSample> yloglist;
            List<WellLogSample> zloglist;
            List<WellLogSample> faciesList;

            Functions.getAllLists(wellDroid, logXDroid, logYDroid, logZDroid, faciesDroid, out yloglist, out xloglist, out zloglist, out faciesList);
            WellLogVersion globalxLog = wellLogSelect1.m_xLog;
            WellLogVersion globalyLog = wellLogSelect1.m_yLog;
            WellLogVersion globalzLog = wellLogSelect1.m_zLog;
            
            try
            {
                if (data == null)
                    CPDataWorkstep.setCPData(yloglist, xloglist, zloglist, faciesList, cp, 0, true, applyLog);
                else
                    CPDataWorkstep.setCPData(yloglist, xloglist, zloglist, faciesList, cp, 0, false, applyLog);

                ITemplateSettingsInfoFactory fact = CoreSystem.GetService<ITemplateSettingsInfoFactory>(globalxLog.Template);

                if (applyLog)
                {
                    var x_label = fact.GetTemplateSettingsInfo(globalxLog.Template).LegendLabel;
                    x_label = x_label.Split('[', ']')[0] + "[log(" + x_label.Split('[', ']')[1] + ")]";
                    var y_label = fact.GetTemplateSettingsInfo(globalyLog.Template).LegendLabel;
                    y_label = y_label.Split('[', ']')[0] + "[log(" + y_label.Split('[', ']')[1] + ")]";
                    var z_label = fact.GetTemplateSettingsInfo(globalzLog.Template).LegendLabel;
                    z_label = z_label.Split('[', ']')[0] + "[log(" + z_label.Split('[', ']')[1] + ")]";
                    cp.setNames(x_label,
                                y_label,
                                z_label);
                }
                else
                {
                    cp.setNames(fact.GetTemplateSettingsInfo(globalxLog.Template).LegendLabel,
                                fact.GetTemplateSettingsInfo(globalyLog.Template).LegendLabel,
                                fact.GetTemplateSettingsInfo(globalzLog.Template).LegendLabel);
                }
                Dictionary<string, Color> faciesName = wellLogSelect1.getFaciesInfo();
                if (faciesName != null)
                {
                    for (int i = 0; i < faciesName.Count; ++i)
                    {
                        string fn = faciesName.Keys.ToList()[i];
                        cp.setPriorName(i, fn);
                        cp.setPriorColor(i, System.Drawing.ColorTranslator.ToHtml(faciesName[fn]));
                    }
                }
                cp.show();

                Cursor.Current = Cursors.WaitCursor;
                data = null;
                mu_x = null;
                mu_y = null;
                mu_z = null;
                cp.getPriors(ref data, ref mu_x, ref mu_y, ref mu_z);

                List<String> priorsName = new List<String>();
                List<Color> priorsColor = new List<Color>();
                for (int i = 0; i < data.Length; ++i)
                {
                    priorsName.Add(cp.getPriorName(i));
                    priorsColor.Add(System.Drawing.ColorTranslator.FromHtml(cp.getPriorColor(i)));
                }

                if (priorsName.Count != faciesTransitionMatrixUI1.getPriorsName().Count ||
                    !priorsName.SequenceEqual(faciesTransitionMatrixUI1.getPriorsName()) ||
                    !priorsColor.SequenceEqual(faciesTransitionMatrixUI1.getColors()))
                {
                    faciesTransitionMatrixUI1.setColors(priorsColor);
                    faciesTransitionMatrixUI1.setPriors(priorsName);

                    faciesPriorProportionUI1.setColors(priorsColor);
                    faciesPriorProportionUI1.setPriors(priorsName);
                }
                Cursor.Current = Cursors.Default;
            } catch (Exception except) {
                PetrelLogger.InfoBox("Error:\n\n" + except.ToString());
                return;
            }
        }

        /**
         * Open Vertical Gate
         */
        private void verticalGateButton_Click(object sender, EventArgs e) {
            vertGate.Show(this);
        }

        /**
         * Open AI VS PHI window
         */
        private void aiVsPhiButton_Click(object sender, EventArgs e) {
            aiphipor.Show(this);
            aiphipor.wellLogSelect1.enableLogDrops(true, 3);
        }

        /**
         * Get Wavelet from Petrel
         */
        private void waveletDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropWavelet(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                waveletDroid = droidObj;
                waveletPresentationBox.Text = refVar.Name;
            } else {
                Wavelet wvlt = Functions.getWavelet(droidObj);
                if (wvlt != null) {
                    waveletDroid = droidObj;
                    waveletPresentationBox.Text = wvlt.Name;
                    wvlt.Deleted += input_Deleted;
                }
            }
        }

        /**
         * Get Cube from Petrel
         */
        private void inputCubeDrop_DragDrop(object sender, DragEventArgs e) {
            object dropped = e.Data.GetData(typeof(object));
            Droid droidObj = Functions.dragDropCube(isInWorkflow(), dropped);

            ReferenceVariable refVar = Functions.getReferenceVariable(droidObj);
            if (refVar != null) {
                inputCubeDroid = droidObj;
                inputCubePresentationBox.Text = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(droidObj);
                if (cubeTemp != null) {
                    inputCubeDroid = droidObj;
                    inputCubePresentationBox.Text = cubeTemp.Name;
                    cubeTemp.Deleted += input_Deleted;
                }
                Cursor.Current = Cursors.WaitCursor;
                decimal mean_angle = Functions.getStackAngle(cubeTemp.Name);
                angleUpDown.Value = (mean_angle >= 0 && mean_angle <= 180) ? mean_angle : angleUpDown.Value;
                double seisstd = Functions.computeStd(cubeTemp);
                Cursor.Current = Cursors.Default;
                labelSeisStd.Text = seisstd.ToString("0.#####");
                labelSuggStd.Text = (seisstd / 2.645).ToString("0.#####");  // SNR = 7, thus diving std by sqrt(7)
            }
        }

        /**
         * Get the Wavelet name
         */
        private string getWaveletName(Droid waveletDroid) {
            String waveletName;
            ReferenceVariable refVar = Functions.getReferenceVariable(waveletDroid);
            if (refVar != null) {
                waveletName = refVar.Name;
            } else {
                Wavelet wvlt = Functions.getWavelet(waveletDroid);
                if (wvlt != null) {
                    waveletName = wvlt.Name;
                    waveletPresentationBox.Text = wvlt.Name;
                } else {
                    throw new Exception("wavelet null");
                }
            }
            return waveletName;
        }

        /**
         * Get the Cube name
         */
        private string getCubeName(Droid cubeDroid) {
            string cubeName;
            ReferenceVariable refVar = Functions.getReferenceVariable(cubeDroid);
            if (refVar != null) {
                cubeName = refVar.Name;
            } else {
                SeismicCube cubeTemp = Functions.getCube(cubeDroid);
                if (cubeTemp != null) {
                    cubeName = cubeTemp.Name;
                } else {
                    throw new Exception("cube null");
                }
            }
            return cubeName;
        }

        /**
         * Add data to the datagridView1
         */
        private void addButton_Click(object sender, EventArgs e) {
            InputStruct input;
            try {
                input = new InputStruct(this);
            } catch (Exception except) {
                PetrelLogger.InfoBox(except.Message);
                return;
            }

            string waveletName = "";
            string cubeName = "";

            try {
                waveletName = getWaveletName(input.waveletDroid);
                cubeName = getCubeName(input.cubeDroid);
            } catch (Exception excpt) {
                PetrelLogger.InfoBox(excpt.ToString());
                return;
            }

            dataGridView1.Rows.Add(waveletName, cubeName, input.angle, input.snr);
            inputList.Add(input);

            waveletPresentationBox.Text = "";
            waveletDroid = null;
            inputCubePresentationBox.Text = "";
            inputCubeDroid = null;

        }

        /**
         * Remove data from datagridView1
         */
        private void removeButton_Click(object sender, EventArgs e) {
            try {
                int selIdx = dataGridView1.CurrentRow.Index;
                if (selIdx > -1) {
                    dataGridView1.Rows.RemoveAt(selIdx);
                    inputList.RemoveAt(selIdx);
                    dataGridView1.Refresh();
                }
            } catch (Exception except) {
                PetrelLogger.InfoBox(except.Message);
                return;
            }
        }

        public void input_Deleted(object sender, EventArgs e)
        {
            Wavelet w = sender as Wavelet;
            if (w != null)
            {
                if (w.Droid.Equals(waveletDroid))
                {
                    waveletDroid = null;
                    waveletPresentationBox.Text = "";
                }
                int idx = 0;
                List<InputStruct> inptmp = inputList;
                foreach (var inp in inputList)
                {
                    if (inp.waveletDroid.Equals(w.Droid))
                    {
                        dataGridView1.Rows.RemoveAt(idx);
                        inptmp.RemoveAll(x => x.waveletDroid.Equals(inp.waveletDroid));
                        PetrelLogger.WarnBox(w.Name + " was deleted and removed from Elastic Inversion input list.");
                    }
                    idx++;
                }
                inputList = inptmp;
            }

            SeismicCube s = sender as SeismicCube;
            if (s != null)
            {
                if (s.Droid.Equals(inputCubeDroid))
                {
                    inputCubeDroid = null;
                    inputCubePresentationBox.Text = "";
                }
                int idx = 0;
                List<InputStruct> inptmp = inputList;
                foreach (var inp in inputList)
                {
                    if (inp.cubeDroid.Equals(s.Droid))
                    {
                        dataGridView1.Rows.RemoveAt(idx);
                        inptmp.RemoveAll(x => x.cubeDroid.Equals(inp.cubeDroid));
                        PetrelLogger.WarnBox(s.Name + " was deleted and removed from Elastic Inversion input list.");
                    }
                    idx++;
                }
                inputList = inptmp;
            }
        }

        /**
         * Input Struct
         */
        public struct InputStruct {
            public Droid waveletDroid;
            public Droid cubeDroid;
            public decimal angle, snr;

            public InputStruct(ElasticFaciesInversionWorkstepUI workstepUI) {
                waveletDroid = workstepUI.waveletDroid;
                cubeDroid = workstepUI.inputCubeDroid;
                angle = workstepUI.angleUpDown.Value;
                snr = workstepUI.signalToNoiseUpDown.Value;
            }
        }

        /**
         * Elastic Facies Struct
         */
        public struct ElasticFaciesInversionStruct {
            //inputs
            public List<string[]> inputList;
            //parameters  --UD = UpDown -- para endicar que é um numericUpDown
            public decimal correlationRange;
            //options  --CB = CheckBox --
            public bool optionsCB;
            public bool inlineInvCB;
            public decimal inlineInvUD;
            //output
            public string vpCubeOutput, vsCubeOutput, rhoCubeOutput, residualCubeOutput;
            public string mostLikelyFaciesCubeOutput, faciesProbabilityCubeOutput;
            //vertGate
            public string topDroid, bottomDroid;
            public double topOffset, bottomOffset;
            // wellLogSelect - crossplot
            public string logXDroid, logYDroid, logZDroid, logTimeDroid, logFaciesDroid;
            public List<string> wellDroids;
            public crossplot3d cp;
            public double[] muX, muY, muZ;
            public double[][] data;
            public List<string> priorsName;
            public List<string> priorsColor;
            public double[,] transitionMatrix;
            public List<string> faciesProportionColors;
            public Dictionary<string, double> faciesProportion;
            public Dictionary<string, string> cubeFaciesProportion;
            public string gridDictPropDroid;
            public List<string> zonesDroid;
            public Dictionary<string, string> priorGridFaciesNames;

            public ElasticFaciesInversionStruct(ElasticFaciesInversionWorkstepUI workstepUI) {
                try {
                    //inputs
                    inputList = new List<String[]>();
                    for (int i = 0; i < workstepUI.inputList.Count; i++) {
                        string[] str = new string[4];
                        //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                        str[0] = workstepUI.inputList[i].waveletDroid.ToString();
                        str[1] = workstepUI.inputList[i].cubeDroid.ToString();
                        str[2] = workstepUI.inputList[i].angle.ToString();
                        str[3] = workstepUI.inputList[i].snr.ToString();
                        inputList.Add(str);
                    }
                    //parameters
                    correlationRange = workstepUI.correlationRangeUpDown.Value;
                    //options
                    optionsCB = workstepUI.optionsCheckBox.Checked;
                    inlineInvCB = workstepUI.inlineInvPreviewCheckBox.Checked;
                    inlineInvUD = workstepUI.inlineInvPreviewUpDown.Value;
                    //output
                    vpCubeOutput = workstepUI.vpCubeTextBox.Text;
                    vsCubeOutput = workstepUI.vsCubeTextBox.Text;
                    rhoCubeOutput = workstepUI.rhoCubeTextBox.Text;
                    residualCubeOutput = workstepUI.residualCubeTextBox.Text;
                    mostLikelyFaciesCubeOutput = workstepUI.mostLikelyFaciesTextBox.Text;
                    faciesProbabilityCubeOutput = workstepUI.faciesPropOutTextBox.Text;
                    //vertGate
                    topDroid = workstepUI.vertGate.getTopDroid();
                    bottomDroid = workstepUI.vertGate.getBottomDroid();
                    topOffset = workstepUI.vertGate.getTopOffset();
                    bottomOffset = workstepUI.vertGate.getBottomOffset();

                    // wellLogSelect - crossplot
                    logXDroid = null;
                    logYDroid = null;
                    logZDroid = null;
                    logTimeDroid = null;
                    logFaciesDroid = null;
                    WellLogSelect wellLogSelect1 = workstepUI.aiphipor.wellLogSelect1;
                    if (wellLogSelect1.m_xLog != null)
                        logXDroid = wellLogSelect1.m_xLog.Droid.ToString();
                    if (wellLogSelect1.m_yLog != null)
                        logYDroid = wellLogSelect1.m_yLog.Droid.ToString();
                    if (wellLogSelect1.m_zLog != null)
                        logZDroid = wellLogSelect1.m_zLog.Droid.ToString();
                    if (wellLogSelect1.m_timeLog != null)
                        logTimeDroid = wellLogSelect1.m_timeLog.Droid.ToString();
                    if (wellLogSelect1.m_faciesLog != null)
                        logFaciesDroid = wellLogSelect1.m_faciesLog.Droid.ToString();

                    //verificar se precisa o droid de facies
                    wellDroids = wellLogSelect1.getWellDroids();
                    cp = workstepUI.cp;
                    data = null;
                    muX = null;
                    muY = null;
                    muZ = null;
                    cp.getPriors(ref data, ref muX, ref muY, ref muZ);
                    priorsName = workstepUI.faciesTransitionMatrixUI1.getPriorsName();
                    priorsColor = workstepUI.faciesTransitionMatrixUI1.getColorsHtml();
                    transitionMatrix = workstepUI.faciesTransitionMatrixUI1.getTransitionMatrixData();
                    faciesProportionColors = null;
                    faciesProportion = null;
                    cubeFaciesProportion = null;

                    gridDictPropDroid = null;
                    zonesDroid = null;
                    priorGridFaciesNames = null;

                    if (workstepUI.faciesPriorProportionUI1.faciesProportionSelected())
                    {
                        faciesProportionColors = workstepUI.faciesPriorProportionUI1.getColorsHtml();
                        faciesProportion = workstepUI.faciesPriorProportionUI1.getFaciesProportion();
                    }
                    else if (workstepUI.faciesPriorProportionUI1.cubeSelected())
                    {
                        cubeFaciesProportion = workstepUI.faciesPriorProportionUI1.getCubeFaciesProportion();
                    }
                    else if (workstepUI.faciesPriorProportionUI1.gridPropertySelected())
                    {
                        gridDictPropDroid = workstepUI.faciesPriorProportionUI1.getGridDictPropDroid();
                        zonesDroid = workstepUI.faciesPriorProportionUI1.getZones();
                        priorGridFaciesNames = workstepUI.faciesPriorProportionUI1.getPriorGridFacies();
                    }
                } catch (Exception e) {
                    PetrelLogger.InfoBox(e.ToString());
                    throw;
                }
            }
        }

        /**
         * Load data from the custom object into petrel's tree and call fillInterface passing this data as parameter
         */
        private void loadDrop_DragDrop(object sender, DragEventArgs e) {
            Cursor.Current = Cursors.WaitCursor;
            this.Enabled = false;
            ElasticFaciesInversionStruct result;
            try {
                GenericDomainObject domainObj = e.Data.GetData(typeof(GenericDomainObject)) as GenericDomainObject;
                if (domainObj.Type != type) {
                    throw new Exception();
                }
                // JSON to struct
                result = JsonConvert.DeserializeObject<ElasticFaciesInversionStruct>(domainObj.Parameters);
            } catch (Exception err) {
                PetrelLogger.InfoBox("Erro: Não é um objeto do tipo correto");
                PetrelLogger.InfoBox(err.ToString());
                return;
            }
            // fill the interface atributs with result
            try {
                fillInterface(result);
            } catch (Exception ex) {
                PetrelLogger.InfoBox(ex.ToString());
            }
            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        /**
         * Fills the interface with the parameter "structure"
         */
        private void fillInterface(ElasticFaciesInversionStruct structure) {
            try {
                //inputs
                inputList = new List<InputStruct>();
                for (int i = 0; i < structure.inputList.Count; i++) {
                    //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                    InputStruct inpt = new InputStruct();
                    if (structure.inputList[i][0] != null) {
                        inpt.waveletDroid = new Droid(structure.inputList[i][0]);
                        Functions.getWavelet(inpt.waveletDroid).Deleted += input_Deleted;
                    } else {
                        inpt.waveletDroid = null;
                    }
                    if (structure.inputList[i][1] != null) {
                        inpt.cubeDroid = new Droid(structure.inputList[i][1]);
                        Functions.getCube(inpt.cubeDroid).Deleted += input_Deleted;
                    } else {
                        inpt.cubeDroid = null;
                    }
                    inpt.angle = decimal.Parse(structure.inputList[i][2]);
                    inpt.snr = decimal.Parse(structure.inputList[i][3]);
                    inputList.Add(inpt);
                }
                dataGridView1.Rows.Clear();
                foreach (var item in inputList) {

                    string waveletName = "";
                    string cubeName = "";

                    try {
                        waveletName = getWaveletName(item.waveletDroid);
                        cubeName = getCubeName(item.cubeDroid);
                    } catch (Exception excpt) {
                        PetrelLogger.InfoBox(excpt.ToString());
                        return;
                    }

                    dataGridView1.Rows.Add(waveletName, cubeName, item.angle, item.snr);
                }
                //parameters
                correlationRangeUpDown.Value = structure.correlationRange;
                //options
                optionsCheckBox.Checked = structure.optionsCB;
                inlineInvPreviewCheckBox.Checked = structure.inlineInvCB;
                inlineInvPreviewUpDown.Value = structure.inlineInvUD;
                //output
                vpCubeTextBox.Text = structure.vpCubeOutput;
                vsCubeTextBox.Text = structure.vsCubeOutput;
                rhoCubeTextBox.Text = structure.rhoCubeOutput;
                residualCubeTextBox.Text = structure.residualCubeOutput;
                //vertGate
                vertGate.setTopDroid(structure.topDroid);
                vertGate.setBottomDroid(structure.bottomDroid);
                vertGate.setTopOffset(structure.topOffset);
                vertGate.setBottomOffset(structure.bottomOffset);

                // wellLogSelect - crossplot
                data = structure.data;
                mu_x = structure.muX;
                mu_y = structure.muY;
                mu_z = structure.muZ;

                string logXDroid = structure.logXDroid;
                string logYDroid = structure.logYDroid;
                string logZDroid = structure.logZDroid;
                string logTimeDroid = structure.logTimeDroid;
                string logfaciesDroid = structure.logFaciesDroid;

                List<string> wellDroid = structure.wellDroids;
                List<WellLogSample> aiList = new List<WellLogSample>();
                List<WellLogSample> phiList = new List<WellLogSample>();
                List<WellLogSample> zlist = new List<WellLogSample>();
                List<WellLogSample> faciesList = new List<WellLogSample>();

                if (logTimeDroid != null)
                    Functions.getAllLists(wellDroid, logXDroid, logYDroid, logZDroid, logTimeDroid, out aiList, out phiList, out zlist, out faciesList);
                else if (logfaciesDroid != null)
                    Functions.getAllLists(wellDroid, logXDroid, logYDroid, logZDroid, logfaciesDroid, out aiList, out phiList, out zlist, out faciesList);

                aiphipor.wellLogSelect1.clearWellsLogs();
                if (logTimeDroid != null)
                    aiphipor.wellLogSelect1.setLogTime(Functions.getWellLogVersion(new Droid(logTimeDroid)));
                if (logfaciesDroid != null)
                    aiphipor.wellLogSelect1.setLogFacies(Functions.getDictWellLogVersion(new Droid(logfaciesDroid)));
                if (logXDroid != null)
                    aiphipor.wellLogSelect1.setLogX(Functions.getWellLogVersion(new Droid(logXDroid)));
                if (logYDroid != null)
                    aiphipor.wellLogSelect1.setLogY(Functions.getWellLogVersion(new Droid(logYDroid)));
                if (logZDroid != null)
                    aiphipor.wellLogSelect1.setLogZ(Functions.getWellLogVersion(new Droid(logZDroid)));
                if (wellDroid != null && wellDroid.Count > 0)
                    aiphipor.wellLogSelect1.addWells(wellDroid);

                if ((data != null) && (mu_x != null) && (mu_y != null) && (mu_z != null)) {
                    CPDataWorkstep.setCPData(aiList, phiList, zlist, faciesList, cp, 0, false, applyLog);
                    if (mu_x.Count() > 0)
                        cp.setPriors(data, mu_x, mu_y, mu_z, false);
                }

                if (structure.priorsColor != null && structure.priorsName != null && structure.transitionMatrix != null)
                {
                    faciesTransitionMatrixUI1.setColorsHtml(structure.priorsColor);
                    faciesTransitionMatrixUI1.setPriors(structure.priorsName);
                    faciesTransitionMatrixUI1.setTransitionMatrixData(structure.transitionMatrix);
                }

                if (structure.faciesProportionColors != null &&
                    structure.faciesProportion.Keys != null &&
                    structure.faciesProportion.Values != null)
                {
                    faciesPriorProportionUI1.setColorsHtml(structure.faciesProportionColors);
                    faciesPriorProportionUI1.setPriors(structure.faciesProportion.Keys.ToList());
                    faciesPriorProportionUI1.setProportions(structure.faciesProportion.Values.ToList());
                } else
                {
                    faciesPriorProportionUI1.setColorsHtml(structure.priorsColor);
                    faciesPriorProportionUI1.setPriors(structure.priorsName);
                }

                for (int i = 0; i < structure.priorsColor.Count; i++)
                    cp.setPriorColor(i, structure.priorsColor[i]);
                for (int i = 0; i < structure.priorsName.Count; ++i)
                    cp.setPriorName(i, structure.priorsName[i]);

                if (structure.cubeFaciesProportion != null)
                    faciesPriorProportionUI1.setCubeProportions(structure.cubeFaciesProportion);

                if (structure.gridDictPropDroid != null)
                    faciesPriorProportionUI1.setGridDictProp(structure.gridDictPropDroid);
                if (structure.zonesDroid != null)
                    faciesPriorProportionUI1.setZones(structure.zonesDroid);

    } catch (Exception ex) {
                throw ex;
            }
        }

        /**
         * Save the data to Petrel tree, creating GenericDomainObject
         */
        private void saveButton_Click(object sender, EventArgs e) {
            // create the structure of this class
            ElasticFaciesInversionStruct myStruct = new ElasticFaciesInversionStruct(this);
            // call saveCustomObject function with the JSON serialized struct
            Functions.saveCustomObject(type, JsonConvert.SerializeObject(myStruct));
        }

        /**
         * Checks if any required parameters is correct
         */
        private bool allOK() {
            // checks if any required parameters are null
            // inputs

            return faciesTransitionMatrixUI1.transitionMatrixOk() 
                && faciesPriorProportionUI1.proportionOk();
        }

        /**
         * Just close the window
         */
        private void closeButton_Click(object sender, EventArgs e) {
            ((Form)TopLevelControl).Close();
        }

        /**
         * "Apply" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         */
        private void applyButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ElasticFaciesInversionStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ElasticFaciesInversionStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

        private void optionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            groupBox4.Visible = false;
            if (optionsCheckBox.Checked)
                groupBox4.Visible = true;
        }

        /**
         * "OK" button:
         *  - if in workflow only pass data to workflow args
         *  - otherwise create the structure, pass to workflow args and execute workflow method
         *  After that, closes
         */
        private void okButton_Click(object sender, EventArgs e) {
            if (allOK()) {
                
                if (isInWorkflow())
                    // create the structure of this class send to workstep
                    args.structure = new ElasticFaciesInversionStruct(this);
                else {
                    // create the structure of this class send to workstep and run ExecuteSimple
                    args.structure = new ElasticFaciesInversionStruct(this);
                    workstep.GetExecutor(args, null).ExecuteSimple();
                }
                
                ((Form)TopLevelControl).Close();
            } else {
                PetrelLogger.InfoBox("Some inputs are empty");
            }
        }

    }
}
