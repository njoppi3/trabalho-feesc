using System;

using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.AcousticInvWorkstepUI;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using System.Linq;
using System.Collections.Generic;
using Slb.Ocean.Basics;
using Slb.Ocean.Petrel.DomainObject.Shapes;
using Slb.Ocean.Petrel.Styles.Attributes;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the AcousticInvWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class AcousticInvWorkstep : Workstep<AcousticInvWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override AcousticInvWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "c6b2ee80-937e-40ac-857f-aacde26c949a";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                this.args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�

                //inputs
                bool loadSingleWavlt = args.structure.loadSingleWavlt;
                //public string waveletDroid, seismicCubeDroid, impedanceCubeDroid;
                Wavelet wavelet;
                SeismicCube seismicCube, impedanceCube;
                try {
                    wavelet = Functions.getWaveletByReferenceVar(new Droid(args.structure.waveletDroid));
                    seismicCube = Functions.getCubeByReferenceVar(new Droid(args.structure.seismicCubeDroid));
                    impedanceCube = Functions.getCubeByReferenceVar(new Droid(args.structure.impedanceCubeDroid));
                } catch (Exception e) {
                    PetrelLogger.ErrorBox(e.ToString());
                    return;
                }
                //parameters
                decimal impedUncertainty = args.structure.impedUncertainty;
                decimal signaltoNoise = args.structure.signaltoNoise;
                decimal correlRange = args.structure.correlRange;
                //options     -- CB = CheckBox  -- pra diferenciar os bool dos double
                bool trendFreqCB = args.structure.trendFreqCB;
                bool inlineInvCB = args.structure.inlineInvCB;
                bool horizonCorrelCB = args.structure.horizonCorrelCB;
                bool mergeInv = args.structure.mergeInv;
                decimal trendFreq = args.structure.trendFreq;
                decimal inlineInv = args.structure.inlineInv;
                decimal horizonCorrel = args.structure.horizonCorrel;
                decimal windowSize = args.structure.windowSize;
                //output
                string impedOut = args.structure.impedOut;
                string residual = args.structure.residual;
                double posteriorStdDev = args.structure.posteriorStdDev;
                //vertGate
                RegularHeightFieldSurface top = null;
                if (args.structure.topDroid != "") {
                    top = Functions.getRegularHeightFieldSurface(new Droid(args.structure.topDroid));
                    PetrelLogger.InfoOutputWindow("top: " + top.Name);
                }
                RegularHeightFieldSurface bottom = null;
                if (args.structure.bottomDroid != "") {
                    bottom = Functions.getRegularHeightFieldSurface(new Droid(args.structure.bottomDroid));
                    PetrelLogger.InfoOutputWindow("bottom: " + bottom.Name);
                }
                double topOffset = args.structure.topOffset;
                PetrelLogger.InfoOutputWindow("topOffset: " + topOffset.ToString());
                double bottomOffset = args.structure.bottomOffset;
                PetrelLogger.InfoOutputWindow("bottomOffset: " + bottomOffset.ToString());

                // verifica��o 
                int i3 = seismicCube.NumSamplesIJK.K;
                if (wavelet.SampleCount > i3) {
                    throw new Exception("Wavalet is shorter than the volumes");
                }

                Index3 sijk = seismicCube.NumSamplesIJK;
                Index3 iijk = impedanceCube.NumSamplesIJK;
                if (sijk != iijk) {
                    throw new Exception("Seismic Cube and trend cube differ in size");
                }

                PetrelLogger.InfoOutputWindow("Started...");
                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot root = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = root.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Bayesian Acoustic Inversion Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                // write output
                SeismicCube imp_result;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    try
                    {
                        tr.Lock(scol);
                        imp_result = scol.CreateSeismicCube(impedanceCube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.ImpedanceAcoustic, impedanceCube.ClippingRange);
                        imp_result.Name = impedOut;
                        args.ImpedOutCube = imp_result;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                }

                // write outputres
                SeismicCube residuals;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    try
                    {
                        tr.Lock(scol);
                        residuals = scol.CreateSeismicCube(seismicCube, typeof(Single), PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault, seismicCube.ClippingRange);
                        residuals.Name = residual;
                        args.ResidualOutCube = residuals;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                }

                CubeFromPetrel cubewseis = null;
                CubeFromPetrel cubewtrend = null;
                CubeFromPetrel cubewimp_results = null;
                CubeFromPetrel cubewresid = null;
                double tstart = seismicCube.Origin.Z * 1000;
                double tstep = seismicCube.PositionAtIndex(new IndexDouble3(0, 0, 1)).Z * -1000 + tstart;
                if (top != null)
                {
                    if (bottom == null)
                        bottom = top;

                    double horSamples = 0;
                    
                    double tend = seismicCube.PositionAtIndex(new IndexDouble3(0, 0, seismicCube.NumSamplesIJK.K-1)).Z * 1000;
                    double[,] meanHor = Functions.StartMeanHorizonFromTwo(top.SpatialLattice.OriginalLattice, top.Samples, bottom.Samples, topOffset, bottomOffset,
                        seismicCube.SpatialLattice.OriginalLattice, tstart, tstep, tend, out horSamples);

                    if (horSamples == 0)
                        throw new Exception("Your horizon shifts yields <=0 samples.");
                    
                    if (inlineInvCB)
                    {
                        cubewseis = new CubeFromPetrel(seismicCube, Convert.ToInt32(inlineInv), meanHor, horSamples);
                        cubewtrend = new CubeFromPetrel(impedanceCube, Convert.ToInt32(inlineInv), meanHor, horSamples);
                        cubewimp_results = new CubeFromPetrel(imp_result, Convert.ToInt32(inlineInv), meanHor, horSamples);
                        cubewresid = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInv), meanHor, horSamples);
                    } else
                    {
                        cubewseis = new CubeFromPetrel(seismicCube, meanHor, horSamples);
                        cubewtrend = new CubeFromPetrel(impedanceCube, meanHor, horSamples);
                        cubewimp_results = new CubeFromPetrel(imp_result, meanHor, horSamples, 10);
                        cubewresid = new CubeFromPetrel(residuals, meanHor, horSamples, 10);
                    }

                }
                else
                {
                    if (inlineInvCB)
                    {
                        cubewseis = new CubeFromPetrel(seismicCube,Convert.ToInt32(inlineInv), false);
                        cubewtrend = new CubeFromPetrel(impedanceCube, Convert.ToInt32(inlineInv), false);
                        cubewimp_results = new CubeFromPetrel(imp_result, Convert.ToInt32(inlineInv), false);
                        cubewresid = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInv), false);
                    }
                    else
                    {
                        cubewseis = new CubeFromPetrel(seismicCube);
                        cubewtrend = new CubeFromPetrel(impedanceCube);
                        cubewimp_results = new CubeFromPetrel(imp_result, 10);
                        cubewresid = new CubeFromPetrel(residuals, 10);
                    }
                }

                cubewimp_results.prepareWriteToPetrel();
                cubewresid.prepareWriteToPetrel();

                AcousticInversionCLI.Parameters p = new AcousticInversionCLI.Parameters();

                double[] wavelets = wavelet.Amplitudes.ToArray();

                p.corr_samples = Convert.ToDouble(correlRange) / tstep;
                p.filter_model = trendFreqCB;
                p.horizontal_corr_samples = Convert.ToDouble(horizonCorrel);
                p.merge_inversion = mergeInv;
                p.sampre_rate = wavelet.SamplingInterval;
                p.sgm_d2 = Convert.ToDouble(signaltoNoise * signaltoNoise);
                p.sgm_m = Convert.ToDouble(impedUncertainty);
                p.sgm_m = AcousticInversionCLI.convertUIstdtoLogstd(p.sgm_m);
                p.trend_frequency = Convert.ToDouble(trendFreq);
                p.window_size = Convert.ToInt32(windowSize);
                if (!horizonCorrelCB)
                    p.window_size = 0;

                AcousticTaskSetup task = new AcousticTaskSetup(ref cubewseis, ref cubewtrend, ref p, ref cubewimp_results, ref cubewresid, ref wavelets);

                List<AcousticTaskSetup> tasks = new List<AcousticTaskSetup>(1);
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, seismicCube.NumSamplesIJK.I * seismicCube.NumSamplesIJK.J)) {
                    try {
                        pbar.SetProgressText("Performing Bayesian Acoustic Inversion");
                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doAcousticInversion, pbar);
                        executor.Execute();
                        pbar.Dispose();
                        args.structure.posteriorStdDev = task._posteriorStd;
                    } catch (Exception excep) {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");
                PetrelLogger.InfoOutputWindow("Process complete");
            }

            private void doAcousticInversion(object objJob) {
                var task = (AcousticTaskSetup) objJob;
                task._statusMsg = "Reading data from input volumes";

                task._cubeseis.readFromPetrel();
                task._cubetrend.readFromPetrel();

                int nseis = (int) task._cubeseis.getNumZlines();
                double srate = task._p.sampre_rate;
                AcousticInversionCLI bi = new AcousticInversionCLI(nseis - 1, task._p, task._wavelet, srate);

                bi.setSeismicCube(task._cubeseis);
                bi.setTrendCube(task._cubetrend);

                task._statusMsg = "Processing data";
                bi.solve();
                task._cubeimpedout.setCube(bi.invertedCube());
                task._cuberesidout.setCube(bi.synteticsCube());

                task._statusMsg = "Writing Impedance results";
                task._cubeimpedout.writeToPetrel(ref task.progressPct, task._cubetrend);
                task._statusMsg = "Writing Seismic results";
                task._cuberesidout.writeToPetrel(ref task.progressPct, task._cubetrend);
                task._posteriorStd = bi.getPosteriorStd(task._cubeimpedout.getMean());
            }
        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for AcousticInvWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {
            public AcousticInvStruct structure;
            private SeismicCube impedOutCube;
            private SeismicCube residualOutCube;

            [Description("Impedance output cube", "Impedance output cube")]
            public SeismicCube ImpedOutCube {
                get { return impedOutCube; }
                internal set { impedOutCube = value; }
            }

            [Description("Residual output cube", "Residual output cube")]
            public SeismicCube ResidualOutCube {
                get { return residualOutCube; }
                internal set { residualOutCube = value; }
            }

            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the AcousticInvWorkstep
        /// </summary>
        public IDescription Description {
            get { return AcousticInvWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the AcousticInvWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class AcousticInvWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static AcousticInvWorkstepDescription instance = new AcousticInvWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static AcousticInvWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of AcousticInvWorkstep
            /// </summary>
            public string Name {
                get { return "Bayesian Linearized Acoustic MAP Inversion"; }
            }
            /// <summary>
            /// Gets the short description of AcousticInvWorkstep
            /// </summary>
            public string ShortDescription {
                get { return ""; }
            }
            /// <summary>
            /// Gets the detailed description of AcousticInvWorkstep
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new AcousticInvWorkstepUI((AcousticInvWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}