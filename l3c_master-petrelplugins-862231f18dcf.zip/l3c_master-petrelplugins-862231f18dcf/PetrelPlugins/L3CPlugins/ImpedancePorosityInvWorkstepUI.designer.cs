namespace UFSC_Plugins
{
    partial class ImpedancePorosityInvWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.waveletDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label30 = new System.Windows.Forms.Label();
            this.cubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.impedanceCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.porosityCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.porosityPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.cubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.impedancePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.waveletPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.label22 = new System.Windows.Forms.Label();
            this.impedanceUncertUpDown = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.signalToNoiseUpDown = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.correlationRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.porosityUncertUpDown = new System.Windows.Forms.NumericUpDown();
            this.aiVsPhiButton = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.openCPbutton = new System.Windows.Forms.Button();
            this.optionsCheckBox = new System.Windows.Forms.CheckBox();
            this.trendFreqCutCheckBox = new System.Windows.Forms.CheckBox();
            this.trendFreqcutUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlineInvPrevCheckBox = new System.Windows.Forms.CheckBox();
            this.inlineInvPrevUpDown = new System.Windows.Forms.NumericUpDown();
            this.mergeInvTrendCheckBox = new System.Windows.Forms.CheckBox();
            this.verticalGateButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.porosityValueLabel = new System.Windows.Forms.Label();
            this.impedanceValueLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.residualTextBox = new System.Windows.Forms.TextBox();
            this.porosityTextBox = new System.Windows.Forms.TextBox();
            this.impedanceTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.okButton = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.impedanceUncertUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.porosityUncertUpDown)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqcutUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPrevUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(233, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 13);
            this.label18.TabIndex = 1;
            this.label18.Text = "Input seismic cube:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 65);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Impedance trend:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(233, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "Porosity trend:";
            // 
            // waveletDrop
            // 
            this.waveletDrop.AllowDrop = true;
            this.waveletDrop.Location = new System.Drawing.Point(102, 21);
            this.waveletDrop.Name = "waveletDrop";
            this.waveletDrop.Size = new System.Drawing.Size(24, 22);
            this.waveletDrop.TabIndex = 0;
            this.waveletDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.waveletDrop_DragDrop);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(50, 13);
            this.label30.TabIndex = 11;
            this.label30.Text = "Wavelet:";
            // 
            // cubeDrop
            // 
            this.cubeDrop.AllowDrop = true;
            this.cubeDrop.Location = new System.Drawing.Point(337, 20);
            this.cubeDrop.Name = "cubeDrop";
            this.cubeDrop.Size = new System.Drawing.Size(24, 22);
            this.cubeDrop.TabIndex = 2;
            this.cubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.cubeDrop_DragDrop);
            // 
            // impedanceCubeDrop
            // 
            this.impedanceCubeDrop.AllowDrop = true;
            this.impedanceCubeDrop.Location = new System.Drawing.Point(102, 60);
            this.impedanceCubeDrop.Name = "impedanceCubeDrop";
            this.impedanceCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.impedanceCubeDrop.TabIndex = 1;
            this.impedanceCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.impedanceCubeDrop_DragDrop);
            // 
            // porosityCubeDrop
            // 
            this.porosityCubeDrop.AllowDrop = true;
            this.porosityCubeDrop.Location = new System.Drawing.Point(337, 60);
            this.porosityCubeDrop.Name = "porosityCubeDrop";
            this.porosityCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.porosityCubeDrop.TabIndex = 3;
            this.porosityCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.porosityCubeDrop_DragDrop);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.porosityPresentationBox);
            this.groupBox3.Controls.Add(this.cubePresentationBox);
            this.groupBox3.Controls.Add(this.impedancePresentationBox);
            this.groupBox3.Controls.Add(this.waveletPresentationBox);
            this.groupBox3.Controls.Add(this.porosityCubeDrop);
            this.groupBox3.Controls.Add(this.impedanceCubeDrop);
            this.groupBox3.Controls.Add(this.cubeDrop);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.waveletDrop);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(469, 94);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Inputs";
            // 
            // porosityPresentationBox
            // 
            this.porosityPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.porosityPresentationBox.Location = new System.Drawing.Point(370, 60);
            this.porosityPresentationBox.Name = "porosityPresentationBox";
            this.porosityPresentationBox.Size = new System.Drawing.Size(93, 22);
            this.porosityPresentationBox.TabIndex = 40;
            this.porosityPresentationBox.TabStop = false;
            // 
            // cubePresentationBox
            // 
            this.cubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cubePresentationBox.Location = new System.Drawing.Point(370, 21);
            this.cubePresentationBox.Name = "cubePresentationBox";
            this.cubePresentationBox.Size = new System.Drawing.Size(93, 22);
            this.cubePresentationBox.TabIndex = 39;
            this.cubePresentationBox.TabStop = false;
            // 
            // impedancePresentationBox
            // 
            this.impedancePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedancePresentationBox.Location = new System.Drawing.Point(132, 60);
            this.impedancePresentationBox.Name = "impedancePresentationBox";
            this.impedancePresentationBox.Size = new System.Drawing.Size(93, 22);
            this.impedancePresentationBox.TabIndex = 38;
            this.impedancePresentationBox.TabStop = false;
            // 
            // waveletPresentationBox
            // 
            this.waveletPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waveletPresentationBox.Location = new System.Drawing.Point(132, 21);
            this.waveletPresentationBox.Name = "waveletPresentationBox";
            this.waveletPresentationBox.Size = new System.Drawing.Size(93, 22);
            this.waveletPresentationBox.TabIndex = 37;
            this.waveletPresentationBox.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 21);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(175, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Impedance Uncertainty (g/cm� m/s)";
            // 
            // impedanceUncertUpDown
            // 
            this.impedanceUncertUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedanceUncertUpDown.Location = new System.Drawing.Point(184, 19);
            this.impedanceUncertUpDown.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.impedanceUncertUpDown.Name = "impedanceUncertUpDown";
            this.impedanceUncertUpDown.Size = new System.Drawing.Size(62, 20);
            this.impedanceUncertUpDown.TabIndex = 0;
            this.impedanceUncertUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 47);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(161, 13);
            this.label21.TabIndex = 2;
            this.label21.Text = "Seismic noise standard deviation";
            // 
            // signalToNoiseUpDown
            // 
            this.signalToNoiseUpDown.DecimalPlaces = 2;
            this.signalToNoiseUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signalToNoiseUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.signalToNoiseUpDown.Location = new System.Drawing.Point(184, 45);
            this.signalToNoiseUpDown.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.signalToNoiseUpDown.Name = "signalToNoiseUpDown";
            this.signalToNoiseUpDown.Size = new System.Drawing.Size(62, 20);
            this.signalToNoiseUpDown.TabIndex = 1;
            this.signalToNoiseUpDown.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "Correlation range";
            // 
            // correlationRangeUpDown
            // 
            this.correlationRangeUpDown.DecimalPlaces = 2;
            this.correlationRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correlationRangeUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.correlationRangeUpDown.Location = new System.Drawing.Point(184, 71);
            this.correlationRangeUpDown.Name = "correlationRangeUpDown";
            this.correlationRangeUpDown.Size = new System.Drawing.Size(62, 20);
            this.correlationRangeUpDown.TabIndex = 2;
            this.correlationRangeUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(255, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 13);
            this.label19.TabIndex = 6;
            this.label19.Text = "Porosity Uncertainty";
            // 
            // porosityUncertUpDown
            // 
            this.porosityUncertUpDown.DecimalPlaces = 2;
            this.porosityUncertUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.porosityUncertUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.porosityUncertUpDown.Location = new System.Drawing.Point(362, 19);
            this.porosityUncertUpDown.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.porosityUncertUpDown.Name = "porosityUncertUpDown";
            this.porosityUncertUpDown.Size = new System.Drawing.Size(101, 20);
            this.porosityUncertUpDown.TabIndex = 3;
            this.porosityUncertUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // aiVsPhiButton
            // 
            this.aiVsPhiButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aiVsPhiButton.Location = new System.Drawing.Point(258, 45);
            this.aiVsPhiButton.Name = "aiVsPhiButton";
            this.aiVsPhiButton.Size = new System.Drawing.Size(205, 23);
            this.aiVsPhiButton.TabIndex = 4;
            this.aiVsPhiButton.Text = "Configure AI vs. PHI Prior";
            this.aiVsPhiButton.UseVisualStyleBackColor = true;
            this.aiVsPhiButton.Click += new System.EventHandler(this.aiVsPhiButton_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.openCPbutton);
            this.groupBox6.Controls.Add(this.aiVsPhiButton);
            this.groupBox6.Controls.Add(this.porosityUncertUpDown);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.correlationRangeUpDown);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.signalToNoiseUpDown);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.impedanceUncertUpDown);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(3, 103);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(469, 104);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Parameters";
            // 
            // openCPbutton
            // 
            this.openCPbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openCPbutton.Location = new System.Drawing.Point(258, 73);
            this.openCPbutton.Name = "openCPbutton";
            this.openCPbutton.Size = new System.Drawing.Size(205, 23);
            this.openCPbutton.TabIndex = 5;
            this.openCPbutton.Text = "Open crossplot";
            this.openCPbutton.UseVisualStyleBackColor = true;
            this.openCPbutton.Click += new System.EventHandler(this.openCPbutton_Click);
            // 
            // optionsCheckBox
            // 
            this.optionsCheckBox.AutoSize = true;
            this.optionsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.optionsCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionsCheckBox.Location = new System.Drawing.Point(12, 213);
            this.optionsCheckBox.Name = "optionsCheckBox";
            this.optionsCheckBox.Size = new System.Drawing.Size(69, 17);
            this.optionsCheckBox.TabIndex = 2;
            this.optionsCheckBox.Text = "Options";
            this.optionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // trendFreqCutCheckBox
            // 
            this.trendFreqCutCheckBox.AutoSize = true;
            this.trendFreqCutCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.trendFreqCutCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trendFreqCutCheckBox.Location = new System.Drawing.Point(23, 23);
            this.trendFreqCutCheckBox.Name = "trendFreqCutCheckBox";
            this.trendFreqCutCheckBox.Size = new System.Drawing.Size(144, 17);
            this.trendFreqCutCheckBox.TabIndex = 0;
            this.trendFreqCutCheckBox.Text = "Trend frequency cut (Hz)";
            this.trendFreqCutCheckBox.UseVisualStyleBackColor = true;
            // 
            // trendFreqcutUpDown
            // 
            this.trendFreqcutUpDown.DecimalPlaces = 1;
            this.trendFreqcutUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trendFreqcutUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.trendFreqcutUpDown.Location = new System.Drawing.Point(181, 22);
            this.trendFreqcutUpDown.Name = "trendFreqcutUpDown";
            this.trendFreqcutUpDown.Size = new System.Drawing.Size(65, 20);
            this.trendFreqcutUpDown.TabIndex = 1;
            this.trendFreqcutUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // inlineInvPrevCheckBox
            // 
            this.inlineInvPrevCheckBox.AutoSize = true;
            this.inlineInvPrevCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPrevCheckBox.Location = new System.Drawing.Point(23, 49);
            this.inlineInvPrevCheckBox.Name = "inlineInvPrevCheckBox";
            this.inlineInvPrevCheckBox.Size = new System.Drawing.Size(136, 17);
            this.inlineInvPrevCheckBox.TabIndex = 2;
            this.inlineInvPrevCheckBox.Text = "Inline inversion preview";
            this.inlineInvPrevCheckBox.UseVisualStyleBackColor = true;
            // 
            // inlineInvPrevUpDown
            // 
            this.inlineInvPrevUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inlineInvPrevUpDown.Location = new System.Drawing.Point(181, 48);
            this.inlineInvPrevUpDown.Name = "inlineInvPrevUpDown";
            this.inlineInvPrevUpDown.Size = new System.Drawing.Size(65, 20);
            this.inlineInvPrevUpDown.TabIndex = 3;
            // 
            // mergeInvTrendCheckBox
            // 
            this.mergeInvTrendCheckBox.AutoSize = true;
            this.mergeInvTrendCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mergeInvTrendCheckBox.Location = new System.Drawing.Point(258, 22);
            this.mergeInvTrendCheckBox.Name = "mergeInvTrendCheckBox";
            this.mergeInvTrendCheckBox.Size = new System.Drawing.Size(150, 17);
            this.mergeInvTrendCheckBox.TabIndex = 4;
            this.mergeInvTrendCheckBox.Text = "Merge inversion with trend";
            this.mergeInvTrendCheckBox.UseVisualStyleBackColor = true;
            // 
            // verticalGateButton
            // 
            this.verticalGateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verticalGateButton.Location = new System.Drawing.Point(258, 44);
            this.verticalGateButton.Name = "verticalGateButton";
            this.verticalGateButton.Size = new System.Drawing.Size(205, 23);
            this.verticalGateButton.TabIndex = 5;
            this.verticalGateButton.Text = "Vertical Gate";
            this.verticalGateButton.UseVisualStyleBackColor = true;
            this.verticalGateButton.Click += new System.EventHandler(this.verticalGateButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.verticalGateButton);
            this.groupBox2.Controls.Add(this.mergeInvTrendCheckBox);
            this.groupBox2.Controls.Add(this.inlineInvPrevUpDown);
            this.groupBox2.Controls.Add(this.inlineInvPrevCheckBox);
            this.groupBox2.Controls.Add(this.trendFreqcutUpDown);
            this.groupBox2.Controls.Add(this.trendFreqCutCheckBox);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 211);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(469, 80);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.porosityValueLabel);
            this.groupBox1.Controls.Add(this.impedanceValueLabel);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.residualTextBox);
            this.groupBox1.Controls.Add(this.porosityTextBox);
            this.groupBox1.Controls.Add(this.impedanceTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 297);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(469, 130);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Output";
            // 
            // porosityValueLabel
            // 
            this.porosityValueLabel.AutoSize = true;
            this.porosityValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.porosityValueLabel.Location = new System.Drawing.Point(412, 107);
            this.porosityValueLabel.Name = "porosityValueLabel";
            this.porosityValueLabel.Size = new System.Drawing.Size(22, 13);
            this.porosityValueLabel.TabIndex = 18;
            this.porosityValueLabel.Text = "0.0";
            // 
            // impedanceValueLabel
            // 
            this.impedanceValueLabel.AutoSize = true;
            this.impedanceValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedanceValueLabel.Location = new System.Drawing.Point(228, 107);
            this.impedanceValueLabel.Name = "impedanceValueLabel";
            this.impedanceValueLabel.Size = new System.Drawing.Size(22, 13);
            this.impedanceValueLabel.TabIndex = 17;
            this.impedanceValueLabel.Text = "0.0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(359, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Porosity:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(159, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Impedance:";
            // 
            // residualTextBox
            // 
            this.residualTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.residualTextBox.Location = new System.Drawing.Point(102, 70);
            this.residualTextBox.Name = "residualTextBox";
            this.residualTextBox.Size = new System.Drawing.Size(361, 20);
            this.residualTextBox.TabIndex = 2;
            // 
            // porosityTextBox
            // 
            this.porosityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.porosityTextBox.Location = new System.Drawing.Point(102, 44);
            this.porosityTextBox.Name = "porosityTextBox";
            this.porosityTextBox.Size = new System.Drawing.Size(361, 20);
            this.porosityTextBox.TabIndex = 1;
            // 
            // impedanceTextBox
            // 
            this.impedanceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedanceTextBox.Location = new System.Drawing.Point(102, 18);
            this.impedanceTextBox.Name = "impedanceTextBox";
            this.impedanceTextBox.Size = new System.Drawing.Size(361, 20);
            this.impedanceTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Posterior Standard Deviations:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Residual";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Porosity output";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Impedance output";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(129, 431);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 6;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(395, 431);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 9;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Location = new System.Drawing.Point(234, 431);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 7;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 436);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Load Parameters";
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 432);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 5;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 431);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 8;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // ImpedancePorosityInvWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.loadDrop);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.optionsCheckBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.Name = "ImpedancePorosityInvWorkstepUI";
            this.Size = new System.Drawing.Size(475, 460);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.impedanceUncertUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.porosityUncertUpDown)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqcutUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInvPrevUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private Slb.Ocean.Petrel.UI.DropTarget waveletDrop;
        private System.Windows.Forms.Label label30;
        private Slb.Ocean.Petrel.UI.DropTarget cubeDrop;
        private Slb.Ocean.Petrel.UI.DropTarget impedanceCubeDrop;
        private Slb.Ocean.Petrel.UI.DropTarget porosityCubeDrop;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown impedanceUncertUpDown;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown signalToNoiseUpDown;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown correlationRangeUpDown;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown porosityUncertUpDown;
        private System.Windows.Forms.Button aiVsPhiButton;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox optionsCheckBox;
        private System.Windows.Forms.CheckBox trendFreqCutCheckBox;
        private System.Windows.Forms.NumericUpDown trendFreqcutUpDown;
        private System.Windows.Forms.CheckBox inlineInvPrevCheckBox;
        private System.Windows.Forms.NumericUpDown inlineInvPrevUpDown;
        private System.Windows.Forms.CheckBox mergeInvTrendCheckBox;
        private System.Windows.Forms.Button verticalGateButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label porosityValueLabel;
        private System.Windows.Forms.Label impedanceValueLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox residualTextBox;
        private System.Windows.Forms.TextBox porosityTextBox;
        private System.Windows.Forms.TextBox impedanceTextBox;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.Label label10;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button openCPbutton;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox porosityPresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox cubePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox impedancePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox waveletPresentationBox;
    }
}
