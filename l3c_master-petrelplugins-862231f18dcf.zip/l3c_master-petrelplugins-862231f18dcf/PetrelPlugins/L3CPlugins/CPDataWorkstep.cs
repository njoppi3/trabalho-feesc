using System;

using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.CPDataWorkstepUI;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject;
using System.Linq;
using Slb.Ocean.Petrel.DomainObject.Well;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the CPDataWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class CPDataWorkstep : Workstep<CPDataWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override CPDataWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "f25604f1-32e5-4842-8c6e-cd6fd5f28f2d";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;
            crossplot cp;

            public Executor(Arguments args, WorkflowRuntimeContext context) {
                this.args = args;
                this.context = context;
            }

            public override void ExecuteSimple() {
                //public string logXDroid, logYDroid, faciesDroid;
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�
                cp = new crossplot();

                string logXDroid = args.structure.logXDroid;
                string logYDroid = args.structure.logYDroid;
                string faciesDroid = args.structure.faciesDroid;
                List<string> wellDroid = args.structure.wellDroids;
                List<WellLogSample> aiList;
                List<WellLogSample> phiList;
                List<WellLogSample> faciesList;

                Functions.getAllLists(wellDroid, logXDroid, logYDroid, faciesDroid, out aiList, out phiList, out faciesList);

                double[] muX = args.structure.muX;
                double[] muY = args.structure.muY;
                double[] priorProbs = args.structure.priorProbs;
                List<string> priorNames = args.structure.priorNames;
                double[][] data = args.structure.data;

                PetrelLogger.Info(aiList.Count.ToString() + " --- " + phiList.Count.ToString());

                try {
                    //ver se vai funcionar isso
                    setCPData(aiList, phiList, faciesList, cp);
                    cp.setPriors(ref data, ref muX, ref muY);
                } catch (Exception except) {
                    PetrelLogger.InfoBox("Erro: " + except.ToString());
                    return;
                }
                
                SeismicCube cubeX, cubeY;
                try {
                    cubeX = Functions.getCubeByReferenceVar(new Droid(args.structure.cubeXDroid));
                    cubeY = Functions.getCubeByReferenceVar(new Droid(args.structure.cubeYDroid));
                } catch (Exception e) {
                    PetrelLogger.ErrorBox(e.ToString());
                    return;
                }
                string outputCubeName = args.structure.output;

                // ---------------------------------------------------------------------------

                double[][] covars = null;
                double[] mu_x = null;
                double[] mu_y = null;
                cp.getPriors(ref covars, ref mu_x, ref mu_y);

                List<double[]> means = new List<double[]>();
                means.Add(mu_x);
                means.Add(mu_y);

                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot root = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = root.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Bayesian Inference Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                // write output
                SeismicCube cubeout;
                try
                {
                    using (ITransaction tr = DataManager.NewTransaction()) {
                        tr.Lock(scol);
                        cubeout = scol.CreateSeismicCube(cubeX, PetrelProject.WellKnownTemplates.MiscellaneousGroup.FromFacies);
                        cubeout.Name = outputCubeName + " most probable";
                        tr.Commit();
                    }
                } catch (Exception){
                    PetrelLogger.ErrorBox("Error creating output cubes");
                    return;
                }

                SeismicCube[] probCubes = new SeismicCube[muX.Length];
                CubeFromPetrel[] probCubesPetrel = new CubeFromPetrel[muX.Length];
                try
                {
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        tr.Lock(scol);
                        for (int i = 0; i < muX.Length; i++)
                        {
                            probCubes[i] = scol.CreateSeismicCube(cubeX, PetrelProject.WellKnownTemplates.MiscellaneousGroup.FromFacies);
                            probCubes[i].Name = outputCubeName + " prob. of " + priorNames[i];
                        }
                        tr.Commit();
                    }
                }
                catch (Exception)
                {
                    PetrelLogger.ErrorBox("Error creating output cubes");
                    return;
                }

                var cubewx = new CubeFromPetrel(cubeX);
                var cubewy = new CubeFromPetrel(cubeY);
                var cubewOut = new CubeFromPetrel(cubeout);
                cubewOut.prepareWriteToPetrel();
                for (int i = 0; i < probCubes.Length; i++)
                {
                    probCubesPetrel[i] = new CubeFromPetrel(probCubes[i]);
                    probCubesPetrel[i].prepareWriteToPetrel();
                }

                BayesTaskSetup task = new BayesTaskSetup(ref cubewx, ref cubewy, ref covars, ref means, ref cubewOut, ref priorProbs, ref probCubesPetrel);

                List<BayesTaskSetup> tasks = new List<BayesTaskSetup>(1);
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, cubeX.NumSamplesIJK.I * cubeX.NumSamplesIJK.J)) {
                    try {
                        pbar.SetProgressText("Performing Bayesian Inference");
                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doBayesianInference, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    } catch (Exception excep) {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");
            }

            private void doBayesianInference(object objJob) {
                var task = (BayesTaskSetup) objJob;
                task._statusMsg = "Reading data from input volumes";

                task._cubeX.readFromPetrel();
                task._cubeY.readFromPetrel();

                double[] mux = task._Means.First<double[]>();
                double[] muy = task._Means.Last<double[]>();
                double[] priorProbs = task._priorProbs;
                double sum = 0;
                for (int i = 0; i < priorProbs.Length; i++)
                {
                    sum = sum + priorProbs[i];
                }
                for (int i = 0; i < priorProbs.Length; i++)
                {
                    priorProbs[i] /= sum;
                }
                double[][] covars = task._Covars;
                BayesianInferenceW bi = new BayesianInferenceW(ref covars, ref mux, ref muy, ref priorProbs);

                CubeCLI cubex1 = task._cubeX;
                CubeCLI cubex2 = task._cubeY;
                CubeCLI cubeout = task._cubeMaxProb;
                CubeCLI[] cubeProbs = task._probCubes;
                task._statusMsg = "Processing data";
                bi.inferMaxProb(ref cubex1, ref cubex2, ref cubeout, ref task.progressPct);
                bi.inferProbCubes(ref cubex1, ref cubex2, ref cubeProbs, ref task.progressPct);
                task._statusMsg = "Writing results";
                task._cubeMaxProb.writeToPetrel(ref task.progressPct);

                foreach(CubeFromPetrel c in task._probCubes)
                    c.writeToPetrel(ref task.progressPct);
            }

        }

        static public void setCPData(List<WellLogSample> xList, List<WellLogSample> yList, List<WellLogSample> faciesList, crossplot cp, bool applylog = false)
        {

            List<double> x = new List<double>();
            List<double> y = new List<double>();
            List<double> fac = new List<double>();

            for (int i = 0; i < xList.Count; i++)
            {
                if ((xList[i].Value > 0) && (yList[i].Value > 0))
                {
                    x.Add(xList[i].Value);
                    if (applylog)
                        y.Add(Math.Log(yList[i].Value));
                    else
                        y.Add(yList[i].Value);
                    if (faciesList.Count == xList.Count)
                    {
                        if (faciesList[i].Value > 0)
                        {
                            fac.Add(faciesList[i].Value);
                        }
                        else
                        {
                            fac.Add(0);
                        }
                    }
                    else
                    {
                        fac.Add(0);
                    }
                }
            }

            if (!(x.Count > 0))
            {
                PetrelLogger.InfoBox("Error:\n\nNo valid value!\nSelect 'Show only rows with valid values' to display the valid values.");
                return;
            }

            double[] crossplotdata = new double[x.Count() * 3];
            int k = 0;
            for (int i = 0; i < x.Count; i++)
                crossplotdata[k++] = x[i];
            for (int i = 0; i < y.Count(); i++)
                crossplotdata[k++] = y[i];
            for (int i = 0; i < fac.Count(); i++)
                crossplotdata[k++] = fac[i];

            try
            {
                cp.setData(ref crossplotdata, x.Count(), 3);
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Error in setCPData()\n" + except.ToString());
                return;
            }
        }

        static public void setCPData(List<WellLogSample> xList, List<WellLogSample> yList, List<WellLogSample> zList, List<WellLogSample> faciesList, 
            crossplot3d cp, int npriors, bool calcFromFacies = true, bool applylog = false)
        {

            List<double> x = new List<double>();
            List<double> y = new List<double>();
            List<double> z = new List<double>();
            List<double> fac = new List<double>();
            for (int i = 0; i < xList.Count; i++)
            {
                if ((xList[i].Value > 0) && (yList[i].Value > 0) && (zList[i].Value > 0))
                {
                    if (applylog)
                    {
                        x.Add(Math.Log(xList[i].Value));
                        y.Add(Math.Log(yList[i].Value));
                        z.Add(Math.Log(zList[i].Value));
                    } else
                    {
                        x.Add(xList[i].Value);
                        y.Add(yList[i].Value);
                        z.Add(zList[i].Value);
                    }

                    if (faciesList.Count == xList.Count)
                    {
                        if (faciesList[i].Value > 0)
                        {
                            fac.Add(faciesList[i].Value);
                        }
                        else
                        {
                            fac.Add(0);
                        }
                    }
                    else
                    {
                        fac.Add(0);
                    }
                }
            }

            if (!(x.Count > 0))
            {
                PetrelLogger.InfoBox("Error:\n\nNo valid value!\nSelect 'Show only rows with valid values' to display the valid values.");
                return;
            }

            double[] crossplotdata = new double[x.Count() * 4];
            int k = 0;
            for (int i = 0; i < x.Count; i++)
                crossplotdata[k++] = x[i];
            for (int i = 0; i < y.Count(); i++)
                crossplotdata[k++] = y[i];
            for (int i = 0; i < z.Count(); i++)
                crossplotdata[k++] = z[i];
            for (int i = 0; i < fac.Count(); i++)
                crossplotdata[k++] = fac[i];

            try
            {
                cp.setData(ref crossplotdata, x.Count(), 4, npriors, calcFromFacies);
            }
            catch (Exception except)
            {
                PetrelLogger.InfoBox("Error in setCPData()\n" + except.ToString());
                return;
            }
        }


        #endregion

        /// <summary>
        /// ArgumentPackage class for CPDataWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {
            public CPDataStruct structure;

            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the CPDataWorkstep
        /// </summary>
        public IDescription Description {
            get { return CPDataWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the CPDataWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class CPDataWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static CPDataWorkstepDescription instance = new CPDataWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static CPDataWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of CPDataWorkstep
            /// </summary>

            public string Name
            {
                get { return "Bayesian Inference Workstep"; }
            }
            /// <summary>
            /// Gets the short description of CPDataWorkstep
            /// </summary>

            public string ShortDescription
            {
                get { return "Set priors and perform Bayesian inference using inversion results"; }

            }
            /// <summary>
            /// Gets the detailed description of CPDataWorkstep
            /// </summary>
            public string Description
            {
                get { return "Use well logs to create a crossplot and define prior distributions for each facies. Use inversion results" +
                        "with the same properties as the well logs used to infer the facies on a new cube."; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new CPDataWorkstepUI((CPDataWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}
