namespace UFSC_Plugins
{
    partial class AcousticInvWorkstepUI
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.singleWvltRadio = new System.Windows.Forms.RadioButton();
            this.cubeWvltRadio = new System.Windows.Forms.RadioButton();
            this.InputsGroupBox = new System.Windows.Forms.GroupBox();
            this.labelSuggStd = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelSeisStd = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.impedanceCubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.seismicCubePresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.typeWaveletPresentationBox = new Slb.Ocean.Petrel.UI.Controls.PresentationBox();
            this.impedanceDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.seismicCubeDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.waveletDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.parametersGroupBox = new System.Windows.Forms.GroupBox();
            this.correlationRangeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.signalToNoiseUpDown = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.impedUncertaintyUpDown = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.optionsGroupBox = new System.Windows.Forms.GroupBox();
            this.windowSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.verticalGateButton = new System.Windows.Forms.Button();
            this.mergeInvTrendCheck = new System.Windows.Forms.CheckBox();
            this.horizonCorrelatUpDown = new System.Windows.Forms.NumericUpDown();
            this.horizonCorrelatCheck = new System.Windows.Forms.CheckBox();
            this.inlineInversionUpDown = new System.Windows.Forms.NumericUpDown();
            this.inlineInversionCheck = new System.Windows.Forms.CheckBox();
            this.trendFreqUpDown = new System.Windows.Forms.NumericUpDown();
            this.TrendFreqCheck = new System.Windows.Forms.CheckBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.residualBox = new System.Windows.Forms.TextBox();
            this.impedOutBox = new System.Windows.Forms.TextBox();
            this.posteriorStdDevLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.loadDrop = new Slb.Ocean.Petrel.UI.DropTarget();
            this.label10 = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.applyButton = new System.Windows.Forms.Button();
            this.InputsGroupBox.SuspendLayout();
            this.parametersGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.impedUncertaintyUpDown)).BeginInit();
            this.optionsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.windowSizeUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizonCorrelatUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInversionUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqUpDown)).BeginInit();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // singleWvltRadio
            // 
            this.singleWvltRadio.AutoSize = true;
            this.singleWvltRadio.Checked = true;
            this.singleWvltRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.singleWvltRadio.Location = new System.Drawing.Point(20, 19);
            this.singleWvltRadio.Name = "singleWvltRadio";
            this.singleWvltRadio.Size = new System.Drawing.Size(128, 17);
            this.singleWvltRadio.TabIndex = 0;
            this.singleWvltRadio.TabStop = true;
            this.singleWvltRadio.Text = "Load a single wavelet";
            this.singleWvltRadio.UseVisualStyleBackColor = true;
            this.singleWvltRadio.CheckedChanged += new System.EventHandler(this.singleWvltRadio_CheckedChanged);
            // 
            // cubeWvltRadio
            // 
            this.cubeWvltRadio.AutoSize = true;
            this.cubeWvltRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cubeWvltRadio.Location = new System.Drawing.Point(20, 42);
            this.cubeWvltRadio.Name = "cubeWvltRadio";
            this.cubeWvltRadio.Size = new System.Drawing.Size(142, 17);
            this.cubeWvltRadio.TabIndex = 1;
            this.cubeWvltRadio.Text = "Load a cube of wavelets";
            this.cubeWvltRadio.UseVisualStyleBackColor = true;
            // 
            // InputsGroupBox
            // 
            this.InputsGroupBox.Controls.Add(this.labelSuggStd);
            this.InputsGroupBox.Controls.Add(this.label13);
            this.InputsGroupBox.Controls.Add(this.labelSeisStd);
            this.InputsGroupBox.Controls.Add(this.label12);
            this.InputsGroupBox.Controls.Add(this.impedanceCubePresentationBox);
            this.InputsGroupBox.Controls.Add(this.seismicCubePresentationBox);
            this.InputsGroupBox.Controls.Add(this.typeWaveletPresentationBox);
            this.InputsGroupBox.Controls.Add(this.impedanceDrop);
            this.InputsGroupBox.Controls.Add(this.seismicCubeDrop);
            this.InputsGroupBox.Controls.Add(this.waveletDrop);
            this.InputsGroupBox.Controls.Add(this.singleWvltRadio);
            this.InputsGroupBox.Controls.Add(this.label2);
            this.InputsGroupBox.Controls.Add(this.cubeWvltRadio);
            this.InputsGroupBox.Controls.Add(this.label1);
            this.InputsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputsGroupBox.Location = new System.Drawing.Point(3, 3);
            this.InputsGroupBox.Name = "InputsGroupBox";
            this.InputsGroupBox.Size = new System.Drawing.Size(469, 145);
            this.InputsGroupBox.TabIndex = 0;
            this.InputsGroupBox.TabStop = false;
            this.InputsGroupBox.Text = "Inputs";
            // 
            // labelSuggStd
            // 
            this.labelSuggStd.AutoSize = true;
            this.labelSuggStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSuggStd.Location = new System.Drawing.Point(320, 84);
            this.labelSuggStd.Name = "labelSuggStd";
            this.labelSuggStd.Size = new System.Drawing.Size(13, 13);
            this.labelSuggStd.TabIndex = 103;
            this.labelSuggStd.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(204, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(108, 13);
            this.label13.TabIndex = 102;
            this.label13.Text = "Suggested noise Std:";
            // 
            // labelSeisStd
            // 
            this.labelSeisStd.AutoSize = true;
            this.labelSeisStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeisStd.Location = new System.Drawing.Point(320, 56);
            this.labelSeisStd.Name = "labelSeisStd";
            this.labelSeisStd.Size = new System.Drawing.Size(13, 13);
            this.labelSeisStd.TabIndex = 101;
            this.labelSeisStd.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(204, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 13);
            this.label12.TabIndex = 100;
            this.label12.Text = "Selected Seismic Std:";
            // 
            // impedanceCubePresentationBox
            // 
            this.impedanceCubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedanceCubePresentationBox.Location = new System.Drawing.Point(335, 111);
            this.impedanceCubePresentationBox.Name = "impedanceCubePresentationBox";
            this.impedanceCubePresentationBox.Size = new System.Drawing.Size(128, 22);
            this.impedanceCubePresentationBox.TabIndex = 7;
            this.impedanceCubePresentationBox.TabStop = false;
            // 
            // seismicCubePresentationBox
            // 
            this.seismicCubePresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seismicCubePresentationBox.Location = new System.Drawing.Point(335, 16);
            this.seismicCubePresentationBox.Name = "seismicCubePresentationBox";
            this.seismicCubePresentationBox.Size = new System.Drawing.Size(128, 22);
            this.seismicCubePresentationBox.TabIndex = 5;
            this.seismicCubePresentationBox.TabStop = false;
            // 
            // typeWaveletPresentationBox
            // 
            this.typeWaveletPresentationBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeWaveletPresentationBox.Location = new System.Drawing.Point(47, 65);
            this.typeWaveletPresentationBox.Name = "typeWaveletPresentationBox";
            this.typeWaveletPresentationBox.Size = new System.Drawing.Size(129, 22);
            this.typeWaveletPresentationBox.TabIndex = 3;
            this.typeWaveletPresentationBox.TabStop = false;
            // 
            // impedanceDrop
            // 
            this.impedanceDrop.AllowDrop = true;
            this.impedanceDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedanceDrop.Location = new System.Drawing.Point(305, 111);
            this.impedanceDrop.Name = "impedanceDrop";
            this.impedanceDrop.Size = new System.Drawing.Size(24, 22);
            this.impedanceDrop.TabIndex = 6;
            this.impedanceDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.impedanceDrop_DragDrop);
            // 
            // seismicCubeDrop
            // 
            this.seismicCubeDrop.AllowDrop = true;
            this.seismicCubeDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seismicCubeDrop.Location = new System.Drawing.Point(305, 16);
            this.seismicCubeDrop.Name = "seismicCubeDrop";
            this.seismicCubeDrop.Size = new System.Drawing.Size(24, 22);
            this.seismicCubeDrop.TabIndex = 4;
            this.seismicCubeDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.seismicCubeDrop_DragDrop);
            // 
            // waveletDrop
            // 
            this.waveletDrop.AllowDrop = true;
            this.waveletDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waveletDrop.Location = new System.Drawing.Point(20, 65);
            this.waveletDrop.Name = "waveletDrop";
            this.waveletDrop.Size = new System.Drawing.Size(24, 22);
            this.waveletDrop.TabIndex = 2;
            this.waveletDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.waveletDrop_DragDrop);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(204, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 99;
            this.label2.Text = "Impedance trend:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(204, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 99;
            this.label1.Text = "Input seismic cube:";
            // 
            // parametersGroupBox
            // 
            this.parametersGroupBox.Controls.Add(this.correlationRangeUpDown);
            this.parametersGroupBox.Controls.Add(this.label5);
            this.parametersGroupBox.Controls.Add(this.signalToNoiseUpDown);
            this.parametersGroupBox.Controls.Add(this.label4);
            this.parametersGroupBox.Controls.Add(this.impedUncertaintyUpDown);
            this.parametersGroupBox.Controls.Add(this.label3);
            this.parametersGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parametersGroupBox.Location = new System.Drawing.Point(6, 154);
            this.parametersGroupBox.Name = "parametersGroupBox";
            this.parametersGroupBox.Size = new System.Drawing.Size(469, 95);
            this.parametersGroupBox.TabIndex = 1;
            this.parametersGroupBox.TabStop = false;
            this.parametersGroupBox.Text = "Parameters";
            // 
            // correlationRangeUpDown
            // 
            this.correlationRangeUpDown.DecimalPlaces = 4;
            this.correlationRangeUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correlationRangeUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.correlationRangeUpDown.Location = new System.Drawing.Point(319, 67);
            this.correlationRangeUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.correlationRangeUpDown.Name = "correlationRangeUpDown";
            this.correlationRangeUpDown.Size = new System.Drawing.Size(144, 20);
            this.correlationRangeUpDown.TabIndex = 2;
            this.correlationRangeUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 13);
            this.label5.TabIndex = 99;
            this.label5.Text = "Vertical correlation range (ms)";
            // 
            // signalToNoiseUpDown
            // 
            this.signalToNoiseUpDown.DecimalPlaces = 4;
            this.signalToNoiseUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signalToNoiseUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.signalToNoiseUpDown.Location = new System.Drawing.Point(319, 41);
            this.signalToNoiseUpDown.Maximum = new decimal(new int[] {
            1569325056,
            23283064,
            0,
            0});
            this.signalToNoiseUpDown.Name = "signalToNoiseUpDown";
            this.signalToNoiseUpDown.Size = new System.Drawing.Size(144, 20);
            this.signalToNoiseUpDown.TabIndex = 1;
            this.signalToNoiseUpDown.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 13);
            this.label4.TabIndex = 99;
            this.label4.Text = "Seismic Noise Standard Deviation";
            // 
            // impedUncertaintyUpDown
            // 
            this.impedUncertaintyUpDown.DecimalPlaces = 4;
            this.impedUncertaintyUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedUncertaintyUpDown.Location = new System.Drawing.Point(319, 14);
            this.impedUncertaintyUpDown.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.impedUncertaintyUpDown.Name = "impedUncertaintyUpDown";
            this.impedUncertaintyUpDown.Size = new System.Drawing.Size(144, 20);
            this.impedUncertaintyUpDown.TabIndex = 0;
            this.impedUncertaintyUpDown.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 13);
            this.label3.TabIndex = 99;
            this.label3.Text = "Impedance Uncertainty (g/cm� ms/s)";
            // 
            // optionsGroupBox
            // 
            this.optionsGroupBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.optionsGroupBox.Controls.Add(this.windowSizeUpDown);
            this.optionsGroupBox.Controls.Add(this.label6);
            this.optionsGroupBox.Controls.Add(this.verticalGateButton);
            this.optionsGroupBox.Controls.Add(this.mergeInvTrendCheck);
            this.optionsGroupBox.Controls.Add(this.horizonCorrelatUpDown);
            this.optionsGroupBox.Controls.Add(this.horizonCorrelatCheck);
            this.optionsGroupBox.Controls.Add(this.inlineInversionUpDown);
            this.optionsGroupBox.Controls.Add(this.inlineInversionCheck);
            this.optionsGroupBox.Controls.Add(this.trendFreqUpDown);
            this.optionsGroupBox.Controls.Add(this.TrendFreqCheck);
            this.optionsGroupBox.Location = new System.Drawing.Point(3, 255);
            this.optionsGroupBox.Name = "optionsGroupBox";
            this.optionsGroupBox.Size = new System.Drawing.Size(469, 110);
            this.optionsGroupBox.TabIndex = 3;
            this.optionsGroupBox.TabStop = false;
            this.optionsGroupBox.Text = "Options";
            // 
            // windowSizeUpDown
            // 
            this.windowSizeUpDown.Location = new System.Drawing.Point(390, 75);
            this.windowSizeUpDown.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.windowSizeUpDown.Name = "windowSizeUpDown";
            this.windowSizeUpDown.Size = new System.Drawing.Size(73, 20);
            this.windowSizeUpDown.TabIndex = 9;
            this.windowSizeUpDown.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(296, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 99;
            this.label6.Text = "Window Size";
            // 
            // verticalGateButton
            // 
            this.verticalGateButton.Location = new System.Drawing.Point(296, 49);
            this.verticalGateButton.Name = "verticalGateButton";
            this.verticalGateButton.Size = new System.Drawing.Size(167, 20);
            this.verticalGateButton.TabIndex = 8;
            this.verticalGateButton.Text = "Vertical Gate";
            this.verticalGateButton.UseVisualStyleBackColor = true;
            this.verticalGateButton.Click += new System.EventHandler(this.verticalGateButton_Click);
            // 
            // mergeInvTrendCheck
            // 
            this.mergeInvTrendCheck.AutoSize = true;
            this.mergeInvTrendCheck.Location = new System.Drawing.Point(296, 26);
            this.mergeInvTrendCheck.Name = "mergeInvTrendCheck";
            this.mergeInvTrendCheck.Size = new System.Drawing.Size(150, 17);
            this.mergeInvTrendCheck.TabIndex = 7;
            this.mergeInvTrendCheck.Text = "Merge inversion with trend";
            this.mergeInvTrendCheck.UseVisualStyleBackColor = true;
            // 
            // horizonCorrelatUpDown
            // 
            this.horizonCorrelatUpDown.DecimalPlaces = 2;
            this.horizonCorrelatUpDown.Location = new System.Drawing.Point(182, 75);
            this.horizonCorrelatUpDown.Name = "horizonCorrelatUpDown";
            this.horizonCorrelatUpDown.Size = new System.Drawing.Size(92, 20);
            this.horizonCorrelatUpDown.TabIndex = 6;
            this.horizonCorrelatUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // horizonCorrelatCheck
            // 
            this.horizonCorrelatCheck.AutoSize = true;
            this.horizonCorrelatCheck.Location = new System.Drawing.Point(20, 78);
            this.horizonCorrelatCheck.Name = "horizonCorrelatCheck";
            this.horizonCorrelatCheck.Size = new System.Drawing.Size(126, 17);
            this.horizonCorrelatCheck.TabIndex = 5;
            this.horizonCorrelatCheck.Text = "Horizontal Correlation";
            this.horizonCorrelatCheck.UseVisualStyleBackColor = true;
            // 
            // inlineInversionUpDown
            // 
            this.inlineInversionUpDown.Location = new System.Drawing.Point(182, 49);
            this.inlineInversionUpDown.Maximum = new decimal(new int[] {
            1215752191,
            23,
            0,
            0});
            this.inlineInversionUpDown.Name = "inlineInversionUpDown";
            this.inlineInversionUpDown.Size = new System.Drawing.Size(92, 20);
            this.inlineInversionUpDown.TabIndex = 4;
            // 
            // inlineInversionCheck
            // 
            this.inlineInversionCheck.AutoSize = true;
            this.inlineInversionCheck.Location = new System.Drawing.Point(20, 52);
            this.inlineInversionCheck.Name = "inlineInversionCheck";
            this.inlineInversionCheck.Size = new System.Drawing.Size(136, 17);
            this.inlineInversionCheck.TabIndex = 3;
            this.inlineInversionCheck.Text = "Inline inversion preview";
            this.inlineInversionCheck.UseVisualStyleBackColor = true;
            // 
            // trendFreqUpDown
            // 
            this.trendFreqUpDown.DecimalPlaces = 1;
            this.trendFreqUpDown.Location = new System.Drawing.Point(182, 23);
            this.trendFreqUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.trendFreqUpDown.Name = "trendFreqUpDown";
            this.trendFreqUpDown.Size = new System.Drawing.Size(92, 20);
            this.trendFreqUpDown.TabIndex = 2;
            this.trendFreqUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // TrendFreqCheck
            // 
            this.TrendFreqCheck.AutoSize = true;
            this.TrendFreqCheck.Checked = true;
            this.TrendFreqCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.TrendFreqCheck.Location = new System.Drawing.Point(20, 26);
            this.TrendFreqCheck.Name = "TrendFreqCheck";
            this.TrendFreqCheck.Size = new System.Drawing.Size(144, 17);
            this.TrendFreqCheck.TabIndex = 0;
            this.TrendFreqCheck.Text = "Trend frequency cut (Hz)";
            this.TrendFreqCheck.UseVisualStyleBackColor = true;
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.residualBox);
            this.outputGroupBox.Controls.Add(this.impedOutBox);
            this.outputGroupBox.Controls.Add(this.posteriorStdDevLabel);
            this.outputGroupBox.Controls.Add(this.label7);
            this.outputGroupBox.Controls.Add(this.label8);
            this.outputGroupBox.Controls.Add(this.label9);
            this.outputGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputGroupBox.Location = new System.Drawing.Point(3, 371);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(469, 102);
            this.outputGroupBox.TabIndex = 4;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // residualBox
            // 
            this.residualBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.residualBox.Location = new System.Drawing.Point(182, 41);
            this.residualBox.Name = "residualBox";
            this.residualBox.Size = new System.Drawing.Size(281, 20);
            this.residualBox.TabIndex = 1;
            // 
            // impedOutBox
            // 
            this.impedOutBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impedOutBox.Location = new System.Drawing.Point(182, 14);
            this.impedOutBox.Name = "impedOutBox";
            this.impedOutBox.Size = new System.Drawing.Size(281, 20);
            this.impedOutBox.TabIndex = 0;
            // 
            // posteriorStdDevLabel
            // 
            this.posteriorStdDevLabel.AutoSize = true;
            this.posteriorStdDevLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posteriorStdDevLabel.Location = new System.Drawing.Point(389, 78);
            this.posteriorStdDevLabel.Name = "posteriorStdDevLabel";
            this.posteriorStdDevLabel.Size = new System.Drawing.Size(22, 13);
            this.posteriorStdDevLabel.TabIndex = 4;
            this.posteriorStdDevLabel.Text = "0.0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Posterior Standard Deviation";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Residual";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Impedance output";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(129, 479);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(99, 23);
            this.saveButton.TabIndex = 6;
            this.saveButton.Text = "Save Parameters";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(395, 479);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(77, 23);
            this.closeButton.TabIndex = 9;
            this.closeButton.Text = "Cancel";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // loadDrop
            // 
            this.loadDrop.AllowDrop = true;
            this.loadDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadDrop.Location = new System.Drawing.Point(3, 480);
            this.loadDrop.Name = "loadDrop";
            this.loadDrop.Size = new System.Drawing.Size(27, 22);
            this.loadDrop.TabIndex = 5;
            this.loadDrop.DragDrop += new System.Windows.Forms.DragEventHandler(this.loadDrop_DragDrop);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 484);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 99;
            this.label10.Text = "Load Parameters";
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(310, 479);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(79, 23);
            this.okButton.TabIndex = 8;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // applyButton
            // 
            this.applyButton.Location = new System.Drawing.Point(234, 479);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(70, 23);
            this.applyButton.TabIndex = 7;
            this.applyButton.Text = "Apply";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
            // 
            // AcousticInvWorkstepUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.loadDrop);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.optionsGroupBox);
            this.Controls.Add(this.parametersGroupBox);
            this.Controls.Add(this.InputsGroupBox);
            this.Name = "AcousticInvWorkstepUI";
            this.Size = new System.Drawing.Size(475, 505);
            this.InputsGroupBox.ResumeLayout(false);
            this.InputsGroupBox.PerformLayout();
            this.parametersGroupBox.ResumeLayout(false);
            this.parametersGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.correlationRangeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalToNoiseUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.impedUncertaintyUpDown)).EndInit();
            this.optionsGroupBox.ResumeLayout(false);
            this.optionsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.windowSizeUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizonCorrelatUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inlineInversionUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trendFreqUpDown)).EndInit();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton singleWvltRadio;
        private System.Windows.Forms.RadioButton cubeWvltRadio;
        private System.Windows.Forms.GroupBox InputsGroupBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox parametersGroupBox;
        private System.Windows.Forms.NumericUpDown correlationRangeUpDown;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown signalToNoiseUpDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown impedUncertaintyUpDown;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox optionsGroupBox;
        private System.Windows.Forms.NumericUpDown horizonCorrelatUpDown;
        private System.Windows.Forms.CheckBox horizonCorrelatCheck;
        private System.Windows.Forms.NumericUpDown inlineInversionUpDown;
        private System.Windows.Forms.CheckBox inlineInversionCheck;
        private System.Windows.Forms.NumericUpDown trendFreqUpDown;
        private System.Windows.Forms.CheckBox TrendFreqCheck;
        private System.Windows.Forms.NumericUpDown windowSizeUpDown;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button verticalGateButton;
        private System.Windows.Forms.CheckBox mergeInvTrendCheck;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label posteriorStdDevLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox residualBox;
        private System.Windows.Forms.TextBox impedOutBox;
        private Slb.Ocean.Petrel.UI.DropTarget waveletDrop;
        private Slb.Ocean.Petrel.UI.DropTarget impedanceDrop;
        private Slb.Ocean.Petrel.UI.DropTarget seismicCubeDrop;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button closeButton;
        private Slb.Ocean.Petrel.UI.DropTarget loadDrop;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button applyButton;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox impedanceCubePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox seismicCubePresentationBox;
        private Slb.Ocean.Petrel.UI.Controls.PresentationBox typeWaveletPresentationBox;
        private System.Windows.Forms.Label labelSuggStd;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelSeisStd;
        private System.Windows.Forms.Label label12;
    }
}
