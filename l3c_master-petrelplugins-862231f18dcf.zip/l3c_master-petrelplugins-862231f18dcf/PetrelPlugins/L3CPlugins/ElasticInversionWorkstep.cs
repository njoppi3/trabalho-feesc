using System;

using Slb.Ocean.Core;
using Slb.Ocean.Petrel;
using Slb.Ocean.Petrel.UI;
using Slb.Ocean.Petrel.Workflow;
using static UFSC_Plugins.ElasticInversionWorkstepUI;
using System.Collections.Generic;
using Slb.Ocean.Petrel.DomainObject;
using Slb.Ocean.Petrel.DomainObject.Seismic;
using System.Linq;
using Slb.Ocean.Basics;
using Slb.Ocean.Petrel.DomainObject.Shapes;

namespace UFSC_Plugins {
    /// <summary>
    /// This class contains all the methods and subclasses of the ElasticInversionWorkstep.
    /// Worksteps are displayed in the workflow editor.
    /// </summary>
    class ElasticInversionWorkstep : Workstep<ElasticInversionWorkstep.Arguments>, IExecutorSource, IAppearance, IDescriptionSource {
        #region Overridden Workstep methods

        /// <summary>
        /// Creates an empty Argument instance
        /// </summary>
        /// <returns>New Argument instance.</returns>

        protected override ElasticInversionWorkstep.Arguments CreateArgumentPackageCore(IDataSourceManager dataSourceManager) {
            return new Arguments(dataSourceManager);
        }
        /// <summary>
        /// Copies the Arguments instance.
        /// </summary>
        /// <param name="fromArgumentPackage">the source Arguments instance</param>
        /// <param name="toArgumentPackage">the target Arguments instance</param>
        protected override void CopyArgumentPackageCore(Arguments fromArgumentPackage, Arguments toArgumentPackage) {
            DescribedArgumentsHelper.Copy(fromArgumentPackage, toArgumentPackage);
        }

        /// <summary>
        /// Gets the unique identifier for this Workstep.
        /// </summary>
        protected override string UniqueIdCore {
            get {
                return "0d36e71c-fd7b-4b48-80cd-89b6a4220ad7";
            }
        }
        #endregion

        #region IExecutorSource Members and Executor class

        /// <summary>
        /// Creates the Executor instance for this workstep. This class will do the work of the Workstep.
        /// </summary>
        /// <param name="argumentPackage">the argumentpackage to pass to the Executor</param>
        /// <param name="workflowRuntimeContext">the context to pass to the Executor</param>
        /// <returns>The Executor instance.</returns>
        public Slb.Ocean.Petrel.Workflow.Executor GetExecutor(object argumentPackage, WorkflowRuntimeContext workflowRuntimeContext) {
            return new Executor(argumentPackage as Arguments, workflowRuntimeContext);
        }

        public class Executor : Slb.Ocean.Petrel.Workflow.Executor {
            Arguments args;
            WorkflowRuntimeContext context;

            public Executor(Arguments arguments, WorkflowRuntimeContext context) {
                this.args = arguments;
                this.context = context;
            }

            public override void ExecuteSimple() {
                // verifica��es faz na parte da UI, se faltar alguma ir testando e implementando l�

                //inputs
                List<InputStruct> inputList = new List<InputStruct>();
                foreach (string[] item in args.structure.inputList) {
                    //waveletDroid [0], cubeDroid [1], angle 2], snr [3], vetor de string com os dados da inputList
                    InputStruct inpt = new InputStruct();
                    try {
                        inpt.wavelet = Functions.getWaveletByReferenceVar(new Droid(item[0]));
                        inpt.cube = Functions.getCubeByReferenceVar(new Droid(item[1]));
                        inpt.angle = Decimal.Parse(item[2]);
                        inpt.snr = Decimal.Parse(item[3]);
                        inputList.Add(inpt);
                    } catch (Exception ex) {
                        PetrelLogger.InfoOutputWindow(ex.ToString());
                        PetrelLogger.InfoBox(ex.ToString());
                        return;
                    }
                }

                //trends
                SeismicCube vpCube, vsCube, rhoCube;
                try {
                    vpCube = Functions.getCubeByReferenceVar(new Droid(args.structure.vpCubeDroid));
                    vsCube = Functions.getCubeByReferenceVar(new Droid(args.structure.vsCubeDroid));
                    rhoCube = Functions.getCubeByReferenceVar(new Droid(args.structure.rhoCubeDroid));
                } catch (Exception ex) {
                    PetrelLogger.InfoOutputWindow(ex.ToString());
                    PetrelLogger.InfoBox(ex.ToString());
                    return;
                }

                //parameters  --UD = UpDown -- para endicar que � um numericUpDown
                decimal vpUD = args.structure.vpUD;
                decimal vsUD = args.structure.vsUD;
                decimal rhoUD = args.structure.rhoUD;
                decimal vp_vsUD = args.structure.vp_vsUD;
                decimal vp_rhoUD = args.structure.vp_rhoUD;
                decimal vs_rho = args.structure.vs_rho;
                decimal correlationRange = args.structure.correlationRange;

                //options  --CB = CheckBox --
                bool trendFrecCB = args.structure.trendFrecCB;
                decimal trendFrecUD = args.structure.trendFrecUD;
                bool mergeInvCB = args.structure.mergeInvCB;
                bool inlineInvCB = args.structure.inlineInvCB;
                decimal inlineInvUD = args.structure.inlineInvUD;

                //output
                //public string vpCubeOutput, vsCubeOutput, rhoCubeOutput, residualCubeOutput;
                string vpCubeOutput = args.structure.vpCubeOutput;
                string vsCubeOutput = args.structure.vsCubeOutput;
                string rhoCubeOutput = args.structure.rhoCubeOutput;
                string residualCubeOutput = args.structure.residualCubeOutput;
                bool compute_ip_vpvs = args.structure.computeIP_VPVS;
                string ipCubeOutput = args.structure.iaCubeOutput;
                string vpvsCubeOutput = args.structure.vpvsCubeOutput;

                //vertGate
                RegularHeightFieldSurface top = null;
                if (args.structure.topDroid != "") {
                    top = Functions.getRegularHeightFieldSurface(new Droid(args.structure.topDroid));
                    PetrelLogger.InfoOutputWindow("top: " + top.Name);
                }
                RegularHeightFieldSurface bottom = null;
                if (args.structure.bottomDroid != "") {
                    bottom = Functions.getRegularHeightFieldSurface(new Droid(args.structure.bottomDroid));
                    PetrelLogger.InfoOutputWindow("bottom: " + bottom.Name);
                }
                double topOffset = args.structure.topOffset;
                //PetrelLogger.InfoOutputWindow("topOffset: " + topOffset.ToString());
                double bottomOffset = args.structure.bottomOffset;
                //PetrelLogger.InfoOutputWindow("bottomOffset: " + bottomOffset.ToString());

                // ----------------------- check for horizon and create mean hor ----

                bool useHorizons = false;
                double[,] meanHor= null;
                double horSamples = 0;
                double tstart = inputList[0].cube.Origin.Z * 1000;
                double tstep = inputList[0].cube.PositionAtIndex(new IndexDouble3(0, 0, 1)).Z * -1000 + tstart;
                if (top != null)
                {
                    if (bottom == null)
                        bottom = top;

                    var seismicCube = inputList[0].cube;

                    double tend = seismicCube.PositionAtIndex(new IndexDouble3(0, 0, seismicCube.NumSamplesIJK.K - 1)).Z * 1000;
                    meanHor = Functions.StartMeanHorizonFromTwo(top.SpatialLattice.OriginalLattice, top.Samples, bottom.Samples, topOffset, bottomOffset,
                        seismicCube.SpatialLattice.OriginalLattice, tstart, tstep, tend, out horSamples);
                    useHorizons = true;
                }

                // ----------------------- checks -----------------------------------

                int j = 0;
                foreach (var i in inputList) {
                    j++;
                    if (i.cube == null || i.wavelet == null) {
                        PetrelLogger.ErrorBox("Problem at input row number: " + Convert.ToString(j));
                        return;
                    }
                    Index3 sijk = i.cube.NumSamplesIJK;
                    Index3 vpijk = vpCube.NumSamplesIJK;
                    Index3 vsijk = vsCube.NumSamplesIJK;
                    Index3 rhoijk = rhoCube.NumSamplesIJK;
                    if (sijk != vpijk || sijk != vsijk || sijk != rhoijk) {
                        PetrelLogger.ErrorBox("Seismic Cube and trend cube differ in size. Input number " + Convert.ToString(j));
                        return;
                    }
                }

                j = 0;
                foreach (var i in inputList) {
                    j++;
                    int i3 = i.cube.NumSamplesIJK.K;
                    if (i.wavelet.SampleCount > i3) {
                        PetrelLogger.ErrorBox("Wavalet is shorter than the volume. Input number " + Convert.ToString(j));
                        return;
                    }
                }

                // ------------------------ run -------------------------------------


                Project proj = PetrelProject.PrimaryProject;
                SeismicRoot sroot = SeismicRoot.Get(proj);

                SeismicProject sproj;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(PetrelProject.PrimaryProject);
                    sproj = sroot.GetOrCreateSeismicProject();
                    tr.Commit();
                }
                string colName = "Bayesian Elastic Inversion Results";
                SeismicCollection scol;

                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(sproj);
                    scol = sproj.CreateSeismicCollection(colName);
                    tr.Commit();
                }

                CubeFromPetrel[] cubetrends_wrap = new CubeFromPetrel[3];
                CubeFromPetrel[] cuberesults_wrap = new CubeFromPetrel[3];
                // write output
                SeismicCube vp_result, vs_result, rho_result = null;
                using (ITransaction tr = DataManager.NewTransaction()) {
                    tr.Lock(scol);
                    try
                    {
                        vp_result = scol.CreateSeismicCube(vpCube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.VelocityP, vpCube.ClippingRange);
                        vp_result.Name = vpCubeOutput;
                        vs_result = scol.CreateSeismicCube(vsCube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.VelocityS, vsCube.ClippingRange);
                        vs_result.Name = vsCubeOutput;
                        rho_result = scol.CreateSeismicCube(rhoCube, typeof(Single), PetrelProject.WellKnownTemplates.LogTypesGroup.Density, rhoCube.ClippingRange);
                        rho_result.Name = rhoCubeOutput;
                        tr.Commit();
                    }
                    catch (Exception)
                    {
                        PetrelLogger.ErrorBox("Error creating output cubes");
                        return;
                    }
                    if (useHorizons)
                    {
                        if (inlineInvCB)
                        {
                            cubetrends_wrap[0] = new CubeFromPetrel(vpCube, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cubetrends_wrap[1] = new CubeFromPetrel(vsCube, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cubetrends_wrap[2] = new CubeFromPetrel(rhoCube, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);

                        }
                        else
                        {
                            cubetrends_wrap[0] = new CubeFromPetrel(vpCube, meanHor, horSamples);
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, meanHor, horSamples, 10);
                            cubetrends_wrap[1] = new CubeFromPetrel(vsCube, meanHor, horSamples);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, meanHor, horSamples, 10);
                            cubetrends_wrap[2] = new CubeFromPetrel(rhoCube, meanHor, horSamples);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, meanHor, horSamples, 10);
                        }
                    } else
                    {
                        if (inlineInvCB)
                        {
                            cubetrends_wrap[0] = new CubeFromPetrel(vpCube, Convert.ToInt32(inlineInvUD), false);
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, Convert.ToInt32(inlineInvUD), false);
                            cubetrends_wrap[1] = new CubeFromPetrel(vsCube, Convert.ToInt32(inlineInvUD), false);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, Convert.ToInt32(inlineInvUD), false);
                            cubetrends_wrap[2] = new CubeFromPetrel(rhoCube, Convert.ToInt32(inlineInvUD), false);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, Convert.ToInt32(inlineInvUD), false);
                        }
                        else
                        {
                            cubetrends_wrap[0] = new CubeFromPetrel(vpCube);
                            cuberesults_wrap[0] = new CubeFromPetrel(vp_result, 10);
                            cubetrends_wrap[1] = new CubeFromPetrel(vsCube);
                            cuberesults_wrap[1] = new CubeFromPetrel(vs_result, 10);
                            cubetrends_wrap[2] = new CubeFromPetrel(rhoCube);
                            cuberesults_wrap[2] = new CubeFromPetrel(rho_result, 10);
                        }
                       
                    }
                    cuberesults_wrap[0].prepareWriteToPetrel();
                    cuberesults_wrap[1].prepareWriteToPetrel();
                    cuberesults_wrap[2].prepareWriteToPetrel();
                }

                ElasticInversionCLI.ParametersCLI p = new ElasticInversionCLI.ParametersCLI();
                SeismicCube ip_result, vpvs_result = SeismicCube.NullObject;
                CubeFromPetrel[] ip_vpvs_wrap = null;
                if (compute_ip_vpvs)
                {
                    p.calc_ip_vpvs = true;
                    ip_vpvs_wrap = new CubeFromPetrel[2];
                    using (ITransaction tr = DataManager.NewTransaction())
                    {
                        tr.Lock(scol);
                        try
                        {
                            ip_result = scol.CreateSeismicCube(rhoCube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.ImpedanceP, rhoCube.ClippingRange);
                            ip_result.Name = ipCubeOutput;
                            vpvs_result = scol.CreateSeismicCube(rhoCube, typeof(Single), PetrelProject.WellKnownTemplates.GeophysicalGroup.VelocityRatio, rhoCube.ClippingRange);
                            vpvs_result.Name = vpvsCubeOutput;
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }
                        if (useHorizons)
                        {
                            if (inlineInvCB)
                            {
                                ip_vpvs_wrap[0] = new CubeFromPetrel(ip_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                                ip_vpvs_wrap[1] = new CubeFromPetrel(vpvs_result, Convert.ToInt32(inlineInvUD), meanHor, horSamples);
                            }
                            else
                            {
                                ip_vpvs_wrap[0] = new CubeFromPetrel(ip_result, meanHor, horSamples);
                                ip_vpvs_wrap[1] = new CubeFromPetrel(vpvs_result, meanHor, horSamples);
                            }
                        }
                        else
                        {
                            if (inlineInvCB)
                            {
                                ip_vpvs_wrap[0] = new CubeFromPetrel(ip_result, Convert.ToInt32(inlineInvUD), false);
                                ip_vpvs_wrap[1] = new CubeFromPetrel(vpvs_result, Convert.ToInt32(inlineInvUD), false);
                            }
                            else
                            {
                                ip_vpvs_wrap[0] = new CubeFromPetrel(ip_result, 10);
                                ip_vpvs_wrap[1] = new CubeFromPetrel(vpvs_result, 10);
                            }

                        }
                        ip_vpvs_wrap[0].prepareWriteToPetrel();
                        ip_vpvs_wrap[1].prepareWriteToPetrel();
                    }
                    
                }

                CubeFromPetrel[] cubeseis_wrap = new CubeFromPetrel[inputList.Count];
                CubeFromPetrel[] cuberesids_wrap = new CubeFromPetrel[inputList.Count];
                double[][] wavelets = new double[inputList.Count][];
                double[] angles = new double[inputList.Count];
                // write outputres
                j = 0;
                p.sgm_d2 = new double[inputList.Count];
                foreach (var i in inputList) {
                    SeismicCube residuals;
                    using (ITransaction tr = DataManager.NewTransaction()) {
                        tr.Lock(scol);
                        try
                        {
                            residuals = scol.CreateSeismicCube(i.cube, typeof(Single), PetrelProject.WellKnownTemplates.SeismicColorGroup.SeismicDefault, i.cube.ClippingRange);
                            residuals.Name = residualCubeOutput + " " + i.angle;
                            tr.Commit();
                        }
                        catch (Exception)
                        {
                            PetrelLogger.ErrorBox("Error creating output cubes");
                            return;
                        }
                    }
                    if (useHorizons)
                    {
                        if (inlineInvCB)
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInvUD), meanHor, horSamples, false);
                        }
                        else
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, meanHor, horSamples);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, meanHor, horSamples, 10);
                        }
                    }
                    else
                    {
                        if (inlineInvCB)
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube, Convert.ToInt32(inlineInvUD), false);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, Convert.ToInt32(inlineInvUD), false);
                        }
                        else
                        {
                            cubeseis_wrap[j] = new CubeFromPetrel(i.cube);
                            cuberesids_wrap[j] = new CubeFromPetrel(residuals, 10);
                        }

                    }
                    cuberesids_wrap[j].prepareWriteToPetrel();
                    wavelets[j] = i.wavelet.Amplitudes.ToArray();
                    angles[j] = Convert.ToDouble(i.angle) * Math.PI / 180.0;
                    p.sgm_d2[j] = Convert.ToDouble(i.snr * i.snr);

                    j++;
                }

                p.corr_samples = Convert.ToDouble(correlationRange) / tstep;
                p.filter_model = trendFrecCB;
                p.merge_inversion = mergeInvCB;
                p.interval_frequency_sec = inputList[0].wavelet.SamplingInterval;
                p.sgm_m = new double[3];
                p.sgm_m[0] = ElasticInversionCLI.convertUIVpstdtoLogstd(Convert.ToDouble(vpUD));
                p.sgm_m[1] = ElasticInversionCLI.convertUIVsstdtoLogstd(Convert.ToDouble(vsUD));
                p.sgm_m[2] = ElasticInversionCLI.convertUIRhostdtoLogstd(Convert.ToDouble(rhoUD));

                p.trend_frequency = Convert.ToDouble(trendFrecUD);
                p.prop_corr = new double[3];
                p.prop_corr[0] = Convert.ToDouble(vp_vsUD);
                p.prop_corr[1] = Convert.ToDouble(vp_rhoUD);
                p.prop_corr[2] = Convert.ToDouble(vs_rho);

                ElasticTaskSetup task = new ElasticTaskSetup(ref cubeseis_wrap, ref cubetrends_wrap, ref p, ref cuberesults_wrap, ref ip_vpvs_wrap,
                                                                ref cuberesids_wrap, ref wavelets, angles);

                List<ElasticTaskSetup> tasks = new List<ElasticTaskSetup>();
                tasks.Add(task);

                using (IProgress pbar = PetrelLogger.NewProgress(0, Convert.ToInt32(cubeseis_wrap[0].getNumInlines() * cubeseis_wrap[0].getNumCrosslines()))) {
                    try {
                        pbar.SetProgressText("Performing Bayesian Elastic Inversion");

                        ParallelBatchExecutor executor = new ParallelBatchExecutor(tasks, doElasticInversion, pbar);
                        executor.Execute();
                        pbar.Dispose();
                    } catch (Exception excep) {
                        pbar.Dispose();
                        PetrelLogger.InfoBox("Error \n" + excep.Message);
                    }
                }
                PetrelLogger.InfoBox("Process complete");

            }
            private void doElasticInversion(object objJob) {
                var task = (ElasticTaskSetup) objJob;
                task._statusMsg = "Reading data from input volumes";

                foreach (var c in task._cubeseis)
                    c.readFromPetrel();
                task._cubetrend[0].readFromPetrel(); // Petrel canonical unit m/s Ok
                task._cubetrend[1].readFromPetrel(); // Petrel canonical unit m/s Ok
                task._cubetrend[2].readFromPetrel(); // Petrel canonical unit kg/cm3 divide by 1000

                int nseis = (int) task._cubeseis[0].getNumZlines();

                ElasticInversionCLI bei = new ElasticInversionCLI(nseis - 1, task._p, task._wavelets, task._angles);

                bei.setSeismicCubes(task._cubeseis);
                bei.setTrendVpCube(task._cubetrend[0]);
                bei.setTrendVsCube(task._cubetrend[1]);
                bei.setTrendPCube(task._cubetrend[2]);


                task._statusMsg = "Processing data";
                task.ei = bei;
                bei.solve();
                task._cube_vpvsrho_out[0].setCube(bei.getVpCube());
                task._cube_vpvsrho_out[1].setCube(bei.getVsCube());
                task._cube_vpvsrho_out[2].setCube(bei.getPCube());
                if (task._p.calc_ip_vpvs)
                {
                    task._cube_ip_vpvs_out[0].setCube(bei.getIPCube());
                    task._cube_ip_vpvs_out[1].setCube(bei.getVPVSCube());
                }
                var outs = bei.getSyntheticsCube();
                int i = 0;
                foreach (var c in task._cuberesidout)
                    c.setCube(outs[i++]);

                task._statusMsg = "Writing Vp results";
                task._cube_vpvsrho_out[0].writeToPetrel(ref task.progressPct, task._cubetrend[0]); // Petrel canonical unit m/s Ok
                task._statusMsg = "Writing Vs results";
                task._cube_vpvsrho_out[1].writeToPetrel(ref task.progressPct, task._cubetrend[1]); // Petrel canonical unit m/s Ok
                task._statusMsg = "Writing rho results";
                task._cube_vpvsrho_out[2].writeToPetrel(ref task.progressPct, task._cubetrend[2], 1000); // Petrel canonical unit kg/cm3 multiply by 1000
                if (task._p.calc_ip_vpvs)
                {
                    task._statusMsg = "Writing IP results";
                    task._cube_ip_vpvs_out[0].writeToPetrel(ref task.progressPct, task._cubetrend[2], 1000);
                    task._statusMsg = "Writing VP/VS results";
                    task._cube_ip_vpvs_out[1].writeToPetrel(ref task.progressPct, task._cubetrend[0], 1000);
                }

                task._statusMsg = "Writing Seismic results";
                foreach (var c in task._cuberesidout)
                    c.writeToPetrel(ref task.progressPct, task._cubetrend[0]);
            }

            private struct InputStruct {
                public Wavelet wavelet;
                public SeismicCube cube;
                public decimal angle, snr;

                private InputStruct(Wavelet wavelet, SeismicCube cube, decimal angleUpDown, decimal signalToNoiseUpDown) {
                    this.wavelet = wavelet;
                    this.cube = cube;
                    angle = angleUpDown;
                    snr = signalToNoiseUpDown;
                }
            }
        }

        #endregion

        /// <summary>
        /// ArgumentPackage class for ElasticInversionWorkstep.
        /// Each public property is an argument in the package.  The name, type and
        /// input/output role are taken from the property and modified by any
        /// attributes applied.
        /// </summary>
        public class Arguments : DescribedArgumentsByReflection {
            public ElasticInversionStruct structure;
            public Arguments()
                : this(DataManager.DataSourceManager) {
            }

            public Arguments(IDataSourceManager dataSourceManager) {
            }



        }

        #region IAppearance Members
        public event EventHandler<TextChangedEventArgs> TextChanged;
        protected void RaiseTextChanged() {
            if (this.TextChanged != null)
                this.TextChanged(this, new TextChangedEventArgs(this));
        }

        public string Text {
            get { return Description.Name; }
            private set {
                // TODO: implement set
                this.RaiseTextChanged();
            }
        }

        public event EventHandler<ImageChangedEventArgs> ImageChanged;
        protected void RaiseImageChanged() {
            if (this.ImageChanged != null)
                this.ImageChanged(this, new ImageChangedEventArgs(this));
        }

        public System.Drawing.Bitmap Image {
            get { return PetrelImages.Modules; }
            private set {
                // TODO: implement set
                this.RaiseImageChanged();
            }
        }
        #endregion

        #region IDescriptionSource Members

        /// <summary>
        /// Gets the description of the ElasticInversionWorkstep
        /// </summary>
        public IDescription Description {
            get { return ElasticInversionWorkstepDescription.Instance; }
        }

        /// <summary>
        /// This singleton class contains the description of the ElasticInversionWorkstep.
        /// Contains Name, Shorter description and detailed description.
        /// </summary>
        public class ElasticInversionWorkstepDescription : IDescription {
            /// <summary>
            /// Contains the singleton instance.
            /// </summary>
            private static ElasticInversionWorkstepDescription instance = new ElasticInversionWorkstepDescription();
            /// <summary>
            /// Gets the singleton instance of this Description class
            /// </summary>
            public static ElasticInversionWorkstepDescription Instance {
                get { return instance; }
            }

            #region IDescription Members

            /// <summary>
            /// Gets the name of ElasticInversionWorkstep
            /// </summary>
            public string Name
            {
                get { return "Bayesian Linearized Elastic MAP Inversion"; }
            }
            /// <summary>
            /// Gets the short description of ElasticInversionWorkstep
            /// </summary>
            public string ShortDescription {
                get { return ""; }
            }
            /// <summary>
            /// Gets the detailed description of ElasticInversionWorkstep
            /// </summary>
            public string Description {
                get { return ""; }
            }

            #endregion
        }
        #endregion

        public class UIFactory : WorkflowEditorUIFactory {
            /// <summary>
            /// This method creates the dialog UI for the given workstep, arguments
            /// and context.
            /// </summary>
            /// <param name="workstep">the workstep instance</param>
            /// <param name="argumentPackage">the arguments to pass to the UI</param>
            /// <param name="context">the underlying context in which the UI is being used</param>
            /// <returns>a Windows.Forms.Control to edit the argument package with</returns>
            protected override System.Windows.Forms.Control CreateDialogUICore(Workstep workstep, object argumentPackage, WorkflowContext context) {
                return new ElasticInversionWorkstepUI((ElasticInversionWorkstep) workstep, (Arguments) argumentPackage, context);
            }
        }
    }
}